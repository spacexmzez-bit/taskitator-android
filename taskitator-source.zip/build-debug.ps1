# Taskitator debug build helper. Requires installed Android SDK and JDK 21.
param([switch]$SkipTests)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Fail($message) { throw "Taskitator build: $message" }

if (-not $env:JAVA_HOME) {
    $studioJbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
    if (Test-Path (Join-Path $studioJbr 'bin\java.exe')) { $env:JAVA_HOME = $studioJbr }
}
if ($env:JAVA_HOME) {
    $env:PATH = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:PATH
}
$java = Get-Command java.exe -ErrorAction SilentlyContinue
if (-not $java) { Fail 'Java not found. Install JDK 21 or configure JAVA_HOME.' }
$javaVersion = (& java -version 2>&1 | Select-Object -First 1) -join ''
Write-Host "Java: $javaVersion"
if ($javaVersion -notmatch 'version "21[\.\"]|openjdk 21[\.\s]') {
    Fail 'JDK 21 is required for this project. Set JAVA_HOME to a JDK 21 installation.'
}

$sdk = $env:ANDROID_HOME
if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
if (-not $sdk) { $sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path $sdk)) { Fail "Android SDK not found at $sdk. Install SDK Platform 36 via Android Studio SDK Manager." }
if (-not (Test-Path (Join-Path $sdk 'platforms\android-36'))) { Fail 'Android SDK Platform 36 is missing. Install it in SDK Manager.' }
$escapedSdk = $sdk.Replace('\','/')
Set-Content -Path (Join-Path $PSScriptRoot 'local.properties') -Value "sdk.dir=$escapedSdk" -Encoding ASCII
Write-Host "Android SDK: $sdk"

$version = '9.8.2'
$gradleRoot = Join-Path $PSScriptRoot '.local-gradle'
$gradleExe = Join-Path $gradleRoot "gradle-$version\bin\gradle.bat"
if (-not (Test-Path $gradleExe)) {
    New-Item -ItemType Directory -Path $gradleRoot -Force | Out-Null
    $zipPath = Join-Path $gradleRoot "gradle-$version-bin.zip"
    $url = "https://services.gradle.org/distributions/gradle-$version-bin.zip"
    Write-Host "Downloading Gradle $version from $url (first run only)..."
    Invoke-WebRequest -Uri $url -OutFile $zipPath -UseBasicParsing
    Write-Host 'Extracting Gradle...'
    Expand-Archive -Path $zipPath -DestinationPath $gradleRoot -Force
    Remove-Item $zipPath
}
if (-not (Test-Path $gradleExe)) { Fail 'Gradle executable was not installed correctly.' }
if (-not $SkipTests) {
    Write-Host 'Running Android unit tests...'
    & $gradleExe --no-daemon :app:testDebugUnitTest
    if ($LASTEXITCODE -ne 0) { Fail 'Unit tests failed. No APK will be labeled verified.' }
}
Write-Host 'Building debug APK...'
& $gradleExe --no-daemon :app:assembleDebug
if ($LASTEXITCODE -ne 0) { Fail 'APK compilation failed. Read the error above.' }
$apk = Join-Path $PSScriptRoot 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $apk)) { Fail 'Gradle finished but the APK file was not found.' }
Write-Host "BUILD SUCCESSFUL. Debug APK: $apk"
