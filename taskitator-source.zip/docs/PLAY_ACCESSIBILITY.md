# Play Console — Accessibility declaration pack (Phase 2)

Policy read on 2026-11-14: "Use of the AccessibilityService API" and "Best practices for prominent disclosure and consent" (Play Console Help). Re-read both before Phase 8; the rules change.

What the policy requires from an app that is **not** an accessibility tool, and where this build meets it:

| Requirement | Where |
|---|---|
| `isAccessibilityTool` not claimed | `res/xml/blocker_service.xml` (`false`) |
| In-app prominent disclosure, separate from any other disclosure, shown before the permission is requested | `BlockerDisclosure` in `ui/screens/BlockerSettings.kt` (Settings → Phone Lock → "Set up app blocker") |
| Explicit consent by a clear action; declining must be respected | "Agree" opens Android settings; "No thanks" closes the dialog and nothing is enabled |
| The service description alone does not count as disclosure | The description exists too (`strings.xml`) but the dialog is the disclosure |
| Declaration form in Play Console with a video | Text and script below |
| Store listing must mention the Accessibility API use | Sentence below |
| No autonomous actions through the API | The service performs one fixed rule: "listed app in front + phone locked → show block screen". The only global action is "go to home screen", and only when the user taps that button |

## 1. Declaration form answers

**Why does your app need the AccessibilityService API?** → App functionality.

**Describe the core feature (paste):**

> Taskitator is a task manager that locks distracting apps until the user finishes the tasks they planned for today. The user chooses which apps to block. Taskitator uses the AccessibilityService API only to detect which app is in the foreground (window-state-changed events, package name only). When the foreground app is on the user's block list and the user's tasks for today are unfinished, Taskitator shows its own full-screen block screen over that app (an accessibility overlay). The service does not retrieve window content (canRetrieveWindowContent is false), does not read text, input, notifications or passwords, does not perform gestures or clicks in other apps, and does not collect, store or transmit which apps the user opens. The block list is stored only on the device. The feature is off until the user reads an in-app disclosure, agrees, and enables the service in Android settings.

**Is it an accessibility tool?** → No.

## 2. Store listing sentence (must be in the long description)

> Taskitator uses the Accessibility Service API to see which app is open, so it can block the apps you choose until today's tasks are done. It does not read your screen or what you type, and it does not collect or share the apps you use.

Arabic:

> يستخدم Taskitator واجهة خدمات إمكانية الوصول (Accessibility Service API) لمعرفة التطبيق المفتوح فقط، حتى يحظر التطبيقات التي تختارها إلى أن تنهي مهام اليوم. لا يقرأ محتوى الشاشة ولا ما تكتبه، ولا يجمع أو يشارك أسماء التطبيقات التي تستخدمها.

## 3. Privacy policy paragraph

> **Accessibility Service.** If you turn on the app blocker, Taskitator uses Android's Accessibility Service API to learn the package name of the app currently on screen. This is used on your device, at that moment, to decide whether to show the block screen. Taskitator does not read screen content, text you type, notifications or passwords through this service. The package names of the apps you open and your block list are not sent to our servers and are not shared with anyone. To know whether your phone is locked, the app asks our server for your lock status (locked / not locked); that request contains no information about your apps. You can turn the service off at any time in Android Settings > Accessibility.

## 4. Demo video script (about 60–90 seconds, screen recording, upload to YouTube as unlisted)

Use a debug build with "Test lock" or a real account with an unfinished task. Add captions with the text in quotes.

1. Open Taskitator from the home screen. Caption: "Taskitator – task manager with an app blocker."
2. Menu → Settings → "Phone Lock" tab. Show "Accessibility permission is off".
3. Tap "Set up app blocker". Hold the disclosure on screen for 5 seconds and scroll it fully. Caption: "Prominent disclosure, shown before the permission."
4. Tap "No thanks". Show that nothing changed (still "off"). Caption: "Declining: nothing is enabled."
5. Tap "Set up app blocker" again → "Agree". Android accessibility settings open.
6. Tap "Taskitator app blocker" → turn it on → confirm Android's own dialog. Go back to Taskitator. Show "✓ Accessibility permission is on".
7. Tap "Choose apps to block", tick one app (for example YouTube), Save. Turn on "Block apps while locked".
8. Go home, open the chosen app. The block screen appears. Caption: "Core feature: the chosen app is blocked while today's tasks are unfinished."
9. Tap "Open Taskitator". Show the task list. Caption: "Finishing the tasks unlocks the app."
10. (Optional) Open an app that is not on the list to show it opens normally.

The policy asks for: opening the app, the path to the disclosure, the consent flow including granting the permission, the decline flow and how the disclosure is reached again, and the core feature in use. Steps 1–9 cover each.

## 5. Battery guidance per phone maker (also shown in the app, shorter)

| Maker | Setting |
|---|---|
| Samsung (One UI) | Settings → Apps → Taskitator → Battery → Unrestricted. Settings → Battery → Background usage limits → Never sleeping apps → add Taskitator |
| Xiaomi / Redmi / Poco | Settings → Apps → Manage apps → Taskitator → Autostart on; Battery saver → No restrictions. In recents, long-press Taskitator → lock |
| Oppo / Realme / OnePlus | Settings → Apps → Taskitator → Battery usage → Allow background activity and Allow auto launch |
| Vivo | i Manager → App manager → Autostart → Taskitator on; Battery → Background power consumption → allow |
| Huawei / Honor | Settings → Battery → App launch → Taskitator → Manage manually, all three switches on |
| Pixel / stock Android | Settings → Apps → Taskitator → App battery usage → Unrestricted |

These paths differ between OS versions; none were tested on a device in this phase.
