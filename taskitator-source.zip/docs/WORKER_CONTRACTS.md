# Taskitator Worker contracts and Phase 0 findings

Read from `spacexmzez-bit/Taskitator` `main` on 2026-11-10 (`worker.js`, `pro-backend.js`, `break-systems.js`, `pro/*.js`, website client JS). Nothing here was tested against the live Worker; it is what the code says.

Base URL used by the app: `https://taskitator-sync.spacexmzez.workers.dev`.

---

## Part A — Findings that change the plan

### A1. Blockers for later phases (need a Worker change)

| # | Finding | Where | Affects |
|---|---|---|---|
| 1 | Native Clerk tokens are accepted only when there is no `Origin` header and `azp` is missing or one of `com.mazendev.taskitator`, `clerk://com.mazendev.taskitator.callback`, `clerk://com.mazendev.taskitator.oauth`. The app's `applicationId` is `com.aistudio.taskitator.mvptsk`. If the Clerk Android SDK sets `azp` from the package, every request returns 401. | `worker.js` `verifySession` | Phase 3 |
| 2 | `POST /auth/verification/start` rejects any request whose `Origin` is not the website (403 "Open verification from the Taskitator website"). A native client sends no `Origin`, and adding one breaks finding 1. So the app cannot start a sensitive-action verification today. | `ActionVerification.start` | Phase 3 (account deletion) |
| 3 | `DELETE /auth/account` requires `phrase === "Macrodroid disabled"` and `blocker_disabled === true`. The app must not mention MacroDroid. | `AccountDeletion.accept` | Phase 3 |
| 4 | Password verification needs a Clerk reverification and the custom session claim `taskitator_reverification_id` plus `fva`. Whether the Clerk Android SDK can run a reverification is unverified. Google verification redirects to `settings.html` on the website, so it is web-only as written. | `ActionVerification.password`, `.callback` | Phase 3 |
| 5 | Pro is one record, `pro:entitlement:<userId>`, built only from a Keyo token. Hosted credit allowances come only from the Keyo parameters `d_allow` / `m_allow`; there is no default. Play Pro needs its own allowance source (fixed per product, set in the Worker). | `KeyoLicenses.record`, `planOf`, `hostedAllowance` | Phase 4 |
| 6 | `POST /study-plan` `authorize` builds the plan's tasks in the Worker but returns only `{authorized:true}`. The client must build byte-identical tasks (the grant is a SHA-256 of `JSON.stringify` of the sorted tasks, so key order matters). | `worker.js` study route | Phase 5 |

**Status after Phase 3 (2026-11-14), Worker patch `taskitator-worker-phase3`:**
- 1: fixed. `com.aistudio.taskitator.mvptsk`, `clerk://com.aistudio.taskitator.mvptsk.callback` and `.oauth` are accepted as `azp` when there is no `Origin` header. The Clerk Android SDK sends no `Origin`, so its tokens most likely carry no `azp` at all, which the Worker already accepted; not confirmed with a real token yet.
- 2 and 4: solved without reverification. New verification method `signin`, app tokens only: the session in the request must be at most 5 minutes old, and the record is `verified` at once. The app signs the user in again and calls it straight away. Website methods are unchanged.
- 3: fixed. For app tokens the phrase is `Delete my account`; the website phrase is unchanged.

Recommendations (as written in Phase 0):
- 1–4: one additive Worker patch in Phase 3: accept the real package in `azp`, accept native verification without `Origin` when the token is native, accept a neutral deletion phrase for `X-Taskitator-Client: android`. Confirm what `azp` the Clerk Android SDK actually sends before writing it.
- 6: porting `TaskitatorStudyCore.build` to Kotlin with exact key order is option (C) in the owner's list: a harder route than needed. Simpler: make `authorize` also return `tasks` (as `/study-plan/manage` `replan` already does). Additive, a few lines.

### A2. Defects found in the current Android source (fix in Phase 1)

- Push omits `dynamic_priority_schema: 1`. The Worker answers 428 for any account that has a task with `dynamic_priority_target`. The app must first preserve that field on every task, then send the flag.
- The app calls `/pro/emergency`; the website calls `/emergency`. Both run the same handler. Switch to `/emergency`.
- `/ai/generate` and `/ai/provider` are behind `!account → 403`; `/pro/*` is not. No action, just note the different error.

### A3. Answers to the Phase 0 questions

- **Keyo license model.** A Keyo token carries `expiresAt`, which is a timestamp or `null`. `null` means no expiry (lifetime). Tier is `pro` or `max`. Activating a new key replaces the stored record with whatever Keyo returns; the Worker does no stacking. Whether Keyo itself extends expiry on a second key cannot be seen from this repo — check in Keyo.
- **AI credits sold separately?** No. There is no top-up route. Credits are a daily and 30-day allowance attached to the license. So nothing extra has to go through Play.
- **Free accounts and AI.** Free accounts can use AI only with a personal key (10 credits/day, 220/month, metered by the Worker). Hosted AI is Pro only. In the app, a free user with no key saved on the web has no AI at all.
- **Pomodoro breaks.** The website's Pomodoro is a standalone timer. It never calls `/breaks` and records nothing. The app's in-memory `_breaks` path has no website equivalent: delete it, record nothing.
- **After a personal-review approval.** The website calls `POST /pro/ai/batch-confirm` with `{job_id, task_ids:[id], operation_id, batch:false}`, then pulls with local changes discarded. The Worker marks the task complete. The client never marks it complete itself.
- **Emergency endpoint.** Website: `/emergency`.
- **Where calculations run.**

| Rule | Worker | Website JS only | App action |
|---|---|---|---|
| Recurrence reconcile (next occurrences) | Yes, on pull, status, push, confirm | also runs locally | Rely on Worker; port only what authoring needs to build a valid `recurrence_state` |
| Smart Study (`apply`, `guard`) | Yes, on push and confirm | also local | Rely on Worker |
| Early bonus (`apply`, `guard`) | Yes, on push | also local | Rely on Worker |
| Phone-lock counting (`status-count`) | Yes | UI only | Rely on Worker |
| Dynamic priority (effective priority for display) | Guard only (who may set it) | Yes (`TaskitatorPriority`, `components.js`) | Port with vectors from `dynamic-priority.test.js` |
| Study plan build | Yes (not returned) | Yes | See finding 6 |
| Three-way merge | No | Yes (`merge3`, `core.js`) | Port with vectors from `merge.test.js` |
| Break rules | Yes | UI only | Rely on Worker |

- **Clerk JWT validation.** RS256 against `CLERK_JWT_KEY`; `iss` must equal `CLERK_ISSUER`; `exp`, `nbf`, `iat` checked; `sub` `user_…`, `sid` `sess_…`; then a live session lookup at Clerk on every request. `azp`/`Origin` rules as in finding 1. Any request with an `Origin` header not in `ALLOWED_ORIGINS` gets 403, so the app must never send `Origin`.

### A4. Phone token for the blocker

`POST /auth/phone` creates a `tkp_…` token (shown once). Free accounts get 3 devices, Pro 12. The app's blocker will use one slot per install; a reinstall creates a new one and leaves the old one listed until removed. The app should store its device `id` and delete it on sign-out.

---

## Part B — Contracts

General:
- Auth: `Authorization: Bearer <Clerk session JWT>`, or `Bearer tkp_<64 hex>` (phone token, `/status` only).
- Methods: GET, POST, DELETE only. Others 405.
- Errors: `{ "error": string, "code"?: string }` with the HTTP status. Unknown failures: 503.
- 401 = sign in again. 403 with "Connect your Taskitator account" = no linked account. 410 = account deletion accepted.

### Auth

**GET `/auth/me`** → `{ account: { user, display_name, user_id, username? } | null }`. If deletion is pending: `{ account: null, deletion: { status, receipt, phone_recovery_until } }`.

**POST `/auth/account`** body `{ mode: "create" }` → `{ success: true, account }`. Needs a verified primary email (403 otherwise). `mode: "migrate"` is legacy web only.

**DELETE `/auth/account`** body `{ blocker_disabled: true, phrase: "Delete my account" (app) or "Macrodroid disabled" (website), receipt: <64 hex>, verification_id }` → `{ accepted: true, receipt, status: "pending", phone_recovery_until }`. 503 if deletion is not enabled; 403 if the verification is not `verified`.

**POST `/auth/deletion/status`** (no auth) body `{ receipt }` → `{ accepted, status: "pending"|"retrying"|"complete", complete, accepted_at, completed_at, phone_recovery_until, legacy_review_needed, migration_approval_remains }`. 404 if unknown.

**POST `/auth/verification/start`** body `{ method: "password"|"google", action: "delete-account"|"api-key-reveal"|"api-key-save"|"api-key-delete", stage_id?, provider? }` → `{ verification_id, expires_at, authorization_url? }`. Valid 5 minutes. See findings 2 and 4.

App only (token without a website `azp`, no `Origin`): body `{ method: "signin", action: "delete-account" }` → `{ verification_id, expires_at }`, already verified. 403 if the session is older than 5 minutes ("Sign in again to confirm…"), if the token is a website token, or for any other action.

**POST `/auth/verification/password`** body `{ verification_id, action }` → `{ verified: true }`.

**POST `/auth/verification/status`** body `{ verification_id, action }` → `{ verified, status, action, context, expires_at }`.

**`/auth/phone`**
- GET → `{ active, created_at, devices: [{ id, label, status: "active"|"revoked", created_at }], limit, limits: { free: 3, pro: 12 } }`
- POST body `{ label? }` → `{ success, token, created_at, device, devices, limit }`. 409 at the limit.
- DELETE `?device=<id>` (or none = all) → `{ success, devices, limit }`. 404 if the id is gone.

### Status

**GET `/status`** (session or phone token). Add `?format=text` for plain text.
- JSON: `{ status: "ok", device_locked: bool, finished, in_break, break_system, universe_degraded, universe_locks, sleep_lock_active, sleep, emergency_bypass? }`
- Text: two lines, `device_locked = true|false` and `sleep = true|false`.
- Order of precedence: tasks → active break → Universe lock → Sleep Lock (reported in `sleep` only, does not change `device_locked`) → Emergency Bypass (clears both).
- Deleted account, phone token within 7 days: `{ device_locked: false, sleep: false, account_deleted: true, recovery_until }`.
- Revoked or over-limit phone token: 401.

### Sync

**GET `/sync/pull`** → the snapshot `{ tasks, settings, projects, today_breaks, recurrence_state, completed_audit_ledger, …, version, saved_at }` or `{ empty: true, version }`. Secret settings fields are stripped. `today_breaks` is always the server copy.

**POST `/sync/push`** body = snapshot plus `{ base_version: int, mutation_id: /^[A-Za-z0-9_-]{8,100}$/, recurrence_schema: 1, dynamic_priority_schema: 1 }` → `{ success, version, updated_at, today_breaks }`.

| Status | Meaning |
|---|---|
| 409 `{ conflict: true, remote_version }` | Another device wrote first. Pull, merge, push again with a new `mutation_id`. |
| 409 (message) | Smart Study guard, or a study plan/criteria grant mismatch |
| 428 | Missing `base_version` / `mutation_id`, or schema flags missing when the account uses recurrence or Dynamic Priority |
| 403 | Protected-task rule, Pro-only field, loosening phone-lock counting while today is unfinished, or a study plan pushed without a grant |
| 400 | Invalid tasks, cycle, recurrence state |
| 413 | More than 10,000 tasks, nesting over 64, text over 10,000 chars, body over 20 MiB |

A repeat of the same `mutation_id` + same body + same `base_version` returns the original success. `today_breaks` sent by the client is ignored.

### Breaks

**GET `/breaks?tz=<IANA zone>`** → the break view:
`{ date, timezone, day_start_hour, cycle_start, cycle_end, reset_at, server_now, revision, system: null|"scheduled"|"flexible", locked_at, lock_source, allowance: { total, used, reserved, remaining }, scheduled: { breaks, saved, saved_at, closing_at, planning, can_start_planning, can_edit, locked, reason, final }, flexible: { active, minimum, strict, gap_until, gap_minutes, presets: [{ minutes, available, reason }], max_custom, can_start, reason, sessions }, strict_today, reserved_breaks: [{ id, minutes, from, to, window_start, window_end, state, started_at, ends_at, granted_minutes, clipped, can_start }], reserved_limits, in_break, record, strict: { config, effective_today, pending_from, revision, locked, required_tasks, bypass, limits } }`

**POST `/breaks`** body `{ action, timezone, … }` → same view (plus `replayed: true` on a harmless repeat).

| action | Extra fields | Main errors |
|---|---|---|
| `plan_start` | — | 409 `SCHEDULE_SAVED`, `PLANNING_CLOSED` |
| `plan_cancel` | — | — |
| `schedule_save` | `breaks: [{start,end}]` (0–3), `reserved: [{minutes, from, to}]` (0–2) | 409 `PLANNING_REQUIRED`, `PLANNING_ENDED`, `ALLOWANCE_LOW`, `BREAK_OVERLAP`, `RESERVED_CONFLICT`, `STRICT_MINIMUM`; 400 `INVALID_SCHEDULE`, `INVALID_RESERVED` |
| `lock` | `system: "scheduled"` | 409 `BREAK_ACTIVE` |
| `reserved_start` | `id`, `operation_id` | 409 `NO_RESERVED`, `RESERVED_USED`, `RESERVED_EARLY`, `RESERVED_MISSED`, `PLANNING_OPEN`, `BREAK_ACTIVE`, `BREAK_OVERLAP` |
| `flex_start` | `mode: "preset"|"custom"|"until"`, `minutes`, `operation_id` | 409 `SYSTEM_LOCKED`, `BREAK_ACTIVE`, `STRICT_GAP`, `ALLOWANCE_LOW`, `RESET_SOON`, `BREAK_OVERLAP`, `STRICT_MINIMUM`; 400 `INVALID_DURATION` |
| `flex_end` | `break_id?` | 409 `NO_ACTIVE_BREAK`, `BREAK_CHANGED`, `MINIMUM_NOT_REACHED` |
| `strict_save` | `revision`, `config: { allowance, flexible, scheduled }` | 409 `STRICT_CHANGED`; 403 `STRICT_LOCKED` |

### Sleep Lock

**GET `/sleep-lock`** → `{ schedule: { enabled, bedtime, wake_time, timezone: "Asia/Riyadh", revision }, delay: { day, minutes, sleep_at, wake_at } | null }`.

**POST `/sleep-lock`**
- Save: `{ enabled, bedtime: "HH:MM", wake_time: "HH:MM", revision }` → `{ schedule }`. 409 if `revision` is stale. 400 if times are equal or extra keys are sent.
- Delay: `{ action: "delay", minutes: 30|60, revision }` → `{ schedule, delay }`. 409 if already delayed tonight, schedule off, or the delay would pass wake time.

### Emergency Bypass

**GET `/emergency`** → `{ cycle_id, uses_left, active_until_ms, reset_at, server_managed: true, active_until, success: true }`.
**POST `/emergency`** → same, after activating: 15 minutes, 4 uses per week. 409 `BYPASS_ACTIVE`, 429 `BYPASS_EXHAUSTED`. (`/pro/emergency` is the same handler.)

### Study plans

**POST `/study-plan`** (Pro; 403 otherwise)
- `{ action: "validate", config, criteria, provider?, model?, key_version? }` → `{ id, score, passed, critique, suggested_rewrite }`. Valid 1 hour.
- `{ action: "authorize", config, criteria, audit: bool, plan_id, created_at, validation_id? }` → `{ authorized: true }`. Grant valid 7 days. 409 if criteria were not validated at 7/10 (when `audit` and strict validation are on) or the plan was authorized with different content.

**POST `/study-plan/manage`** `{ action: "delete"|"replan", plan_id, options? }`
- `delete` → `{ authorized: true, guarded, bypass: { uses_left, active_until, charged } | null }`. Costs 2 Emergency Bypass uses when any task is AI-protected (1 if a window is open). 429 `BYPASS_EXHAUSTED`.
- `replan` (Pro) → `{ authorized: true, tasks, scheduled, removed, days, end, bypass_used }`. 403 `REQUIREMENTS_LOCKED`, `STATUS_LOCKED`; 400 `INVALID_REPLAN`.
- Both grants last 10 minutes and are spent by the next push that matches exactly.

### Criteria edit

**POST `/criteria/edit`** `{ task_id, criteria, provider?, model?, key_version?, lang? }` → `{ score, passed, critique, suggested_rewrite, comparison, comparison_reason, allowed, override, reason, message, grant?: { proof_criteria, raw_proof_criteria, original_proof_criteria } }`. When `allowed`, write the three `grant` fields onto the task and push within 10 minutes. 404 task not synced; 409 task changed during review; 502 bad AI answer.

### Pro

**GET `/pro/status`**
- Pro: `{ isPro: true, tier, status: "active", plan: "pro", username, use_byok, byok_credit_limits: false, activated_at, cycle_anchor, expires_at, server_now, offline_token, policy_version, hosted_policy, themes: { allowed, default, catalog_version }, credits: { daily_limit, daily_used, daily_remaining, monthly_limit, monthly_used, monthly_remaining, monthly_period: "30-day", daily_resets_at, cycle_started_at, monthly_resets_at, reset_timezone } }`
- Not Pro: `{ isPro: false, tier, status: "inactive"|"expired"|"revoked"|…, plan: "free"|"restricted", username, use_byok: false, byok_credit_limits: true, limits: { state: "available"|"caution"|"critical", exhausted, metered, reset_timezone }, server_now, credits: null, themes }`

**POST `/pro/ai/quote`** — same body as review (below), plus `batch: true` for a batch → `{ quote_id, expires_at, input_tokens, max_output_tokens, estimated_credits, maximum_credits, estimated_credits_exact, maximum_credits_exact, tasks, model_used }`. Quote lasts 5 minutes. If the operation already finished: `{ completed: true, result }`.

**POST `/pro/ai/review`** (hosted, Pro, not in personal-key mode)
body `{ operation_id, quote_id, task_id, files: [{ mime_type, data: <base64> }] (1–5), test? }` → `{ success, verdict: "approved"|"rejected"|"incomplete", confidence, critique, is_pro, discount_applied, model_used, credits_charged, credits_exact, task_charges, operation_id, credits_remaining: { daily, monthly }, job_id }`.
The Worker takes title, criteria and exemplar from the synced task; anything the client sends for those is ignored.

**POST `/pro/ai/batch-review`** body `{ operation_id, quote_id, tasks: [{ id }] (1–20), files }` → `{ success, tasks: [{ task_id, status: "eligible"|"rejected"|"partial"|"uncertain", verdict, reason }], …, job_id }`.

**POST `/pro/ai/personal-review`** (personal key; batch needs Pro in personal-key mode) body as review without `quote_id`, plus `batch?` → `{ success, verdict…|tasks…, model_used, job_id }`.

**POST `/pro/ai/batch-confirm`** `{ job_id, task_ids, operation_id, batch: true|false }` → `{ success, job_id, confirmed_task_ids, version, replayed? }`. Then pull.

`operation_id` format: `op_<base36 ms timestamp>_<8–64 chars>`; valid 24 hours. Files: JPEG, PNG, WebP, PDF (HEIC for personal review only); photo ≤ 8 MiB, PDF ≤ 30 MiB, exemplar ≤ 5 MiB, total ≤ 40 MiB, request ≤ 56 MiB.

| Code | Status | Meaning |
|---|---|---|
| `PRO_REQUIRED` | 403 | Not Pro |
| `BYOK_ACTIVE` | 409 | Hosted review while personal-key mode is on |
| `LICENSE_PARAMETERS_INVALID` | 403 | License has no valid allowance |
| `SYNC_REQUIRED`, `TASK_CHANGED`, `CRITERIA_MISSING`, `REFERENCE_MISSING` | 409 | Sync first / task changed |
| `QUOTE_REQUIRED`, `AUDIT_PENDING`, `OPERATION_CONFLICT`, `OPERATION_EXPIRED` | 409 | Quote/operation state |
| `QUOTA_EXHAUSTED`, `HOSTED_SPEND_LIMIT`, `FREE_LIMIT_REACHED` | 429 | Out of credits |
| `PREVIEW_RATE_LIMIT`, `PREVIEW_RUNNING`, `PREVIEW_LIMIT`, `UPLOAD_BUSY` | 429 | Retry shortly |
| `INPUT_TOKEN_LIMIT`, `PAYLOAD_TOO_LARGE` | 413 | Too big |
| `UNSUPPORTED_MEDIA_TYPE` | 415 | Wrong file type |
| `AI_PROVIDER_ERROR` | 502 | Provider failed; nothing confirmed |
| `APPROVAL_INVALID`, `APPROVAL_EXPIRED`, `NO_ELIGIBLE_TASKS` | 403 | Confirm rejected |
| `APPROVAL_USED`, `CHILD_PROOF_REQUIRED`, `CHILDREN_REQUIRED` | 409 | Confirm rejected |
| `TEST_LOCKED`, `TEST_SINGLE_ONLY` | 409 / 400 | Criteria test rules |

Web-only, not for the app: `/pro/activate`, `/pro/byok`, `/ai/keys*`, `/pro/username*`, `/universe/*`.

### AI

**POST `/ai/generate`** `{ provider: "gemini"|"claude", model, key_version?, payload: { taskitatorFormat, contents, systemInstruction?, generationConfig } }` → a Gemini-shaped response `{ candidates: [{ content: { parts: [{ text }] }, finishReason }] }`.
- Pro (hosted): `provider`/`model` are ignored; the Worker uses its own model. `proof`/`batch-proof` formats are refused (409).
- Free: uses the saved personal key; metered. 409 if the provider changed; 429 limit reached or two requests already running; 504 timeout.
- Models allowed today: gemini `gemini-3.5-flash-lite`, `gemini-3.1-flash-lite`; claude `claude-haiku-5-5`.

**POST `/ai/provider`** `{ provider }` → provider metadata. 409 if no tested key is saved for that provider. In the app this only makes sense for an account with keys saved on the web.

**GET `/ai/keys`** returns key metadata plus `hosted: bool`. The app may read `hosted` and `selected_provider` from it but must not show key management. (The CI guard in Phase 1 bans the string `/ai/keys`; if the app needs `selected_provider`, add it to `/pro/status` instead.)
