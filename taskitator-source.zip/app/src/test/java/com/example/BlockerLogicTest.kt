package com.example

import com.example.blocker.BlockDecision
import com.example.blocker.BlockListRules
import com.example.blocker.BlockReason
import com.example.blocker.BlockVerdict
import com.example.blocker.BlockerApi
import com.example.blocker.BlockerSignals
import com.example.blocker.LockState
import com.example.blocker.StatusOutcome
import com.example.blocker.StatusRefreshPolicy
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BlockerLogicTest {
    private val blocked = setOf("com.game", "com.video")
    private val allowed = setOf("com.aistudio.taskitator.mvptsk", "com.android.settings", "com.launcher", "com.dialer")
    private val transient = setOf("com.android.systemui", "com.keyboard")
    private val lockedByTasks = LockState(deviceLocked = true, sleep = false)
    private val lockedBySleep = LockState(deviceLocked = false, sleep = true)
    private val unlocked = LockState(deviceLocked = false, sleep = false)

    private fun decide(pkg: String?, enabled: Boolean = true, state: LockState? = lockedByTasks, apps: Set<String> = blocked) =
        BlockDecision.decide(pkg, enabled, state, apps, allowed, transient)

    // --- decision ---

    @Test fun blocksChosenAppWhileTasksUnfinished() = assertEquals(BlockVerdict.BLOCK, decide("com.game"))
    @Test fun blocksChosenAppDuringSleepLock() = assertEquals(BlockVerdict.BLOCK, decide("com.game", state = lockedBySleep))
    @Test fun allowsChosenAppWhenUnlocked() = assertEquals(BlockVerdict.ALLOW, decide("com.game", state = unlocked))
    @Test fun allowsAppNotOnTheList() = assertEquals(BlockVerdict.ALLOW, decide("com.maps"))
    @Test fun allowsEverythingWhenSwitchedOff() = assertEquals(BlockVerdict.ALLOW, decide("com.game", enabled = false))
    @Test fun allowsWhenServerNeverAnswered() = assertEquals(BlockVerdict.ALLOW, decide("com.game", state = null))
    @Test fun ignoresMissingPackage() {
        assertEquals(BlockVerdict.IGNORE, decide(null))
        assertEquals(BlockVerdict.IGNORE, decide(""))
    }

    @Test fun neverBlocksProtectedAppsEvenIfListed() {
        val everything = blocked + allowed
        for (pkg in allowed) assertEquals(pkg, BlockVerdict.ALLOW, decide(pkg, apps = everything))
    }

    @Test fun keyboardAndSystemPanelsLeaveTheScreenAsItIs() {
        assertEquals(BlockVerdict.IGNORE, decide("com.keyboard"))
        assertEquals(BlockVerdict.IGNORE, decide("com.android.systemui"))
    }

    @Test fun keyboardHidesTheScreenOnceUnlocked() =
        assertEquals(BlockVerdict.ALLOW, decide("com.keyboard", state = unlocked))

    @Test fun deletedAccountNeverLocks() {
        val state = LockState(deviceLocked = true, sleep = true, accountDeleted = true)
        assertFalse(state.locked)
        assertEquals(BlockVerdict.ALLOW, decide("com.game", state = state))
    }

    @Test fun reasonNamesTasksBeforeSleep() {
        assertEquals(BlockReason.TASKS, BlockDecision.reason(lockedByTasks))
        assertEquals(BlockReason.TASKS, BlockDecision.reason(LockState(deviceLocked = true, sleep = true)))
        assertEquals(BlockReason.SLEEP, BlockDecision.reason(lockedBySleep))
        assertNull(BlockDecision.reason(unlocked))
        assertNull(BlockDecision.reason(null))
    }

    // --- /status parsing (shapes from docs/WORKER_CONTRACTS.md) ---

    @Test fun parsesLockedStatus() {
        val body = """{"status":"ok","device_locked":true,"finished":false,"in_break":false,"sleep_lock_active":false,"sleep":false}"""
        val outcome = StatusOutcome.fromHttp(200, body, 1234L) as StatusOutcome.Updated
        assertTrue(outcome.state.deviceLocked)
        assertFalse(outcome.state.sleep)
        assertTrue(outcome.state.locked)
        assertEquals(1234L, outcome.state.fetchedAtMs)
    }

    @Test fun parsesEmergencyBypassAsUnlocked() {
        val body = """{"status":"ok","device_locked":false,"sleep":false,"emergency_bypass":true}"""
        val state = (StatusOutcome.fromHttp(200, body, 1L) as StatusOutcome.Updated).state
        assertFalse(state.locked)
        assertTrue(state.emergencyBypass)
    }

    @Test fun parsesSleepOnly() {
        val body = """{"status":"ok","device_locked":false,"sleep":true,"sleep_lock_active":true}"""
        val state = (StatusOutcome.fromHttp(200, body, 1L) as StatusOutcome.Updated).state
        assertTrue(state.locked)
        assertEquals(BlockReason.SLEEP, BlockDecision.reason(state))
    }

    @Test fun parsesDeletedAccount() {
        val body = """{"status":"ok","device_locked":false,"sleep":false,"finished":true,"in_break":false,"account_deleted":true}"""
        val state = (StatusOutcome.fromHttp(200, body, 1L) as StatusOutcome.Updated).state
        assertTrue(state.accountDeleted)
        assertFalse(state.locked)
    }

    @Test fun revokedTokenIsReported() = assertTrue(StatusOutcome.fromHttp(401, """{"error":"x"}""", 1L) is StatusOutcome.TokenRejected)

    @Test fun failuresNeverUnlock() {
        // None of these produce a new state, so the last known lock stays in force.
        assertTrue(StatusOutcome.fromHttp(0, "", 1L) is StatusOutcome.Unavailable)
        assertTrue(StatusOutcome.fromHttp(503, """{"error":"busy"}""", 1L) is StatusOutcome.Unavailable)
        assertTrue(StatusOutcome.fromHttp(200, "<html>captive portal</html>", 1L) is StatusOutcome.Unavailable)
        assertTrue(StatusOutcome.fromHttp(200, """{"hello":"world"}""", 1L) is StatusOutcome.Unavailable)
        assertTrue(StatusOutcome.fromHttp(403, """{"error":"Account access denied."}""", 1L) is StatusOutcome.Unavailable)
    }

    @Test fun lockStateSurvivesSaveAndLoad() {
        val saved = LockState(deviceLocked = true, sleep = true, inBreak = false, emergencyBypass = false, fetchedAtMs = 99L)
        assertEquals(saved, LockState.fromSaved(saved.toJson().toString()))
        assertNull(LockState.fromSaved(null))
        assertNull(LockState.fromSaved(""))
        assertNull(LockState.fromSaved("not json"))
    }

    // --- loosening is refused while locked ---

    @Test fun cannotSwitchOffWhileLocked() =
        assertEquals(BlockListRules.REFUSED_OFF, BlockListRules.refusal(true, true, false, blocked, blocked))

    @Test fun cannotRemoveAppWhileLocked() =
        assertEquals(BlockListRules.REFUSED_REMOVE, BlockListRules.refusal(true, true, true, blocked, setOf("com.game")))

    @Test fun cannotSwapAppWhileLocked() =
        assertEquals(BlockListRules.REFUSED_REMOVE, BlockListRules.refusal(true, true, true, blocked, setOf("com.game", "com.other")))

    @Test fun canAddAppWhileLocked() = assertNull(BlockListRules.refusal(true, true, true, blocked, blocked + "com.social"))
    @Test fun canSwitchOnWhileLocked() = assertNull(BlockListRules.refusal(true, false, true, blocked, blocked))
    @Test fun canEditListWhileBlockerIsOff() = assertNull(BlockListRules.refusal(true, false, false, blocked, emptySet()))

    @Test fun anythingGoesWhenUnlocked() {
        assertNull(BlockListRules.refusal(false, true, false, blocked, blocked))
        assertNull(BlockListRules.refusal(false, true, true, blocked, emptySet()))
    }

    @Test fun signOutRefusedOnlyWhileLockedAndOn() {
        assertTrue(BlockListRules.signOutRefusal(true, true) != null)
        assertNull(BlockListRules.signOutRefusal(true, false))
        assertNull(BlockListRules.signOutRefusal(false, true))
    }

    // --- refresh timing ---

    @Test fun refreshIsRateLimited() {
        val t = 1_000_000L
        assertTrue(StatusRefreshPolicy.due(t, 0L, false, false))
        assertFalse(StatusRefreshPolicy.due(t + 14_999, t, false, false))
        assertTrue(StatusRefreshPolicy.due(t + 15_000, t, false, false))
        assertFalse(StatusRefreshPolicy.due(t + 20_000, t, true, false))
        assertTrue(StatusRefreshPolicy.due(t + 30_000, t, true, false))
        assertTrue("forced", StatusRefreshPolicy.due(t + 1, t, true, true))
        assertTrue("clock moved back", StatusRefreshPolicy.due(t - 5, t, false, false))
    }

    @Test fun lockChangingRoutesTriggerRefresh() {
        assertTrue(BlockerSignals.changesLock("/breaks", true))
        assertTrue(BlockerSignals.changesLock("/sleep-lock", true))
        assertTrue(BlockerSignals.changesLock("/emergency", true))
        assertFalse(BlockerSignals.changesLock("/emergency", false))
        assertFalse(BlockerSignals.changesLock("/pro/status", true))

        var calls = 0
        BlockerSignals.onRefreshRequested = { calls++ }
        BlockerSignals.requestRefresh()
        BlockerSignals.onRefreshRequested = { throw IllegalStateException("service gone") }
        BlockerSignals.requestRefresh() // must not crash the caller
        BlockerSignals.onRefreshRequested = null
        BlockerSignals.requestRefresh()
        assertEquals(1, calls)
    }

    // --- phone link ---

    @Test fun parsesNewPhoneToken() {
        val token = "tkp_" + "a".repeat(64)
        val body = JSONObject().put("success", true).put("token", token)
            .put("device", JSONObject().put("id", "dev_0123456789abcdef").put("label", "App: Pixel")).toString()
        val device = BlockerApi.parseDevice(200, body).getOrThrow()
        assertEquals(token, device.token)
        assertEquals("dev_0123456789abcdef", device.id)
    }

    @Test fun phoneLimitAndBadAnswersFail() {
        assertTrue(BlockerApi.parseDevice(409, """{"error":"limit"}""").exceptionOrNull()!!.message!!.contains("phone limit"))
        assertTrue(BlockerApi.parseDevice(200, """{"success":true}""").isFailure)
        assertTrue(BlockerApi.parseDevice(200, """{"token":"not-a-phone-token"}""").isFailure)
        assertTrue(BlockerApi.parseDevice(0, "").isFailure)
    }
}
