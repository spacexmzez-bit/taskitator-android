package com.example

import com.example.data.model.*
import com.example.data.util.TaskOrdering
import org.junit.Assert.*
import org.junit.Test

class Phase1WorkspaceContractTest {
    @Test fun inboxIsDefaultProject() {
        assertEquals("inbox", Task(title = "New task").projectId)
        assertEquals("inbox", TaskProject("inbox", "Inbox", isDefault = true).id)
    }

    @Test fun taskSortingUsesPriorityRanksAndIsStable() {
        val tasks = listOf(Task(id = "a", title = "B", priorityId = "prio_low"),
            Task(id = "b", title = "A", priorityId = "prio_high"))
        assertEquals(listOf("b", "a"), TaskOrdering.sort(tasks, DEFAULT_PRIORITIES, "priority").map { it.id })
        assertEquals(listOf("b", "a"), TaskOrdering.sort(tasks, DEFAULT_PRIORITIES, "alphabetical").map { it.id })
    }
}
