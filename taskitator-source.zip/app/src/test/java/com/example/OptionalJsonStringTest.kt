package com.example

import com.example.data.util.optionalJsonString
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OptionalJsonStringTest {
    @Test fun parentIdsHandleNullAndExistingParents() {
        assertNull(optionalJsonString(JSONObject("{\"parent_id\":null}"), "parent_id"))
        assertNull(optionalJsonString(JSONObject(), "parent_id"))
        assertNull(optionalJsonString(JSONObject("{\"parent_id\":\"\"}"), "parent_id"))
        assertEquals("parent-1", optionalJsonString(JSONObject("{\"parent_id\":\"parent-1\"}"), "parent_id"))
    }
}
