package com.example

import com.example.data.sync.AccountPaths
import com.example.data.sync.SnapshotStore
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files

class SnapshotStoreTest {
    private fun tempDir(): File = Files.createTempDirectory("taskitator-test").toFile().apply { deleteOnExit() }

    @Test
    fun eachAccountGetsItsOwnFiles() {
        assertEquals("taskitator_clerk_user_alice123_snapshot.json", AccountPaths.snapshot("clerk:user_alice123"))
        assertNotEquals(AccountPaths.snapshot("clerk:user_alice123"), AccountPaths.snapshot("clerk:user_bob456"))
        assertEquals("taskitator_anonymous_snapshot.json", AccountPaths.snapshot(""))
        // A user id can never escape the app's files folder.
        assertFalse(AccountPaths.snapshot("../../etc/passwd").contains("/"))
    }

    @Test
    fun oneAccountCannotReadAnothersSnapshot() {
        val dir = tempDir()
        SnapshotStore(dir, "clerk:alice").save(JSONObject().put("tasks", "alice data"))

        assertNull(SnapshotStore(dir, "clerk:bob").load())
        assertEquals("alice data", SnapshotStore(dir, "clerk:alice").load()!!.getString("tasks"))
    }

    @Test
    fun aSavedEditSurvivesAReload() {
        val dir = tempDir()
        SnapshotStore(dir, "u").save(JSONObject().put("version", 3).put("title", "Edited offline"))

        val reloaded = SnapshotStore(dir, "u").load()!!
        assertEquals("Edited offline", reloaded.getString("title"))
        assertEquals(3, reloaded.getInt("version"))
    }

    @Test
    fun aCorruptSnapshotIsRestoredFromTheRecoveryCopy() {
        val dir = tempDir()
        val store = SnapshotStore(dir, "u")
        store.save(JSONObject().put("title", "good 1"))
        store.save(JSONObject().put("title", "good 2"))   // "good 1" becomes the recovery copy
        store.snapshotFile.writeText("""{"title": "cut off""")

        assertEquals("good 1", store.load()!!.getString("title"))
        // The main file is repaired, so the next load does not depend on the recovery copy.
        assertEquals("good 1", JSONObject(store.snapshotFile.readText()).getString("title"))
    }

    @Test
    fun aCorruptSnapshotIsNeverCopiedOverTheRecoveryCopy() {
        val dir = tempDir()
        val store = SnapshotStore(dir, "u")
        store.save(JSONObject().put("title", "good 1"))
        store.save(JSONObject().put("title", "good 2"))
        store.snapshotFile.writeText("garbage")
        store.save(JSONObject().put("title", "good 3"))

        assertEquals("good 1", JSONObject(store.recoveryFile.readText()).getString("title"))
        assertEquals("good 3", store.load()!!.getString("title"))
    }

    @Test
    fun nothingSavedMeansNothingLoaded() {
        val store = SnapshotStore(tempDir(), "u")
        assertNull(store.load())
        assertNull(store.loadBase())
    }

    @Test
    fun theBaseCopyIsStoredSeparately() {
        val store = SnapshotStore(tempDir(), "u")
        store.save(JSONObject().put("title", "local"))
        store.saveBase(JSONObject().put("title", "cloud"))

        assertEquals("cloud", store.loadBase()!!.getString("title"))
        assertEquals("local", store.load()!!.getString("title"))
    }
}
