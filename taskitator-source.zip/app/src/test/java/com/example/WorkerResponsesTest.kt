package com.example

import com.example.data.network.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Response shapes are the ones in docs/WORKER_CONTRACTS.md. */
class WorkerResponsesTest {

    // --- /auth/me ---

    @Test
    fun authMeReadsTheLinkedAccount() {
        val me = AuthMe.parse(JSONObject("""{"account":{"user":"clerk:abc","display_name":"Maz","user_id":"user_2t19","username":"focus"}}"""))
        assertTrue(me.linked)
        assertEquals("clerk:abc", me.workerUser)
        assertEquals("focus", me.username)
        assertEquals("user_2t19", me.clerkUserId)
        assertFalse(me.deletionPending)
    }

    @Test
    fun authMeFallsBackToTheDisplayName() {
        val me = AuthMe.parse(JSONObject("""{"account":{"user":"clerk:abc","display_name":"Maz","user_id":"user_2t19"}}"""))
        assertEquals("Maz", me.username)
    }

    @Test
    fun authMeWithoutAnAccountIsNotLinked() {
        val me = AuthMe.parse(JSONObject("""{"account":null}"""))
        assertFalse(me.linked)
        assertFalse(me.deletionPending)
    }

    @Test
    fun authMeReportsAPendingDeletion() {
        val me = AuthMe.parse(JSONObject("""{"account":null,"deletion":{"status":"pending","receipt":"r"}}"""))
        assertFalse(me.linked)
        assertTrue(me.deletionPending)
    }

    // --- /pro/status ---

    @Test
    fun websiteOnlyProIsFreeInsideTheApp() {
        val status = ProStatus.parse(JSONObject("""{"isPro":true,"status":"active","plan":"pro","use_byok":true}"""))
        assertFalse(status.appPro)
        assertFalse(status.personalKeyMode)
    }

    @Test
    fun proForTheAppComesOnlyFromTheAppEntitlement() {
        assertTrue(ProStatus.parse(JSONObject("""{"isPro":true,"entitlements":{"web":true,"app":true}}""")).appPro)
        assertFalse(ProStatus.parse(JSONObject("""{"isPro":true,"entitlements":{"web":true,"app":false}}""")).appPro)
        assertFalse(ProStatus.parse(JSONObject("""{"isPro":false}""")).appPro)
    }

    @Test
    fun personalKeyModeIsReadFromTheWorker() {
        val status = ProStatus.parse(JSONObject("""{"entitlements":{"app":true},"use_byok":true}"""))
        assertTrue(status.appPro)
        assertTrue(status.personalKeyMode)
    }

    // --- /emergency ---

    @Test
    fun emergencyStateComesFromTheWorker() {
        val state = EmergencyState.parse(JSONObject("""{"cycle_id":"server-2026-11-09","uses_left":3,"active_until_ms":1000,"reset_at":5000,"server_managed":true}"""))
        assertEquals(3, state.usesLeft)
        assertEquals(1000L, state.activeUntilMs)
        assertEquals(5000L, state.resetAtMs)
        assertTrue(state.isActive(nowMs = 999))
        assertFalse(state.isActive(nowMs = 1000))
    }

    @Test
    fun anEmptyEmergencyAnswerGrantsNothing() {
        val state = EmergencyState.parse(JSONObject())
        assertEquals(0, state.usesLeft)
        assertFalse(state.isActive(nowMs = 0))
    }

    // --- /pro/ai/batch-confirm ---

    @Test
    fun auditConfirmBodyMatchesTheWebsite() {
        val body = AuditConfirm.body("job_1", listOf("task_9"), "confirm_x", batch = false)
        assertEquals("job_1", body.getString("job_id"))
        assertEquals("task_9", body.getJSONArray("task_ids").getString(0))
        assertEquals(1, body.getJSONArray("task_ids").length())
        assertEquals("confirm_x", body.getString("operation_id"))
        assertFalse(body.getBoolean("batch"))
        assertEquals(4, body.length())
    }

    // --- error mapping ---

    @Test
    fun workerStatusCodesMapToTypedErrors() {
        assertTrue(WorkerErrors.forStatus(401) is UnauthorizedException)
        assertTrue(WorkerErrors.forStatus(403, """{"error":"Protected task"}""") is WorkerProtectionException)
        assertTrue(WorkerErrors.forStatus(410) is AccountDeletedException)
        assertTrue(WorkerErrors.forStatus(428) is PreconditionRequiredException)
        assertTrue(WorkerErrors.forStatus(429) is RateLimitException)
        assertTrue(WorkerErrors.forStatus(503) is ServiceUnavailableException)
        assertEquals("HTTP 500: boom", WorkerErrors.forStatus(500, """{"error":"boom"}""").message)
    }

    @Test
    fun onlyAVersionConflictStartsAMerge() {
        assertTrue(WorkerErrors.forStatus(409, """{"error":"Conflict","conflict":true,"remote_version":8}""") is SyncConflictException)
        // A 409 without "conflict": the Worker refused the change (for example a Smart Study rule).
        val refused = WorkerErrors.forStatus(409, """{"error":"Smart Study task changed"}""")
        assertTrue(refused is WorkerProtectionException)
        assertTrue(refused.message!!.contains("Smart Study task changed"))
        assertTrue(WorkerErrors.forStatus(409, "not json") is WorkerProtectionException)
    }

    @Test
    fun theWorkersErrorTextIsShown() {
        assertEquals("Protected task", WorkerErrors.message("""{"error":"Protected task","code":"X"}"""))
        assertEquals("plain text", WorkerErrors.message("plain text"))
    }
}
