package com.example

import com.example.data.auth.AccountDeletionRules
import com.example.data.auth.DeletionNotice
import com.example.data.network.SessionTokens
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.startCoroutine

class AccountAuthTest {
    /** Runs a suspend block that never actually suspends. */
    private fun <T> run(block: suspend () -> T): T {
        var out: Result<T>? = null
        block.startCoroutine(object : Continuation<T> {
            override val context = EmptyCoroutineContext
            override fun resumeWith(result: Result<T>) { out = result }
        })
        return out!!.getOrThrow()
    }

    @After fun reset() { SessionTokens.source = null }

    // --- fresh session tokens ---

    @Test fun usesTheSuppliedTokenInsteadOfTheStoredOne() {
        SessionTokens.source = { "fresh" }
        assertEquals("fresh", run { SessionTokens.fresh("stale") })
    }

    @Test fun signedOutNeverFetchesAToken() {
        var asked = false
        SessionTokens.source = { asked = true; "fresh" }
        assertEquals("", run { SessionTokens.fresh("") })
        assertFalse(asked)
    }

    @Test fun phoneTokensAreLeftAlone() {
        SessionTokens.source = { "fresh" }
        assertEquals("tkp_abc", run { SessionTokens.fresh("tkp_abc") })
    }

    @Test fun fallsBackWhenNoFreshTokenIsAvailable() {
        assertEquals("stale", run { SessionTokens.fresh("stale") })
        SessionTokens.source = { null }
        assertEquals("stale", run { SessionTokens.fresh("stale") })
        SessionTokens.source = { "" }
        assertEquals("stale", run { SessionTokens.fresh("stale") })
        SessionTokens.source = { throw IllegalStateException("offline") }
        assertEquals("stale", run { SessionTokens.fresh("stale") })
    }

    // --- account deletion ---

    @Test fun deletionIsRefusedUntilEverythingIsConfirmed() {
        val ok = AccountDeletionRules.PHRASE
        assertNull(AccountDeletionRules.refusal(ok, true, false, false))
        assertTrue(AccountDeletionRules.refusal(ok, true, true, true)!!.contains("locked"))
        assertTrue(AccountDeletionRules.refusal(ok, true, true, false)!!.contains("Turn off"))
        assertTrue(AccountDeletionRules.refusal(ok, false, false, false)!!.contains("Confirm"))
        assertTrue(AccountDeletionRules.refusal("delete my account", true, false, false)!!.contains(ok))
        assertTrue(AccountDeletionRules.refusal("", true, false, false) != null)
        // A lock reported while the blocker is off on this phone does not stop deletion.
        assertNull(AccountDeletionRules.refusal(ok, true, false, true))
    }

    @Test fun receiptIs64LowercaseHexAndUnique() {
        val a = AccountDeletionRules.newReceipt()
        val b = AccountDeletionRules.newReceipt()
        assertTrue(Regex("^[a-f0-9]{64}$").matches(a))
        assertTrue(AccountDeletionRules.isReceipt(a))
        assertNotEquals(a, b)
        assertFalse(AccountDeletionRules.isReceipt("A".repeat(64)))
        assertFalse(AccountDeletionRules.isReceipt("a".repeat(63)))
    }

    @Test fun requestBodiesMatchTheWorkerContract() {
        val start = AccountDeletionRules.startBody()
        assertEquals("signin", start.getString("method"))
        assertEquals("delete-account", start.getString("action"))

        val receipt = "c".repeat(64)
        val body = AccountDeletionRules.deleteBody("v".repeat(64), receipt)
        assertEquals(true, body.getBoolean("blocker_disabled"))
        assertEquals("Delete my account", body.getString("phrase"))
        assertEquals(receipt, body.getString("receipt"))
        assertEquals("v".repeat(64), body.getString("verification_id"))
        // Android's JSONObject has no keySet(); compare through keys().
        val keys = body.keys().asSequence().toSet()
        assertEquals(setOf("blocker_disabled", "phrase", "receipt", "verification_id"), keys)

        val confirm = AccountDeletionRules.confirmBody("v".repeat(64))
        assertEquals(setOf("verification_id", "action"), confirm.keys().asSequence().toSet())
        assertEquals("delete-account", confirm.getString("action"))
        assertEquals("/auth/verification/signin", AccountDeletionRules.CONFIRM_PATH)

        assertEquals(receipt, AccountDeletionRules.statusBody(receipt).getString("receipt"))
    }

    @Test fun parsesTheAcceptedAnswer() {
        val receipt = "d".repeat(64)
        val json = JSONObject("""{"accepted":true,"receipt":"$receipt","status":"pending","phone_recovery_until":1700000000000}""")
        val notice = DeletionNotice.parse(json, receipt)!!
        assertEquals(receipt, notice.receipt)
        assertEquals("pending", notice.status)
        assertFalse(notice.complete)
        assertEquals(1700000000000L, notice.phoneRecoveryUntilMs)
    }

    @Test fun parsesTheStatusAnswerWhichHasNoReceipt() {
        val receipt = "e".repeat(64)
        val json = JSONObject("""{"accepted":true,"status":"complete","complete":true,"accepted_at":1,"completed_at":2,"phone_recovery_until":3}""")
        val notice = DeletionNotice.parse(json, receipt)!!
        assertEquals(receipt, notice.receipt)
        assertTrue(notice.complete)
        assertTrue(notice.statusText.contains("deleted"))
    }

    @Test fun anErrorBodyIsNotAnAcceptedDeletion() {
        assertNull(DeletionNotice.parse(JSONObject("""{"error":"Verification expired"}"""), "f".repeat(64)))
        assertNull(DeletionNotice.parse(JSONObject("""{"accepted":false,"status":"pending"}"""), "f".repeat(64)))
        assertNull(DeletionNotice.parse(JSONObject("""{"accepted":true,"status":"pending"}"""), "not-a-receipt"))
    }

    @Test fun noticeSurvivesSaveAndLoad() {
        val notice = DeletionNotice("a".repeat(64), "retrying", false, 42L)
        assertEquals(notice, DeletionNotice.fromSaved(notice.toJson().toString()))
        assertNull(DeletionNotice.fromSaved(null))
        assertNull(DeletionNotice.fromSaved("{}"))
        assertNull(DeletionNotice.fromSaved("not json"))
    }
}
