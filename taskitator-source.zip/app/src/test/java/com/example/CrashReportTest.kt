package com.example

import com.example.data.util.CrashReport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.file.Files

class CrashReportTest {
    @Test fun reportNamesTheErrorAndThread() {
        val text = CrashReport.format(IllegalStateException("boom"), "main", 123L)
        assertTrue(text.contains("IllegalStateException"))
        assertTrue(text.contains("boom"))
        assertTrue(text.contains("Thread: main"))
        assertTrue(text.contains("CrashReportTest"))
    }

    @Test fun tokensNeverReachTheFile() {
        val jwt = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1c2VyXzEifQ.c2lnbmF0dXJl"
        val phone = "tkp_" + "a1".repeat(32)
        val text = CrashReport.format(RuntimeException("failed with $jwt and $phone"), "t", 1L)
        assertFalse(text.contains("eyJ"))
        assertFalse(text.contains("tkp_a1"))
        assertTrue(text.contains("[token]"))
    }

    @Test fun reportIsCapped() {
        val text = CrashReport.format(RuntimeException("x".repeat(50_000)), "t", 1L)
        assertTrue(text.length <= 8000)
    }

    @Test fun saveLoadClear() {
        val dir = Files.createTempDirectory("crash").toFile()
        assertNull(CrashReport.load(dir))
        CrashReport.save(dir, "first")
        CrashReport.save(dir, "second")
        assertEquals("second", CrashReport.load(dir))
        CrashReport.clear(dir)
        assertNull(CrashReport.load(dir))
        CrashReport.clear(dir) // clearing nothing is fine
    }
}
