package com.example

import com.example.data.sync.SyncDecision
import com.example.data.sync.SyncStep
import org.junit.Assert.assertEquals
import org.junit.Test

class SyncDecisionTest {
    @Test
    fun withoutATokenNothingSyncs() {
        assertEquals(SyncStep.SIGNED_OUT, SyncDecision.next(hasToken = false, inProgress = false, needsInitialPull = true, dirty = true))
    }

    @Test
    fun aRunningSyncBlocksASecondOne() {
        assertEquals(SyncStep.BUSY, SyncDecision.next(hasToken = true, inProgress = true, needsInitialPull = false, dirty = true))
    }

    @Test
    fun aFreshInstallPullsBeforeItMayPush() {
        // Even with local edits: an empty local store must never overwrite the cloud.
        assertEquals(SyncStep.PULL, SyncDecision.next(hasToken = true, inProgress = false, needsInitialPull = true, dirty = true))
        assertEquals(SyncStep.PULL, SyncDecision.next(hasToken = true, inProgress = false, needsInitialPull = true, dirty = false))
    }

    @Test
    fun withoutLocalEditsItOnlyPulls() {
        assertEquals(SyncStep.PULL, SyncDecision.next(hasToken = true, inProgress = false, needsInitialPull = false, dirty = false))
    }

    @Test
    fun localEditsAfterTheFirstPullArePushed() {
        assertEquals(SyncStep.PUSH, SyncDecision.next(hasToken = true, inProgress = false, needsInitialPull = false, dirty = true))
    }
}
