package com.example

import com.example.data.network.TaskitatorWorkerApi
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PushPayloadTest {
    private val cloud = """
        {
            "app": "taskitator",
            "version": 9,
            "unknown_web_flag": true,
            "universe_groups": [{"id": "grp_1"}],
            "recurrence_state": {"schema_version": 2, "study_plans": [{"plan_id": "sp_1"}]},
            "completed_audit_ledger": [{"job_id": "job_123"}],
            "tasks": [
                {"id": "t1", "title": "Read", "dynamic_priority_target": "prio_high",
                 "nested_unknown": {"score": 99}, "smart_study_tag": "KEEP"}
            ]
        }
    """.trimIndent()

    @Test
    fun versionAndMutationIdSitAtTheTopLevel() {
        val payload = TaskitatorWorkerApi.createPushPayload(JSONObject(cloud), 9L, "mutation-12345")
        assertEquals(9L, payload.getLong("base_version"))
        assertEquals("mutation-12345", payload.getString("mutation_id"))
        assertFalse(payload.has("payload"))
        assertEquals("taskitator", payload.getString("app"))
    }

    @Test
    fun schemaFlagsAreAlwaysSent() {
        // Without these the Worker answers 428 for accounts that use recurrence or Dynamic Priority.
        val payload = TaskitatorWorkerApi.createPushPayload(JSONObject("""{"tasks":[]}"""), 1L, "mutation-12345")
        assertEquals(1, payload.getInt("recurrence_schema"))
        assertEquals(1, payload.getInt("dynamic_priority_schema"))
    }

    @Test
    fun dataTheAppDoesNotUnderstandIsSentBackUnchanged() {
        val payload = TaskitatorWorkerApi.createPushPayload(JSONObject(cloud), 9L, "mutation-12345")
        val task = payload.getJSONArray("tasks").getJSONObject(0)
        assertEquals("prio_high", task.getString("dynamic_priority_target"))
        assertEquals(99, task.getJSONObject("nested_unknown").getInt("score"))
        assertEquals("KEEP", task.getString("smart_study_tag"))
        assertTrue(payload.getBoolean("unknown_web_flag"))
        assertEquals(1, payload.getJSONArray("universe_groups").length())
        assertEquals(2, payload.getJSONObject("recurrence_state").getInt("schema_version"))
        assertEquals("job_123", payload.getJSONArray("completed_audit_ledger").getJSONObject(0).getString("job_id"))
    }

    @Test
    fun buildingAPayloadDoesNotChangeTheLocalSnapshot() {
        val snapshot = JSONObject(cloud)
        val before = snapshot.toString()
        TaskitatorWorkerApi.createPushPayload(snapshot, 9L, "mutation-12345")
        assertEquals(before, snapshot.toString())
    }

    @Test
    fun aRetryCarriesTheSameMutationId() {
        val first = TaskitatorWorkerApi.createPushPayload(JSONObject(cloud), 9L, "mutation-12345")
        val retry = TaskitatorWorkerApi.createPushPayload(JSONObject(cloud), 9L, "mutation-12345")
        assertEquals(first.toString(), retry.toString())
    }
}
