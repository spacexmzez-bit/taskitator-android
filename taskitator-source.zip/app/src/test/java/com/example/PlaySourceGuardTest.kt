package com.example

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Fails the build if the app's source mentions website-only purchase or key paths.
 * The Play build must contain none of them.
 */
class PlaySourceGuardTest {
    private val banned = listOf("keyo", "license key", "/pro/activate", "/pro/byok", "/ai/keys")

    private fun mainSourceDir(): File = listOf(File("src/main"), File("app/src/main"))
        .firstOrNull { it.isDirectory }
        ?: throw AssertionError("Cannot find src/main from ${File(".").absolutePath}")

    @Test
    fun appSourceHasNoWebsiteOnlyPurchaseOrKeyPaths() {
        val textFiles = setOf("kt", "java", "xml", "json", "txt", "html", "md", "properties")
        val files = mainSourceDir().walkTopDown().filter { it.isFile && it.extension.lowercase() in textFiles }.toList()
        assertTrue("No source files found to check", files.size > 20)

        val hits = mutableListOf<String>()
        for (file in files) {
            file.readLines().forEachIndexed { index, line ->
                val lower = line.lowercase()
                banned.filter { it in lower }.forEach { hits.add("${file.path}:${index + 1} contains \"$it\"") }
            }
        }
        assertTrue("Banned text found in app source:\n" + hits.joinToString("\n"), hits.isEmpty())
    }
}
