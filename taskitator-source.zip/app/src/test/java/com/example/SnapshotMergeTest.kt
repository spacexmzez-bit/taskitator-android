package com.example

import com.example.data.sync.SnapshotMerge
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class SnapshotMergeTest {
    private fun obj(json: String) = JSONObject(json)

    @Test fun disjointTaskEditsMergeWithoutLosingUnknownFields() {
        val base = obj("""{"username":"clerk:test","tasks":[{"id":"1","title":"Old","description":"Old","opaque":{"x":3}}]}""")
        val local = obj("""{"username":"clerk:test","tasks":[{"id":"1","title":"Local","description":"Old","opaque":{"x":3}}]}""")
        val remote = obj("""{"username":"clerk:test","tasks":[{"id":"1","title":"Old","description":"Remote","opaque":{"x":3},"web_only":true}]}""")
        val outcome = SnapshotMerge.merge(base, local, remote)
        assertTrue(outcome.issues.toString(), outcome.issues.isEmpty())
        val task = outcome.merged.getJSONArray("tasks").getJSONObject(0)
        assertEquals("Local", task.getString("title"))
        assertEquals("Remote", task.getString("description"))
        assertTrue(task.getBoolean("web_only"))
        assertEquals(3, task.getJSONObject("opaque").getInt("x"))
    }

    @Test fun sameFieldConflictCannotAutoOverwrite() {
        val base = obj("""{"tasks":[{"id":"1","title":"Base"}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Android"}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"Web"}]}""")
        val outcome = SnapshotMerge.merge(base, local, remote)
        assertEquals("1", outcome.issues.single().id)
        assertEquals("title", outcome.issues.single().fields.single())
    }

    @Test fun deletingFieldOnOneSideDoesNotCrash() {
        val base = obj("""{"tasks":[{"id":"1","title":"Base","description":"Old"}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Base"}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"Web","description":"Old"}]}""")
        val result = SnapshotMerge.merge(base, local, remote)
        assertTrue(result.issues.toString(), result.issues.isEmpty())
        val task = result.merged.getJSONArray("tasks").getJSONObject(0)
        assertFalse(task.has("description"))
        assertEquals("Web", task.getString("title"))
    }

    @Test fun rootServerOwnedMutationIsRejected() {
        val base = obj("""{"tasks":[],"today_breaks":{"locked":true}}""")
        val local = obj("""{"tasks":[],"today_breaks":{"locked":false}}""")
        val remote = obj("""{"tasks":[],"today_breaks":{"locked":true}}""")
        assertEquals("__snapshot__", SnapshotMerge.merge(base, local, remote).issues.single().id)
    }

    @Test fun localEditToProtectedTaskFieldCannotOverrideCloud() {
        val base = obj("""{"tasks":[{"id":"1","title":"X","ai_locked":true}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"X","ai_locked":false}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"X","ai_locked":true}]}""")
        assertTrue(SnapshotMerge.merge(base, local, remote).issues.any { "ai_locked" in it.fields })
    }

    @Test fun remoteDeleteVersusLocalEditIsConflict() {
        val base = obj("""{"tasks":[{"id":"1","title":"Old"}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Edited"}]}""")
        val remote = obj("""{"tasks":[]}""")
        assertEquals("delete_vs_edit", SnapshotMerge.merge(base, local, remote).issues.single().fields.single())
    }

    @Test fun conflictResolutionKeepsUnrelatedRemoteField() {
        val base = obj("""{"tasks":[{"id":"1","title":"Base","description":"Base"}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Local","description":"Base"}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"Remote","description":"Web"}]}""")
        val resolved = SnapshotMerge.merge(base, local, remote, setOf("1"))
        assertTrue(resolved.issues.toString(), resolved.issues.isEmpty())
        val task = resolved.merged.getJSONArray("tasks").getJSONObject(0)
        assertEquals("Local", task.getString("title"))
        assertEquals("Web", task.getString("description"))
    }

    @Test fun noOpIgnoresTransportMetadata() {
        val base = obj("""{"version":5,"updated_at":"old","tasks":[],"settings":{}}""")
        val local = obj("""{"version":6,"updated_at":"new","tasks":[],"settings":{}}""")
        assertFalse(SnapshotMerge.hasLocalEdits(base, local))
    }
}
