package com.example

import com.example.data.sync.SnapshotMerge
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class SnapshotMergeTest {
    private fun obj(json: String) = JSONObject(json)

    @Test fun disjointTaskEditsMergeWithoutLosingUnknownFields() {
        val base = obj("""{"username":"clerk:test","tasks":[{"id":"1","title":"Old","description":"Old","opaque":{"x":3}}]}""")
        val local = obj("""{"username":"clerk:test","tasks":[{"id":"1","title":"Local","description":"Old","opaque":{"x":3}}]}""")
        val remote = obj("""{"username":"clerk:test","tasks":[{"id":"1","title":"Old","description":"Remote","opaque":{"x":3},"web_only":true}]}""")
        val outcome = SnapshotMerge.merge(base, local, remote)
        assertTrue(outcome.issues.toString(), outcome.issues.isEmpty())
        val task = outcome.merged.getJSONArray("tasks").getJSONObject(0)
        assertEquals("Local", task.getString("title"))
        assertEquals("Remote", task.getString("description"))
        assertTrue(task.getBoolean("web_only"))
        assertEquals(3, task.getJSONObject("opaque").getInt("x"))
    }

    @Test fun sameFieldConflictCannotAutoOverwrite() {
        val base = obj("""{"tasks":[{"id":"1","title":"Base"}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Android"}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"Web"}]}""")
        val outcome = SnapshotMerge.merge(base, local, remote)
        assertEquals("1", outcome.issues.single().id)
        assertEquals("title", outcome.issues.single().fields.single())
    }

    @Test fun deletingFieldOnOneSideDoesNotCrash() {
        val base = obj("""{"tasks":[{"id":"1","title":"Base","description":"Old"}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Base"}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"Web","description":"Old"}]}""")
        val result = SnapshotMerge.merge(base, local, remote)
        assertTrue(result.issues.toString(), result.issues.isEmpty())
        val task = result.merged.getJSONArray("tasks").getJSONObject(0)
        assertFalse(task.has("description"))
        assertEquals("Web", task.getString("title"))
    }

    @Test fun rootServerOwnedMutationIsIgnoredAndCloudWins() {
        val base = obj("""{"tasks":[],"today_breaks":{"locked":true}}""")
        val local = obj("""{"tasks":[],"today_breaks":{"locked":false}}""")
        val remote = obj("""{"tasks":[],"today_breaks":{"locked":true}}""")
        val outcome = SnapshotMerge.merge(base, local, remote)
        assertTrue(outcome.issues.toString(), outcome.issues.isEmpty())
        assertTrue(outcome.merged.getJSONObject("today_breaks").getBoolean("locked"))
        assertTrue("today_breaks" in outcome.serverOwnedOverrides)
    }

    private val web = """{"app":"taskitator","username":"u","version":7,"tasks":[{"id":"1","title":"A"}],
        "projects":[{"id":"p1"}],"recurrence_state":{"series":[]},"today_breaks":{"mode":"flexible"},
        "completed_audit_ledger":[{"id":"x"}],"dynamic_priority_schema":1,"last_login":111,
        "settings":{"worker_url":"https://w","auto_page_refresh":true,"custom_tags":["a"],"day_start_hour":4},"saved_criteria":[]}"""
    private val androidDefault = """{"app":"taskitator","username":"u","updated_at":1,"force":false,"recurrence_state":{},
        "recurrence_schema":1,"tasks":[],"projects":[],"settings":{},"today_breaks":{},"completed_audit_ledger":[],
        "saved_criteria":[],"last_login":222}"""

    @Test fun androidDefaultShapeAgainstWebsiteSnapshotRaisesNoSnapshotConflict() {
        val local = obj(androidDefault).apply { put("last_login", 333) }
        val outcome = SnapshotMerge.merge(obj(androidDefault), local, obj(web))
        assertTrue(outcome.issues.toString(), outcome.issues.isEmpty())
        // Website fields are preserved untouched.
        assertEquals(1, outcome.merged.getJSONArray("projects").length())
        assertEquals(1, outcome.merged.getInt("dynamic_priority_schema"))
        assertEquals("https://w", outcome.merged.getJSONObject("settings").getString("worker_url"))
    }

    @Test fun websiteManagedSettingsNeverConflict() {
        val local = obj(web).apply { getJSONObject("settings").put("custom_tags", org.json.JSONArray().put("a").put("b")).put("worker_url", "x") }
        val outcome = SnapshotMerge.merge(obj(web), local, obj(web))
        assertTrue(outcome.issues.toString(), outcome.issues.isEmpty())
        assertEquals(1, outcome.merged.getJSONObject("settings").getJSONArray("custom_tags").length())
    }

    @Test fun deviceEditableSettingConflictResolvesByChoice() {
        val base = obj("""{"tasks":[],"settings":{"copilot_name":"Ari"}}""")
        val local = obj("""{"tasks":[],"settings":{"copilot_name":"Local"}}""")
        val remote = obj("""{"tasks":[],"settings":{"copilot_name":"Web"}}""")
        val unresolved = SnapshotMerge.merge(base, local, remote)
        assertEquals("__snapshot__", unresolved.issues.single().id)
        val keepLocal = SnapshotMerge.merge(base, local, remote, preferLocal = setOf("__snapshot__"))
        assertTrue(keepLocal.issues.isEmpty())
        assertEquals("Local", keepLocal.merged.getJSONObject("settings").getString("copilot_name"))
        val keepCloud = SnapshotMerge.merge(base, local, remote, preferLocal = emptySet())
        assertTrue(keepCloud.issues.isEmpty())
        assertEquals("Web", keepCloud.merged.getJSONObject("settings").getString("copilot_name"))
    }

    @Test fun protectedTaskFieldWithExplicitChoiceKeepsCloudValue() {
        val base = obj("""{"tasks":[{"id":"1","title":"X","ai_locked":true}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Y","ai_locked":false}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"X","ai_locked":true}]}""")
        val outcome = SnapshotMerge.merge(base, local, remote, preferLocal = setOf("1"))
        assertTrue(outcome.issues.isEmpty())
        val t = outcome.merged.getJSONArray("tasks").getJSONObject(0)
        assertEquals("Y", t.getString("title"))
        assertTrue(t.getBoolean("ai_locked"))
    }

    @Test fun localEditToProtectedTaskFieldCannotOverrideCloud() {
        val base = obj("""{"tasks":[{"id":"1","title":"X","ai_locked":true}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"X","ai_locked":false}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"X","ai_locked":true}]}""")
        assertTrue(SnapshotMerge.merge(base, local, remote).issues.any { "ai_locked" in it.fields })
    }

    @Test fun remoteDeleteVersusLocalEditIsConflict() {
        val base = obj("""{"tasks":[{"id":"1","title":"Old"}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Edited"}]}""")
        val remote = obj("""{"tasks":[]}""")
        assertEquals("delete_vs_edit", SnapshotMerge.merge(base, local, remote).issues.single().fields.single())
    }

    @Test fun conflictResolutionKeepsUnrelatedRemoteField() {
        val base = obj("""{"tasks":[{"id":"1","title":"Base","description":"Base"}]}""")
        val local = obj("""{"tasks":[{"id":"1","title":"Local","description":"Base"}]}""")
        val remote = obj("""{"tasks":[{"id":"1","title":"Remote","description":"Web"}]}""")
        val resolved = SnapshotMerge.merge(base, local, remote, setOf("1"))
        assertTrue(resolved.issues.toString(), resolved.issues.isEmpty())
        val task = resolved.merged.getJSONArray("tasks").getJSONObject(0)
        assertEquals("Local", task.getString("title"))
        assertEquals("Web", task.getString("description"))
    }

    @Test fun noOpIgnoresTransportMetadata() {
        val base = obj("""{"version":5,"updated_at":"old","tasks":[],"settings":{}}""")
        val local = obj("""{"version":6,"updated_at":"new","tasks":[],"settings":{}}""")
        assertFalse(SnapshotMerge.hasLocalEdits(base, local))
    }
}

class TimeCodecTest {
    @Test fun readsIsoAndNumericAndWritesIso() {
        val ms = 1_762_444_800_123L
        val iso = com.example.data.util.TimeCodec.toIso(ms)
        assertEquals("2025-11-06T16:00:00.123Z", iso)
        assertEquals(ms, com.example.data.util.TimeCodec.parse(iso))
        assertEquals(ms, com.example.data.util.TimeCodec.parse(ms))
        assertNull(com.example.data.util.TimeCodec.parse(null))
        assertNull(com.example.data.util.TimeCodec.parse(org.json.JSONObject.NULL))
        assertNull(com.example.data.util.TimeCodec.parse("garbage"))
        assertEquals("2025-11-06", com.example.data.util.TimeCodec.utcDate(ms))
    }
}

class TaskOrderingTest {
    private val prios = com.example.data.model.DEFAULT_PRIORITIES
    private fun t(id: String, title: String = id, prio: String = "prio_med", due: String = "", bonus: Boolean = false,
                  created: Long = 0, status: com.example.data.model.TaskStatus = com.example.data.model.TaskStatus.ACTIVE,
                  parent: String? = null, extra: Map<String, Any?> = emptyMap()) =
        com.example.data.model.Task(id = id, parentId = parent, title = title, priorityId = prio, dueDate = due,
            isBonus = bonus, createdAt = created, status = status, unmappedFields = extra)

    @Test fun priorityThenDueThenCreated() {
        val list = listOf(t("a", prio = "prio_low"), t("b", prio = "prio_high", due = "2026-12-01"),
            t("c", prio = "prio_high", due = "2026-11-01"), t("d", prio = "prio_high", due = "2026-11-01", created = -1))
        val out = com.example.data.util.TaskOrdering.sort(list, com.example.data.util.SortMode.PRIORITY, prios, emptyMap())
        assertEquals(listOf("d", "c", "b", "a"), out.map { it.id })
    }

    @Test fun alphabeticalIsNumericAware() {
        val list = listOf(t("1", title = "Chapter 10"), t("2", title = "chapter 2"), t("3", title = "Alpha"))
        val out = com.example.data.util.TaskOrdering.sort(list, com.example.data.util.SortMode.ALPHA, prios, emptyMap())
        assertEquals(listOf("3", "2", "1"), out.map { it.id })
    }

    @Test fun requiredPutsBonusLast() {
        val list = listOf(t("b", prio = "prio_high", bonus = true), t("r", prio = "prio_low"))
        val out = com.example.data.util.TaskOrdering.sort(list, com.example.data.util.SortMode.REQUIRED, prios, emptyMap())
        assertEquals(listOf("r", "b"), out.map { it.id })
    }

    @Test fun dynamicPriorityAppliesWhenOnlyBonusWorkRemains() {
        val parent = t("p", prio = "prio_low", extra = mapOf("dynamic_priority_target" to "prio_high"))
        val doneRequired = t("c1", parent = "p", status = com.example.data.model.TaskStatus.COMPLETED)
        val bonus = t("b1", parent = "p", bonus = true)
        assertEquals("prio_high", com.example.data.util.TaskOrdering.effectivePriorities(listOf(parent, doneRequired, bonus), prios)["p"])
        val required = t("r1", parent = "p")
        assertNull(com.example.data.util.TaskOrdering.effectivePriorities(listOf(parent, required, bonus), prios)["p"])
        assertNull(com.example.data.util.TaskOrdering.effectivePriorities(listOf(parent, doneRequired), prios)["p"])
    }
}

class ProjectMergeTest {
    private fun obj(s: String) = JSONObject(s)
    private val inbox = """{"id":"inbox","name":"Inbox","is_default":true}"""

    @Test fun projectCreatedOnDeviceSurvivesMergeWithoutConflict() {
        val base = obj("""{"tasks":[],"projects":[$inbox]}""")
        val local = obj("""{"tasks":[],"projects":[$inbox,{"id":"proj_1","name":"School"}]}""")
        val remote = obj("""{"tasks":[],"projects":[$inbox]}""")
        val out = SnapshotMerge.merge(base, local, remote)
        assertTrue(out.issues.toString(), out.issues.isEmpty())
        assertEquals(2, out.merged.getJSONArray("projects").length())
    }

    @Test fun projectsAddedOnBothSidesAreUnioned() {
        val base = obj("""{"tasks":[],"projects":[$inbox]}""")
        val local = obj("""{"tasks":[],"projects":[$inbox,{"id":"a","name":"A"}]}""")
        val remote = obj("""{"tasks":[],"projects":[$inbox,{"id":"b","name":"B"}]}""")
        val out = SnapshotMerge.merge(base, local, remote)
        assertTrue(out.issues.isEmpty())
        assertEquals(3, out.merged.getJSONArray("projects").length())
    }

    @Test fun websiteRenameOfProjectIsKept() {
        val base = obj("""{"tasks":[],"projects":[{"id":"a","name":"Old"}]}""")
        val remote = obj("""{"tasks":[],"projects":[{"id":"a","name":"New"}]}""")
        val out = SnapshotMerge.merge(base, base, remote)
        assertTrue(out.issues.isEmpty())
        assertEquals("New", out.merged.getJSONArray("projects").getJSONObject(0).getString("name"))
    }
}

class PrioritySettingsMergeTest {
    @Test fun devicePriorityEditIsKeptWhenCloudUnchanged() {
        val base = JSONObject("""{"tasks":[],"settings":{"custom_priorities":[{"id":"a","name":"High","rank":1}]}}""")
        val local = JSONObject("""{"tasks":[],"settings":{"custom_priorities":[{"id":"a","name":"Urgent","rank":1}]}}""")
        val out = SnapshotMerge.merge(base, local, base)
        assertTrue(out.issues.isEmpty())
        assertEquals("Urgent", out.merged.getJSONObject("settings").getJSONArray("custom_priorities").getJSONObject(0).getString("name"))
    }
}
