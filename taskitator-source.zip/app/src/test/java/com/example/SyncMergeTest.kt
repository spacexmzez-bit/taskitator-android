package com.example

import com.example.data.sync.SyncMerge
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Tests the merge code the app runs (SyncMerge), not a copy of it. */
class SyncMergeTest {
    private fun snap(version: Int, vararg tasks: String, extra: String = ""): JSONObject =
        JSONObject("""{"version": $version, "tasks": [${tasks.joinToString(",")}] $extra}""")

    private fun task(obj: JSONObject, id: String): JSONObject {
        val arr = obj.getJSONArray("tasks")
        return (0 until arr.length()).map { arr.getJSONObject(it) }.first { it.getString("id") == id }
    }

    private fun ids(obj: JSONObject): Set<String> {
        val arr = obj.getJSONArray("tasks")
        return (0 until arr.length()).map { arr.getJSONObject(it).getString("id") }.toSet()
    }

    @Test
    fun independentEditsOnDifferentTasksMergeCleanly() {
        val base = snap(1, """{"id":"A","title":"A base","status":"active"}""", """{"id":"B","title":"B base","status":"active"}""")
        val local = snap(1, """{"id":"A","title":"A renamed on Android","status":"active"}""", """{"id":"B","title":"B base","status":"active"}""")
        val remote = snap(2, """{"id":"A","title":"A base","status":"active"}""", """{"id":"B","title":"B base","status":"completed"}""")

        val result = SyncMerge.merge(base, local, remote)

        assertTrue(result.clean)
        assertTrue(result.conflicts.isEmpty())
        assertEquals("A renamed on Android", task(remote, "A").getString("title"))
        assertEquals("completed", task(remote, "B").getString("status"))
    }

    @Test
    fun differentFieldsOfTheSameTaskMergeCleanly() {
        val base = snap(1, """{"id":"A","title":"T","due_date":"2026-11-10","web_only":"keep"}""")
        val local = snap(1, """{"id":"A","title":"T local","due_date":"2026-11-10","web_only":"keep"}""")
        val remote = snap(2, """{"id":"A","title":"T","due_date":"2026-11-12","web_only":"keep"}""")

        assertTrue(SyncMerge.merge(base, local, remote).clean)
        val merged = task(remote, "A")
        assertEquals("T local", merged.getString("title"))
        assertEquals("2026-11-12", merged.getString("due_date"))
        assertEquals("keep", merged.getString("web_only"))
    }

    @Test
    fun sameFieldEditedOnBothSidesIsAConflict() {
        val base = snap(1, """{"id":"C","title":"Base","status":"active"}""")
        val local = snap(1, """{"id":"C","title":"Local X","status":"active"}""")
        val remote = snap(2, """{"id":"C","title":"Remote Y","status":"active"}""")

        val result = SyncMerge.merge(base, local, remote)

        assertFalse(result.clean)
        assertEquals(1, result.conflicts.size)
        assertEquals("C", result.conflicts[0].taskId)
        assertEquals(listOf("title"), result.conflicts[0].conflictingFields)
        assertEquals("Local X", result.conflicts[0].localTitle)
        assertEquals("Remote Y", result.conflicts[0].remoteTitle)
    }

    @Test
    fun deleteAgainstEditIsAConflictInBothDirections() {
        val base = snap(1, """{"id":"D","title":"Base","status":"active"}""")
        val edited = """{"id":"D","title":"Edited","status":"active"}"""

        val localDeleted = SyncMerge.merge(base, snap(1), snap(2, edited))
        assertFalse(localDeleted.clean)
        assertEquals(listOf("delete_vs_edit"), localDeleted.conflicts[0].conflictingFields)

        val remoteDeleted = SyncMerge.merge(base, snap(1, edited), snap(2))
        assertFalse(remoteDeleted.clean)
        assertEquals(listOf("delete_vs_edit"), remoteDeleted.conflicts[0].conflictingFields)
    }

    @Test
    fun deletionOfAnUntouchedTaskIsKept() {
        val base = snap(1, """{"id":"D","title":"Base"}""", """{"id":"E","title":"Stays"}""")
        val local = snap(1, """{"id":"E","title":"Stays"}""")
        val remote = snap(2, """{"id":"D","title":"Base"}""", """{"id":"E","title":"Stays"}""")

        assertTrue(SyncMerge.merge(base, local, remote).clean)
        assertEquals(setOf("E"), ids(remote))
    }

    @Test
    fun tasksAddedOnEachSideAreBothKept() {
        val base = snap(1)
        val local = snap(1, """{"id":"L","title":"From phone"}""")
        val remote = snap(2, """{"id":"R","title":"From web"}""")

        assertTrue(SyncMerge.merge(base, local, remote).clean)
        assertEquals(setOf("L", "R"), ids(remote))
    }

    @Test
    fun aFieldRemovedOnOneSideDoesNotCrashAndIsRemoved() {
        val base = snap(1, """{"id":"A","title":"T","completed_at":5,"status":"completed"}""")
        val local = snap(1, """{"id":"A","title":"T","status":"active"}""")
        val remote = snap(2, """{"id":"A","title":"T web","completed_at":5,"status":"completed"}""")

        assertTrue(SyncMerge.merge(base, local, remote).clean)
        val merged = task(remote, "A")
        assertFalse(merged.has("completed_at"))
        assertEquals("active", merged.getString("status"))
        assertEquals("T web", merged.getString("title"))
    }

    @Test
    fun protectedFieldsAlwaysComeFromTheCloud() {
        val base = snap(1, """{"id":"A","title":"T","ai_locked":true,"audit_approved":false}""")
        val local = snap(1, """{"id":"A","title":"T local","ai_locked":false,"audit_approved":true}""")
        val remote = snap(2, """{"id":"A","title":"T","ai_locked":true,"audit_approved":false,"due_date":"2026-11-12"}""")

        assertTrue(SyncMerge.merge(base, local, remote).clean)
        val merged = task(remote, "A")
        assertTrue(merged.getBoolean("ai_locked"))
        assertFalse(merged.getBoolean("audit_approved"))
        assertEquals("T local", merged.getString("title"))
    }

    @Test
    fun projectsAndSettingsMergePerEntry() {
        val base = snap(1, extra = ""","projects":[{"id":"p1","name":"One"}],"settings":{"copilot_name":"Ari","day_start_hour":0}""")
        val local = snap(1, extra = ""","projects":[{"id":"p1","name":"One"},{"id":"p2","name":"Phone"}],"settings":{"copilot_name":"Ari","day_start_hour":0,"task_draft:d1":{"saved_at":1}}""")
        val remote = snap(2, extra = ""","projects":[{"id":"p1","name":"One"},{"id":"p3","name":"Web"}],"settings":{"copilot_name":"Ari","day_start_hour":2}""")

        assertTrue(SyncMerge.merge(base, local, remote).clean)
        val projects = remote.getJSONArray("projects")
        assertEquals(setOf("p1", "p2", "p3"), (0 until projects.length()).map { projects.getJSONObject(it).getString("id") }.toSet())
        val settings = remote.getJSONObject("settings")
        assertEquals(2, settings.getInt("day_start_hour"))
        assertTrue(settings.has("task_draft:d1"))
    }

    @Test
    fun theSameSettingChangedOnBothSidesIsAConflict() {
        val base = snap(1, extra = ""","settings":{"day_start_hour":0}""")
        val local = snap(1, extra = ""","settings":{"day_start_hour":1}""")
        val remote = snap(2, extra = ""","settings":{"day_start_hour":2}""")

        val result = SyncMerge.merge(base, local, remote)
        assertFalse(result.clean)
        assertEquals("setting:day_start_hour", result.conflicts[0].taskId)
    }

    @Test
    fun aConflictLeavesTheCloudCopyUntouched() {
        val base = snap(1, """{"id":"C","title":"Base"}""", extra = ""","recurrence_state":{"n":1}""")
        val local = snap(1, """{"id":"C","title":"Local"}""", extra = ""","recurrence_state":{"n":2}""")
        val remote = snap(2, """{"id":"C","title":"Remote"}""", extra = ""","recurrence_state":{"n":1}""")
        val before = remote.toString()

        assertFalse(SyncMerge.merge(base, local, remote).clean)
        assertEquals(before, remote.toString())
    }

    @Test
    fun unknownTopLevelDataFromTheCloudSurvivesAMerge() {
        val base = snap(1, """{"id":"A","title":"T"}""")
        val local = snap(1, """{"id":"A","title":"T2"}""")
        val remote = snap(2, """{"id":"A","title":"T"}""", extra = ""","universe_groups":[{"id":"g"}],"today_breaks":{"x":1}""")

        assertTrue(SyncMerge.merge(base, local, remote).clean)
        assertEquals(1, remote.getJSONArray("universe_groups").length())
        assertEquals(1, remote.getJSONObject("today_breaks").getInt("x"))
        assertEquals(2, remote.getInt("version"))
    }

    @Test
    fun byIdSkipsEntriesWithoutAnId() {
        val arr = JSONArray().put(JSONObject().put("id", "a")).put(JSONObject().put("title", "no id")).put("not an object")
        assertEquals(setOf("a"), SyncMerge.byId(arr).keys)
        assertTrue(SyncMerge.byId(null).isEmpty())
    }
}
