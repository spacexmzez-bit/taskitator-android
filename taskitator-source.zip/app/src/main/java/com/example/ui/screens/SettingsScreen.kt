package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CustomPriority
import com.example.data.network.TaskitatorWorkerApi
import com.example.ui.theme.*
import com.example.ui.viewmodel.TaskitatorViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: TaskitatorViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    val authState by viewModel.authState.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("General", "Tasks", "Day & Week", "Pro", "Phone Lock", "Account")

    // Phase 1 native language and appearance controls.
    var chosenLanguage by remember(settings.language) { mutableStateOf(settings.language) }
    var chosenTheme by remember(settings.appearanceTheme) { mutableStateOf(settings.appearanceTheme) }

    // General state
    var copilotNameInput by remember(settings.copilotName) { mutableStateOf(settings.copilotName) }
    var soundEffects by remember(settings.soundEffectsEnabled) { mutableStateOf(settings.soundEffectsEnabled) }
    var haptics by remember(settings.hapticsEnabled) { mutableStateOf(settings.hapticsEnabled) }
    var dumpDuration by remember(settings.dumpDurationSeconds) { mutableFloatStateOf(settings.dumpDurationSeconds.toFloat()) }
    var syncStatusMessage by remember { mutableStateOf<String?>(null) }
    var isSyncing by remember { mutableStateOf(false) }

    // Tasks state
    var strictValidation by remember(settings.strictCriteriaValidation) { mutableStateOf(settings.strictCriteriaValidation) }
    var newTagInput by remember { mutableStateOf("") }

    // Day & week state
    var dayStartHour by remember(settings.dayStartHour) { mutableFloatStateOf(settings.dayStartHour.toFloat()) }
    var weekendStart by remember(settings.weekendStart) { mutableIntStateOf(settings.weekendStart) }
    var weekendEnd by remember(settings.weekendEnd) { mutableIntStateOf(settings.weekendEnd) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Settings",
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
            fontWeight = FontWeight.ExtraBold
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                chosenLanguage = if (chosenLanguage == "en") "ar" else "en"
                viewModel.repository.updateSettings(settings.copy(language = chosenLanguage))
            }) { Text(if (chosenLanguage == "en") "العربية / RTL" else "English / LTR") }
            OutlinedButton(onClick = {
                chosenTheme = if (chosenTheme == "midnight") "nature" else "midnight"
                viewModel.repository.updateSettings(settings.copy(appearanceTheme = chosenTheme))
            }) { Text(if (chosenTheme == "nature") "Nature (preview)" else "Midnight") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Task sorting:", modifier = Modifier.padding(top = 10.dp))
            listOf("priority", "alphabetical", "required_first").forEach { mode ->
                TextButton(onClick = { viewModel.repository.updateSettings(settings.copy(taskSortMode = mode)) }) {
                    Text(if (mode == settings.taskSortMode) "✓ ${mode.replace('_', ' ')}" else mode.replace('_', ' '))
                }
            }
        }

        // 6 Tabs per Plan v5 Section 9.4
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurfaceVariant,
            contentColor = ElectricBlue,
            edgePadding = 0.dp
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            when (selectedTab) {
                0 -> {
                    // TAB 0: General
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Focus & Experience", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = copilotNameInput,
                                onValueChange = {
                                    if (it.length <= 20) {
                                        copilotNameInput = it
                                        viewModel.repository.updateSettings(settings.copy(copilotName = it))
                                    }
                                },
                                label = { Text("Assistant Name (max 20 chars)") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = ElectricBlue,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        soundEffects = !soundEffects
                                        viewModel.repository.updateSettings(settings.copy(soundEffectsEnabled = soundEffects))
                                    },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Sound Effects", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = soundEffects,
                                    onCheckedChange = {
                                        soundEffects = it
                                        viewModel.repository.updateSettings(settings.copy(soundEffectsEnabled = it))
                                    }
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        haptics = !haptics
                                        viewModel.repository.updateSettings(settings.copy(hapticsEnabled = haptics))
                                    },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Haptic Feedback", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = haptics,
                                    onCheckedChange = {
                                        haptics = it
                                        viewModel.repository.updateSettings(settings.copy(hapticsEnabled = it))
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "Distraction Dump Timer: ${dumpDuration.toInt()} seconds",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Slider(
                                value = dumpDuration,
                                onValueChange = {
                                    val stepped = (Math.round(it / 15f) * 15).coerceIn(30, 300)
                                    dumpDuration = stepped.toFloat()
                                    viewModel.repository.updateSettings(settings.copy(dumpDurationSeconds = stepped))
                                },
                                valueRange = 30f..300f,
                                steps = 17,
                                colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Cloudflare Worker Sync Card
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Cloudflare Worker Synchronization", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Worker Gateway: ${TaskitatorWorkerApi.WORKER_BASE_URL}", fontSize = 11.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    isSyncing = true
                                    syncStatusMessage = null
                                    scope.launch {
                                        val (ok, msg) = viewModel.repository.performSync()
                                        isSyncing = false
                                        syncStatusMessage = msg
                                    }
                                },
                                enabled = !isSyncing,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (isSyncing) "Syncing with Worker..." else "Sync Now", fontWeight = FontWeight.Bold)
                            }

                            if (syncStatusMessage != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(syncStatusMessage!!, fontSize = 11.sp, color = CyanAccent)
                            }
                        }
                    }
                }

                1 -> {
                    // TAB 1: Tasks
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Criteria & Protection Rules", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        strictValidation = !strictValidation
                                        viewModel.repository.updateSettings(settings.copy(strictCriteriaValidation = strictValidation))
                                    },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Strict Criteria Validation", color = TextPrimary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text("Ordinary AI-locked tasks must achieve score >= 7/10 before saving.", color = TextMuted, fontSize = 11.sp)
                                }
                                Switch(
                                    checked = strictValidation,
                                    onCheckedChange = {
                                        strictValidation = it
                                        viewModel.repository.updateSettings(settings.copy(strictCriteriaValidation = it))
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text("Custom Tags", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedTextField(
                                    value = newTagInput,
                                    onValueChange = { newTagInput = it },
                                    placeholder = { Text("Add tag...") },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyanAccent,
                                        unfocusedBorderColor = DarkBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Button(
                                    onClick = {
                                        if (newTagInput.isNotBlank()) {
                                            val current = settings.customTags.toMutableList()
                                            val t = newTagInput.trim().lowercase()
                                            if (t !in current) current.add(t)
                                            viewModel.repository.updateSettings(settings.copy(customTags = current))
                                            newTagInput = ""
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent)
                                ) {
                                    Text("Add", color = DarkBackground, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                settings.customTags.forEach { tag ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = DarkSurfaceVariant,
                                        border = androidx.compose.foundation.BorderStroke(0.5.dp, DarkBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text("#$tag", color = TextPrimary, fontSize = 11.sp)
                                            Text(
                                                "✕",
                                                color = TextMuted,
                                                fontSize = 10.sp,
                                                modifier = Modifier.clickable {
                                                    val current = settings.customTags.toMutableList()
                                                    current.remove(tag)
                                                    viewModel.repository.updateSettings(settings.copy(customTags = current))
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // TAB 2: Day & week
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Schedule & Calendar Cycle", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Logical Day Start: ${dayStartHour.toInt()}:00 AM",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text("Tasks due 'today' remain active until this hour tomorrow morning (0..4 AM).", color = TextMuted, fontSize = 11.sp)
                            Slider(
                                value = dayStartHour,
                                onValueChange = {
                                    val h = it.toInt().coerceIn(0, 4)
                                    dayStartHour = h.toFloat()
                                    viewModel.repository.updateSettings(settings.copy(dayStartHour = h))
                                },
                                valueRange = 0f..4f,
                                steps = 3,
                                colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = ElectricBlue)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Text("Break & Schedule Timezone", style = MaterialTheme.typography.labelMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            Text("App Timezone: ${settings.breakTimezone} (Server sync uses Riyadh UTC+3)", color = TextMuted, fontSize = 11.sp)
                        }
                    }
                }

                3 -> {
                    // TAB 3: AI & Pro
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Taskitator Pro", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (settings.isPro) SuccessGreen.copy(alpha = 0.2f) else DarkSurfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, if (settings.isPro) SuccessGreen else DarkBorder)
                                ) {
                                    Text(
                                        text = if (settings.isPro) "PRO ACTIVE" else "FREE ACCOUNT",
                                        color = if (settings.isPro) SuccessGreen else TextSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Pro and AI features are not available in the app yet. They arrive in a later build.",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }

                4 -> {
                    // TAB 4: Phone lock. The built-in app blocker replaces any external setup.
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            BlockerSettings(signedIn = authState is com.example.data.model.AuthState.Authenticated)
                        }
                    }
                }

                5 -> {
                    // TAB 5: Account & Data
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Account & Cloud Data", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(10.dp))

                            when (authState) {
                                is com.example.data.model.AuthState.Authenticated -> {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = SuccessGreen.copy(alpha = 0.12f),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.4f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text("✓ Connected Cloud Account", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("User: ${settings.username}", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                            Text("Cloud User ID: ${settings.workerUser}", color = TextSecondary, fontSize = 11.sp)
                                            Text("Remote Snapshot: v${settings.remoteVersion}", color = TextMuted, fontSize = 11.sp)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Button(
                                        onClick = { viewModel.setAuthDialogVisible(true) },
                                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Manage Session / Switch Account", fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    OutlinedButton(
                                        onClick = { viewModel.signOut() },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PriorityP1),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, PriorityP1.copy(alpha = 0.5f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Sign Out", fontWeight = FontWeight.Bold)
                                    }
                                }
                                else -> {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = DarkSurfaceVariant,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text("☁️ Cloud Sync Disabled", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("Sign in to sync with the website.", color = TextMuted, fontSize = 11.sp)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Button(
                                        onClick = { viewModel.setAuthDialogVisible(true) },
                                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Sign in", color = DarkBackground, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = DarkBorder, thickness = 0.5.dp)
                            Spacer(modifier = Modifier.height(16.dp))

                            Text("Local Safety Backups", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedButton(
                                onClick = {
                                    val backupJson = viewModel.repository.exportConflictBackup()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("conflict_backup", backupJson))
                                    Toast.makeText(context, "Conflict backup copied to clipboard", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Export Conflict Backup JSON", fontSize = 12.sp)
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = DarkBorder, thickness = 0.5.dp)
                            Spacer(modifier = Modifier.height(16.dp))

                            // Last crash, saved on this phone only, so it can be copied and reported.
                            var crash by remember { mutableStateOf(com.example.data.util.CrashReport.load(context.filesDir)) }
                            crash?.let { text ->
                                Text("Last crash", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text.take(1200), color = TextMuted, fontSize = 10.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("crash", text))
                                        Toast.makeText(context, "Crash text copied", Toast.LENGTH_SHORT).show()
                                    }) { Text("Copy", fontSize = 12.sp) }
                                    TextButton(onClick = {
                                        com.example.data.util.CrashReport.clear(context.filesDir)
                                        crash = null
                                    }) { Text("Clear", fontSize = 12.sp) }
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider(color = DarkBorder, thickness = 0.5.dp)
                                Spacer(modifier = Modifier.height(16.dp))
                            }

                            // In-app account deletion (Google Play requirement).
                            AccountDeletionSection(
                                viewModel = viewModel,
                                signedIn = authState is com.example.data.model.AuthState.Authenticated
                            )
                        }
                    }
                }
            }
        }
    }
}
