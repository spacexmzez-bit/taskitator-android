package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.INBOX_PROJECT_ID
import com.example.data.model.Project
import com.example.data.model.TaskStatus
import com.example.data.util.TaskOrdering
import com.example.ui.components.TaskItemCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.TaskitatorViewModel

/** Website Projects view: real projects (snapshot.projects + task.project_id), Inbox is the default. */
@Composable
fun ProjectsScreen(
    viewModel: TaskitatorViewModel,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.tasks.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val projects by viewModel.repository.projects.collectAsState()
    val isSelectMode by viewModel.isSelectMode.collectAsState()
    val selectedTaskIds by viewModel.selectedTaskIds.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()

    var expanded by remember { mutableStateOf(setOf<String>()) }
    var editing by remember { mutableStateOf<Project?>(null) }   // rename
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Project?>(null) }
    var nameInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    val live = remember(tasks) { tasks.filter { it.status != TaskStatus.TRASH } }

    Column(modifier = modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Projects", style = MaterialTheme.typography.headlineMedium, color = TextPrimary, fontWeight = FontWeight.ExtraBold)
            Button(
                onClick = { nameInput = ""; errorText = null; creating = true },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
            ) { Text("+ Project", fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(projects, key = { it.id }) { project ->
                val inProject = live.filter { (it.projectId ?: INBOX_PROJECT_ID) == project.id }
                val done = inProject.count { it.status == TaskStatus.COMPLETED }
                val roots = TaskOrdering.sort(
                    inProject.filter { it.status == TaskStatus.ACTIVE && (it.parentId == null || inProject.none { p -> p.id == it.parentId }) },
                    sortMode, settings.customPriorities, TaskOrdering.effectivePriorities(tasks, settings.customPriorities)
                )
                val isOpen = project.id in expanded
                Surface(shape = RoundedCornerShape(12.dp), color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(
                            Modifier.fillMaxWidth().clickable { expanded = if (isOpen) expanded - project.id else expanded + project.id },
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(project.icon, fontSize = 20.sp)
                            Column(Modifier.weight(1f)) {
                                Text(project.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("$done/${inProject.size} done · ${roots.size} active", color = TextMuted, fontSize = 11.sp)
                            }
                            if (!project.isDefault && project.id != INBOX_PROJECT_ID) {
                                TextButton(onClick = { nameInput = project.name; errorText = null; editing = project }) { Text("Rename", fontSize = 11.sp, color = CyanAccent) }
                                TextButton(onClick = { deleting = project }) { Text("Delete", fontSize = 11.sp, color = DangerRed) }
                            }
                            Text(if (isOpen) "▾" else "▸", color = TextSecondary, fontSize = 16.sp)
                        }
                        if (inProject.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { done.toFloat() / inProject.size },
                                modifier = Modifier.fillMaxWidth().height(4.dp),
                                color = SuccessGreen, trackColor = DarkSurfaceVariant
                            )
                        }
                        if (isOpen) {
                            Spacer(Modifier.height(10.dp))
                            if (roots.isEmpty()) Text("No active tasks in this project.", color = TextMuted, fontSize = 12.sp)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                roots.forEach { task ->
                                    TaskItemCard(
                                        task = task,
                                        allTasks = tasks,
                                        indentLevel = 0,
                                        isSelectMode = isSelectMode,
                                        isSelected = task.id in selectedTaskIds,
                                        emergencyBypassActive = settings.emergencyBypassActive,
                                        onToggleCompletion = { id ->
                                            val (ok, error) = viewModel.repository.toggleTaskCompletion(id)
                                            if (!ok && error != null) viewModel.setStatusMessage(error)
                                        },
                                        onToggleSelection = { viewModel.toggleTaskSelection(it) },
                                        onEditTask = { viewModel.openEditTaskDialog(it) },
                                        onAddSubtask = { viewModel.openCreateTaskDialog(parentId = it) },
                                        onTrashTask = { viewModel.repository.trashBranch(it) },
                                        onOpenAudit = { viewModel.openEvidenceAuditDialog(it) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (creating || editing != null) {
        AlertDialog(
            onDismissRequest = { creating = false; editing = null },
            title = { Text(if (creating) "New project" else "Rename project") },
            text = {
                Column {
                    OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, singleLine = true, label = { Text("Project name") })
                    errorText?.let { Text(it, color = DangerRed, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val target = editing
                    val (ok, err) = if (target == null) viewModel.repository.createProject(nameInput)
                        else viewModel.repository.renameProject(target.id, nameInput)
                    if (ok) { creating = false; editing = null } else errorText = err
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { creating = false; editing = null }) { Text("Cancel") } }
        )
    }

    deleting?.let { project ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete \"${project.name}\"?") },
            text = { Text("Its tasks are not deleted. They move to the Inbox.") },
            confirmButton = {
                Button(
                    onClick = {
                        val (ok, err) = viewModel.repository.deleteProject(project.id)
                        if (!ok && err != null) viewModel.setStatusMessage(err)
                        deleting = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}
