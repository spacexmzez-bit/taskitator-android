package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AuthState
import com.example.data.model.UserSettings

@Composable
fun AuthDialog(authState: AuthState, settings: UserSettings, onSignInToken: (String) -> Unit,
               onConnectAccount: (String) -> Unit, onSignOut: () -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Taskitator account", style = MaterialTheme.typography.titleLarge)
                Text(when (authState) {
                    is AuthState.Authenticated -> "Signed in: ${authState.username}"
                    is AuthState.Unlinked -> "Your Clerk account needs a Taskitator cloud account."
                    else -> "Email, password and Google sign-in are managed securely by Clerk."
                })
                if (authState is AuthState.Authenticated) {
                    Button(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Close") }
            }
        }
    }
}
