package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AuthState
import com.example.data.model.UserSettings
import com.example.ui.theme.*

@Composable
fun AuthDialog(
    authState: AuthState,
    settings: UserSettings,
    busy: Boolean,
    onSignIn: () -> Unit,
    onConnectAccount: (String) -> Unit,
    onSignOut: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Account Authentication",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Text("✕", color = TextMuted, fontSize = 16.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (authState) {
                    is AuthState.Authenticated -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SuccessGreen.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("✓ Connected to Cloud Account", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("User: ${authState.username}", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                Text("Worker User ID: ${authState.workerUser}", color = TextSecondary, fontSize = 11.sp)
                                if (authState.isOffline) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Status: Working in offline mode", color = WarningAmber, fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                onSignOut()
                                onDismiss()
                            },
                            enabled = !busy,
                            colors = ButtonDefaults.buttonColors(containerColor = PriorityP1),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_sign_out")
                        ) {
                            Text("Sign Out", fontWeight = FontWeight.Bold)
                        }
                    }

                    is AuthState.Unlinked -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = WarningAmber.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("⚠️ Account Unlinked", color = WarningAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "You are signed in, but this sign-in has no Taskitator account yet. Create one to begin syncing.",
                                    color = TextPrimary,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { onConnectAccount(authState.token) },
                                    colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Create Taskitator account", color = DarkBackground, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    is AuthState.SessionExpired -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = PriorityP1.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PriorityP1),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("⚠️ Session ended", color = PriorityP1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(authState.message, color = TextPrimary, fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    is AuthState.AccountDeleted -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = PriorityP1.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PriorityP1),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("🚫 Account Deleted (410)", color = PriorityP1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("This cloud account has been permanently deleted.", color = TextPrimary, fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    else -> {
                        Text(
                            text = "Sign in to synchronize your tasks, breaks, and settings with the website.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                    }
                }

                if (authState !is AuthState.Authenticated) {
                    Button(
                        onClick = onSignIn,
                        enabled = !busy,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_sign_in")
                    ) {
                        Text(if (busy) "Waiting for sign-in…" else "Sign in", color = DarkBackground, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "A secure sign-in page opens in your browser. New here? Create an account on that page.",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Close", color = TextSecondary)
                }
            }
        }
    }
}
