package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.example.BuildConfig
import com.example.blocker.BlockListRules
import com.example.blocker.BlockerPackages
import com.example.blocker.BlockerSignals
import com.example.blocker.BlockerStore
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** The exact disclosure shown before Android's accessibility settings are opened. */
object BlockerDisclosure {
    const val TITLE = "Taskitator needs the Accessibility permission"
    const val BODY =
        "Taskitator uses Android's Accessibility Service API for one purpose: to block the apps you choose " +
        "while your tasks for today are unfinished or Sleep Lock is on.\n\n" +
        "What it does:\n" +
        "• Sees the name of the app that is open on screen (its package name, for example com.example.game).\n" +
        "• If that app is on your block list and your phone is locked, shows a Taskitator screen over it.\n\n" +
        "What it does not do:\n" +
        "• It does not read what is on your screen, what you type, your messages or your passwords.\n" +
        "• It does not tap, type or change settings for you.\n" +
        "• It does not store or send the names of the apps you use. Your block list stays on this phone.\n\n" +
        "You can turn this off at any time in Android Settings > Accessibility. " +
        "If you agree, the next screen is Android's accessibility settings, where you switch on \"Taskitator app blocker\"."
    const val AGREE = "Agree"
    const val DECLINE = "No thanks"
}

@Composable
fun BlockerSettings(signedIn: Boolean) {
    val context = LocalContext.current
    val store = remember { BlockerStore(context) }

    var serviceOn by remember { mutableStateOf(BlockerPackages.isServiceEnabled(context)) }
    var enabled by remember { mutableStateOf(store.enabled) }
    var blocked by remember { mutableStateOf(store.blockedApps) }
    var locked by remember { mutableStateOf(isLocked(store)) }
    var debugLock by remember { mutableStateOf(store.debugLock) }
    var message by remember { mutableStateOf<String?>(null) }
    var showDisclosure by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }

    // Coming back from Android settings: re-read what may have changed.
    LifecycleResumeEffect(Unit) {
        serviceOn = BlockerPackages.isServiceEnabled(context)
        locked = isLocked(store)
        BlockerSignals.requestRefresh()
        onPauseOrDispose { }
    }

    Column {
        Text("App blocker", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Blocks the apps you choose while your tasks for today are unfinished or Sleep Lock is on. " +
                "Breaks and Emergency Bypass open them again. Calls, Settings and your home screen are never blocked.",
            color = TextSecondary, fontSize = 12.sp
        )
        Spacer(Modifier.height(12.dp))

        // 1. Permission
        Text(
            text = if (serviceOn) "✓ Accessibility permission is on" else "Accessibility permission is off",
            color = if (serviceOn) SuccessGreen else WarningAmber,
            fontWeight = FontWeight.SemiBold, fontSize = 13.sp
        )
        if (!serviceOn) {
            Spacer(Modifier.height(6.dp))
            Button(
                onClick = { showDisclosure = true },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Set up app blocker", fontWeight = FontWeight.Bold) }
        }

        // 2. Switch
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("Block apps while locked", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    when {
                        !serviceOn -> "Needs the Accessibility permission first."
                        locked -> "Your phone is locked now."
                        else -> "Your phone is not locked now."
                    },
                    color = TextMuted, fontSize = 11.sp
                )
            }
            Switch(
                checked = enabled,
                enabled = serviceOn || enabled,
                onCheckedChange = { wanted ->
                    val refusal = BlockListRules.refusal(isLocked(store), enabled, wanted, blocked, blocked)
                    if (refusal != null) {
                        message = refusal
                    } else {
                        store.enabled = wanted
                        enabled = wanted
                        message = null
                    }
                }
            )
        }

        // 3. Apps
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Choose apps to block (${blocked.size} chosen)")
        }

        message?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = DangerRed, fontSize = 12.sp)
        }

        if (!signedIn) {
            Spacer(Modifier.height(8.dp))
            Text("Sign in so the blocker can follow your tasks. Until then nothing is blocked.", color = WarningAmber, fontSize = 12.sp)
        }

        Spacer(Modifier.height(12.dp))
        Text("Why is an app blocked?", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(
            "Taskitator's server decides when your phone is locked, the same way as on the website: " +
                "unfinished tasks for today, a Universe lock, or Sleep Lock. This phone only applies that answer. " +
                "With no internet the last answer stays in force. While the phone is locked you can add apps " +
                "to the list but not remove them or turn blocking off.",
            color = TextSecondary, fontSize = 12.sp
        )

        Spacer(Modifier.height(12.dp))
        Text("If blocking stops by itself", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(
            "Some phones stop background services to save battery. Set Taskitator's battery use to " +
                "\"Unrestricted\" (Samsung: also add it to \"Never sleeping apps\"; Xiaomi: turn on Autostart and " +
                "choose \"No restrictions\"; Oppo/Realme/Vivo: allow auto-launch and background activity).",
            color = TextSecondary, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = { openAppDetails(context) }, modifier = Modifier.fillMaxWidth()) {
            Text("Open Taskitator's system settings")
        }

        if (BuildConfig.DEBUG) {
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Test lock (debug builds only)", color = WarningAmber, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text("Pretends the server says \"locked\" so you can try the block screen without signing in.", color = TextMuted, fontSize = 11.sp)
                }
                Switch(checked = debugLock, onCheckedChange = {
                    store.debugLock = it
                    debugLock = it
                    locked = isLocked(store)
                })
            }
        }
    }

    if (showDisclosure) {
        AlertDialog(
            onDismissRequest = { showDisclosure = false },
            title = { Text(BlockerDisclosure.TITLE) },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    item { Text(BlockerDisclosure.BODY, fontSize = 13.sp) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    store.consentGiven = true
                    showDisclosure = false
                    openAccessibilitySettings(context)
                }) { Text(BlockerDisclosure.AGREE) }
            },
            dismissButton = {
                TextButton(onClick = { showDisclosure = false }) { Text(BlockerDisclosure.DECLINE) }
            }
        )
    }

    if (showPicker) {
        AppPickerDialog(
            initial = blocked,
            onDismiss = { showPicker = false },
            onSave = { chosen ->
                val refusal = BlockListRules.refusal(isLocked(store), enabled, enabled, blocked, chosen)
                if (refusal != null) {
                    message = refusal
                } else {
                    store.blockedApps = chosen
                    blocked = chosen
                    message = null
                }
                showPicker = false
            }
        )
    }
}

@Composable
private fun AppPickerDialog(initial: Set<String>, onDismiss: () -> Unit, onSave: (Set<String>) -> Unit) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<BlockerPackages.AppEntry>?>(null) }
    var chosen by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { BlockerPackages.launchableApps(context) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Apps to block") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                val list = apps
                if (list == null) {
                    Text("Loading apps…", fontSize = 13.sp)
                } else {
                    val shown = list.filter { query.isBlank() || it.label.contains(query.trim(), ignoreCase = true) }
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(shown, key = { it.packageName }) { app ->
                            val checked = app.packageName in chosen
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        chosen = if (checked) chosen - app.packageName else chosen + app.packageName
                                    }
                                    .padding(vertical = 2.dp)
                            ) {
                                Checkbox(checked = checked, onCheckedChange = null)
                                Text(app.label, fontSize = 14.sp, modifier = Modifier.padding(start = 8.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onSave(chosen) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun isLocked(store: BlockerStore): Boolean =
    (BuildConfig.DEBUG && store.debugLock) || store.lockState?.locked == true

private fun openAccessibilitySettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) { }
}

private fun openAppDetails(context: Context) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + context.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) { }
}
