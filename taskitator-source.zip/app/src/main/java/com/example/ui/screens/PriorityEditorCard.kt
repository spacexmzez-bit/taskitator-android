package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CustomPriority
import com.example.ui.theme.*

/** Website Settings > Tasks > Priority levels: rename, recolour, reorder (rank = list order), add, delete. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun PriorityEditorCard(priorities: List<CustomPriority>, onSave: (List<CustomPriority>) -> Unit) {
    val hexRegex = remember { Regex("^#[0-9a-fA-F]{6}$") }
    val palette = listOf("#ef4444", "#f97316", "#eab308", "#22c55e", "#3b82f6", "#8b5cf6", "#ec4899", "#94a3b8")
    var draft by remember(priorities) { mutableStateOf(priorities) }
    val dirty = draft != priorities

    fun colorOf(hex: String): Color = runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(TextMuted)

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, DarkBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Priority levels", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
            Text("Order sets the rank: the top level is the highest priority.", color = TextMuted, fontSize = 11.sp)

            draft.forEachIndexed { idx, p ->
                Surface(shape = RoundedCornerShape(10.dp), color = DarkSurfaceVariant, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(Modifier.size(14.dp).clip(CircleShape).background(colorOf(p.colorHex)))
                            Text("#${idx + 1}", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = p.label,
                                onValueChange = { v -> draft = draft.toMutableList().also { it[idx] = p.copy(label = v.take(30)) } },
                                singleLine = true,
                                label = { Text("Name") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(enabled = idx > 0, onClick = {
                                draft = draft.toMutableList().also { val x = it.removeAt(idx); it.add(idx - 1, x) }
                            }) { Text("▲", fontSize = 13.sp) }
                            TextButton(enabled = idx < draft.lastIndex, onClick = {
                                draft = draft.toMutableList().also { val x = it.removeAt(idx); it.add(idx + 1, x) }
                            }) { Text("▼", fontSize = 13.sp) }
                            Spacer(Modifier.weight(1f))
                            TextButton(enabled = draft.size > 1, onClick = {
                                draft = draft.toMutableList().also { it.removeAt(idx) }
                            }) { Text("Delete", color = DangerRed, fontSize = 12.sp) }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            palette.forEach { hex ->
                                Box(
                                    Modifier.size(26.dp).clip(CircleShape).background(colorOf(hex))
                                        .then(if (p.colorHex.equals(hex, true)) Modifier.background(Color.Transparent) else Modifier)
                                        .let { m -> m }
                                ) {
                                    TextButton(
                                        onClick = { draft = draft.toMutableList().also { it[idx] = p.copy(colorHex = hex) } },
                                        contentPadding = PaddingValues(0.dp),
                                        modifier = Modifier.fillMaxSize()
                                    ) { Text(if (p.colorHex.equals(hex, true)) "✓" else "", color = Color.White, fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = {
                    draft = draft + CustomPriority(
                        id = "prio_${System.currentTimeMillis()}_${(1000..9999).random()}",
                        label = "New level", rank = draft.size + 1, colorHex = palette[draft.size % palette.size]
                    )
                }, modifier = Modifier.weight(1f)) { Text("+ Add level") }
                Button(
                    enabled = dirty && draft.all { it.label.isNotBlank() && hexRegex.matches(it.colorHex) },
                    onClick = { onSave(draft.mapIndexed { i, p -> p.copy(label = p.label.trim(), rank = i + 1) }) },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                    modifier = Modifier.weight(1f)
                ) { Text("Save") }
            }
            if (dirty) Text("Unsaved changes. Deleting a level does not change tasks that already use it.", color = WarningAmber, fontSize = 11.sp)
        }
    }
}
