package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.auth.AccountDeletionRules
import com.example.ui.theme.DangerRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.TaskitatorViewModel

/** Account deletion inside the app: the request, and the status of a request already made. */
@Composable
fun AccountDeletionSection(viewModel: TaskitatorViewModel, signedIn: Boolean) {
    val notice by viewModel.deletionNotice.collectAsState()
    val busy by viewModel.accountBusy.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    Column {
        notice?.let { current ->
            Text("Account deletion", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(current.statusText, color = if (current.complete) TextSecondary else WarningAmber, fontSize = 12.sp)
            Text("Receipt: ${current.receipt.take(12)}…", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!current.complete) {
                    OutlinedButton(onClick = { viewModel.refreshDeletionStatus() }) { Text("Check status", fontSize = 12.sp) }
                    Spacer(Modifier.padding(start = 8.dp))
                }
                TextButton(onClick = { viewModel.dismissDeletionNotice() }) { Text("Hide", fontSize = 12.sp) }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (signedIn) {
            OutlinedButton(
                onClick = { showDialog = true },
                enabled = !busy,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                border = BorderStroke(1.dp, DangerRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_delete_account")
            ) {
                Text("Delete account", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showDialog) {
        var phrase by remember { mutableStateOf("") }
        var blockerOff by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Delete your account?") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "This permanently deletes your Taskitator account and everything in it: tasks, projects, " +
                            "notes, break and sleep settings, and your sign-in. It is deleted for the website too. " +
                            "It cannot be undone.",
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "To confirm it is you, the sign-in page opens next. Enter your sign-in details again for this same " +
                            "account; the deletion is sent once that new sign-in completes. A sign-in that was " +
                            "already open on this phone does not count.",
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = blockerOff, onCheckedChange = { blockerOff = it })
                        Text("App blocking is turned off on every device I use.", fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = phrase,
                        onValueChange = { phrase = it },
                        label = { Text("Type: ${AccountDeletionRules.PHRASE}") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_delete_phrase")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDialog = false
                        viewModel.deleteAccount(phrase.trim(), blockerOff)
                    },
                    enabled = blockerOff && phrase.trim() == AccountDeletionRules.PHRASE,
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
                ) { Text("Sign in and delete") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
        )
    }
}
