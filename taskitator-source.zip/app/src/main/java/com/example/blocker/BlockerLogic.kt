package com.example.blocker

import org.json.JSONObject

/**
 * Pure rules of the app blocker. Nothing here touches Android, so all of it is unit-tested.
 * The lock itself is decided by the Worker (`/status`); this file only applies that answer on the phone.
 */

/** The Worker's last answer to `/status`. */
data class LockState(
    val deviceLocked: Boolean,
    val sleep: Boolean,
    val inBreak: Boolean = false,
    val emergencyBypass: Boolean = false,
    val accountDeleted: Boolean = false,
    val fetchedAtMs: Long = 0L
) {
    /** True when either the task lock or Sleep Lock is on. */
    val locked: Boolean get() = !accountDeleted && (deviceLocked || sleep)

    fun toJson(): JSONObject = JSONObject()
        .put("device_locked", deviceLocked)
        .put("sleep", sleep)
        .put("in_break", inBreak)
        .put("emergency_bypass", emergencyBypass)
        .put("account_deleted", accountDeleted)
        .put("fetched_at", fetchedAtMs)

    companion object {
        /** Reads a `/status` JSON body, or a state saved earlier with [toJson]. */
        fun fromJson(json: JSONObject, fetchedAtMs: Long = json.optLong("fetched_at", 0L)): LockState = LockState(
            deviceLocked = json.optBoolean("device_locked", false),
            sleep = json.optBoolean("sleep", false),
            inBreak = json.optBoolean("in_break", false),
            emergencyBypass = json.optBoolean("emergency_bypass", false),
            accountDeleted = json.optBoolean("account_deleted", false),
            fetchedAtMs = fetchedAtMs
        )

        fun fromSaved(text: String?): LockState? {
            if (text.isNullOrBlank()) return null
            return try { fromJson(JSONObject(text)) } catch (_: Exception) { null }
        }
    }
}

/** What one `/status` call produced. */
sealed class StatusOutcome {
    data class Updated(val state: LockState) : StatusOutcome()
    /** The phone token was revoked or is over the device limit. A new one is needed. */
    object TokenRejected : StatusOutcome()
    /** Network or server trouble. The last known state stays in force. */
    object Unavailable : StatusOutcome()

    companion object {
        fun fromHttp(code: Int, body: String, nowMs: Long): StatusOutcome = when {
            code == 401 -> TokenRejected
            code in 200..299 -> try {
                val json = JSONObject(body)
                if (!json.has("device_locked")) Unavailable else Updated(LockState.fromJson(json, nowMs))
            } catch (_: Exception) {
                Unavailable
            }
            else -> Unavailable
        }
    }
}

enum class BlockVerdict {
    /** Show the block screen. */
    BLOCK,
    /** Hide the block screen. */
    ALLOW,
    /** Not a real app change (keyboard, system panel): leave the screen as it is. */
    IGNORE
}

enum class BlockReason { TASKS, SLEEP }

object BlockDecision {
    /**
     * @param packageName the app that just came to the front
     * @param enabled the user's blocker switch
     * @param state the Worker's last answer, or null if there has never been one
     * @param blocked the apps the user chose to block
     * @param alwaysAllowed apps that are never blocked (this app, dialer, launcher, Settings…)
     * @param transient packages whose windows sit on top of other apps (keyboards, system UI)
     */
    fun decide(
        packageName: String?,
        enabled: Boolean,
        state: LockState?,
        blocked: Set<String>,
        alwaysAllowed: Set<String>,
        transient: Set<String>
    ): BlockVerdict {
        if (packageName.isNullOrBlank()) return BlockVerdict.IGNORE
        if (!enabled || state == null || !state.locked) return BlockVerdict.ALLOW
        if (packageName in alwaysAllowed) return BlockVerdict.ALLOW
        if (packageName in transient) return BlockVerdict.IGNORE
        return if (packageName in blocked) BlockVerdict.BLOCK else BlockVerdict.ALLOW
    }

    /** Why the phone is locked, for the block screen text. Task lock is named first. */
    fun reason(state: LockState?): BlockReason? = when {
        state == null || !state.locked -> null
        state.deviceLocked -> BlockReason.TASKS
        else -> BlockReason.SLEEP
    }
}

/** While the phone is locked the blocker may be tightened but not loosened. */
object BlockListRules {
    const val REFUSED_OFF = "Blocking can't be turned off while your phone is locked. Finish today's tasks or use Emergency Bypass."
    const val REFUSED_REMOVE = "Apps can't be removed from the block list while your phone is locked. You can still add apps."

    /** Returns null when the change is allowed, otherwise the message to show. */
    fun refusal(
        locked: Boolean,
        wasEnabled: Boolean,
        nowEnabled: Boolean,
        oldApps: Set<String>,
        newApps: Set<String>
    ): String? {
        if (!locked) return null
        if (wasEnabled && !nowEnabled) return REFUSED_OFF
        if (wasEnabled && !newApps.containsAll(oldApps)) return REFUSED_REMOVE
        return null
    }

    /** Signing out removes the phone's link to the account, so it is a loosening too. */
    fun signOutRefusal(locked: Boolean, enabled: Boolean): String? =
        if (locked && enabled) "You can't sign out while your phone is locked. Finish today's tasks or use Emergency Bypass." else null
}

/** When to ask the Worker again. */
object StatusRefreshPolicy {
    /** Shortest gap between two calls caused by app switches. */
    const val EVENT_GAP_MS = 15_000L
    /** Timer interval while the service runs. */
    const val PERIODIC_MS = 60_000L
    /** Gap after a failed call, so a dead network is not hammered. */
    const val FAILURE_GAP_MS = 30_000L

    fun due(nowMs: Long, lastAttemptMs: Long, lastFailed: Boolean, forced: Boolean): Boolean {
        if (forced) return true
        val gap = if (lastFailed) FAILURE_GAP_MS else EVENT_GAP_MS
        return lastAttemptMs <= 0L || nowMs - lastAttemptMs >= gap || nowMs < lastAttemptMs
    }
}

/** Lets other parts of the app ask the running service to re-check `/status` right away. */
object BlockerSignals {
    @Volatile
    var onRefreshRequested: (() -> Unit)? = null

    fun requestRefresh() {
        try { onRefreshRequested?.invoke() } catch (_: Exception) { }
    }

    /** Worker routes whose successful POST can change the lock. */
    fun changesLock(path: String, isPost: Boolean): Boolean {
        if (!isPost) return false
        val p = path.substringBefore('?')
        return p == "/breaks" || p == "/sleep-lock" || p == "/emergency" || p == "/sync/push"
    }
}
