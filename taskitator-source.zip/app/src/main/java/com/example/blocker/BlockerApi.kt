package com.example.blocker

import com.example.data.network.TaskitatorWorkerApi
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** The three Worker calls the blocker needs. All of them block; call them off the main thread. */
object BlockerApi {
    data class Device(val token: String, val id: String)

    /** GET /status with the phone token. */
    fun status(phoneToken: String, nowMs: Long = System.currentTimeMillis()): StatusOutcome {
        val (code, body) = call("/status", "GET", phoneToken, null)
        return StatusOutcome.fromHttp(code, body, nowMs)
    }

    /** POST /auth/phone with the session token. Returns the new phone token, or an error message. */
    fun createDevice(sessionToken: String, label: String): Result<Device> {
        val (code, body) = call("/auth/phone", "POST", sessionToken, JSONObject().put("label", label))
        return parseDevice(code, body)
    }

    /** DELETE /auth/phone?device=id with the session token. Best effort. */
    fun deleteDevice(sessionToken: String, deviceId: String): Boolean {
        if (deviceId.isBlank() || !deviceId.all { it.isLetterOrDigit() || it == '-' || it == '_' }) return false
        val (code, _) = call("/auth/phone?device=$deviceId", "DELETE", sessionToken, null)
        return code in 200..299 || code == 404
    }

    fun parseDevice(code: Int, body: String): Result<Device> {
        val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        if (code in 200..299) {
            val token = json.optString("token")
            val id = json.optJSONObject("device")?.optString("id").orEmpty()
            return if (token.startsWith("tkp_")) Result.success(Device(token, id))
            else Result.failure(IllegalStateException("The server did not return a phone token."))
        }
        val message = when (code) {
            409 -> "This account has reached its phone limit. Remove an old phone on the website, then try again."
            401 -> "Sign in again to link this phone."
            0 -> "No connection."
            else -> json.optString("error").ifBlank { "Could not link this phone (HTTP $code)." }
        }
        return Result.failure(IllegalStateException(message))
    }

    /** Returns (HTTP status, body). Status 0 means the request never got an answer. */
    private fun call(path: String, method: String, token: String, body: JSONObject?): Pair<Int, String> {
        if (token.isBlank()) return Pair(0, "")
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(TaskitatorWorkerApi.WORKER_BASE_URL + path).openConnection() as HttpURLConnection
            conn.requestMethod = method
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            conn.setRequestProperty("X-App-ID", "taskitator")
            conn.setRequestProperty(TaskitatorWorkerApi.CLIENT_HEADER, TaskitatorWorkerApi.CLIENT_ANDROID)
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body.toString()) }
            }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            Pair(code, text)
        } catch (_: Exception) {
            Pair(0, "")
        } finally {
            conn?.disconnect()
        }
    }
}

/** Links this phone to the signed-in account so the blocker can read `/status` on its own. */
object BlockerLink {
    /** Makes sure a phone token exists. Returns null on success, otherwise the reason. */
    fun ensureDevice(store: BlockerStore, sessionToken: String, label: String): String? {
        if (store.phoneToken.isNotBlank()) return null
        if (sessionToken.isBlank()) return "Sign in to link this phone."
        val created = BlockerApi.createDevice(sessionToken, label)
        val device = created.getOrNull() ?: return created.exceptionOrNull()?.message ?: "Could not link this phone."
        store.phoneToken = device.token
        store.deviceId = device.id
        return null
    }

    /** Removes this phone from the account and forgets the link. */
    fun unlink(store: BlockerStore, sessionToken: String) {
        val id = store.deviceId
        store.clearAccount()
        if (sessionToken.isNotBlank() && id.isNotBlank()) BlockerApi.deleteDevice(sessionToken, id)
    }
}
