package com.example.blocker

import android.content.Context
import android.content.SharedPreferences
import com.example.data.security.KeystoreTokenStore
import com.example.data.security.TokenStore

/**
 * The blocker's settings on this phone. The list of blocked apps is device-local by design:
 * it is never sent to the Worker. The phone token is stored encrypted.
 */
class BlockerStore(
    context: Context,
    private val phoneTokenStore: TokenStore =
        KeystoreTokenStore(context.applicationContext, KeystoreTokenStore.PHONE_TOKEN_ENTRY)
) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The user read the disclosure and agreed. */
    var consentGiven: Boolean
        get() = prefs.getBoolean(KEY_CONSENT, false)
        set(value) { prefs.edit().putBoolean(KEY_CONSENT, value).apply() }

    var enabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)
        set(value) { prefs.edit().putBoolean(KEY_ENABLED, value).apply() }

    var blockedApps: Set<String>
        get() = HashSet(prefs.getStringSet(KEY_APPS, emptySet()) ?: emptySet())
        set(value) { prefs.edit().putStringSet(KEY_APPS, HashSet(value)).apply() }

    /** The Worker's last answer. Kept across restarts so the lock survives being offline. */
    var lockState: LockState?
        get() = LockState.fromSaved(prefs.getString(KEY_STATE, null))
        set(value) {
            if (value == null) prefs.edit().remove(KEY_STATE).apply()
            else prefs.edit().putString(KEY_STATE, value.toJson().toString()).apply()
        }

    /** Id of this phone in the account's device list, so it can be removed on sign-out. */
    var deviceId: String
        get() = prefs.getString(KEY_DEVICE, "") ?: ""
        set(value) { prefs.edit().putString(KEY_DEVICE, value).apply() }

    /** Debug builds only: pretend the Worker says "locked", to test the block screen without an account. */
    var debugLock: Boolean
        get() = prefs.getBoolean(KEY_DEBUG_LOCK, false)
        set(value) { prefs.edit().putBoolean(KEY_DEBUG_LOCK, value).apply() }

    var phoneToken: String
        get() = phoneTokenStore.read()
        set(value) { if (value.isBlank()) phoneTokenStore.clear() else phoneTokenStore.write(value) }

    /** Forgets the account link. Consent, the switch and the app list stay. */
    fun clearAccount() {
        phoneTokenStore.clear()
        prefs.edit().remove(KEY_STATE).remove(KEY_DEVICE).apply()
    }

    fun addListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(listener)

    fun removeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(listener)

    private companion object {
        const val PREFS = "taskitator_blocker"
        const val KEY_CONSENT = "consent_given"
        const val KEY_ENABLED = "enabled"
        const val KEY_APPS = "blocked_apps"
        const val KEY_STATE = "lock_state"
        const val KEY_DEVICE = "device_id"
        const val KEY_DEBUG_LOCK = "debug_lock"
    }
}
