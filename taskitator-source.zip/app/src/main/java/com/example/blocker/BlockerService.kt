package com.example.blocker

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.PowerManager
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.BuildConfig
import com.example.MainActivity
import com.example.data.security.KeystoreTokenStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Blocks the apps the user chose while the Worker says the phone is locked.
 *
 * What it reads: only the package name of the app that comes to the front
 * (`TYPE_WINDOW_STATE_CHANGED`). It cannot read window content (`canRetrieveWindowContent` is off),
 * performs no gestures or clicks in other apps, and sends nothing about app usage anywhere.
 * The only network call is `GET /status`, which carries no app information.
 */
class BlockerService : AccessibilityService() {
    private val main = Handler(Looper.getMainLooper())
    private var worker: ExecutorService? = null
    private lateinit var store: BlockerStore

    // Read on the main thread only.
    private var enabled = false
    private var blocked: Set<String> = emptySet()
    private var state: LockState? = null
    private var alwaysAllowed: Set<String> = emptySet()
    private var transient: Set<String> = emptySet()
    private var currentPackage: String? = null
    private var screenOn = true

    private var overlay: View? = null
    private var overlayText: TextView? = null

    // Touched on the worker thread only.
    private var lastAttemptMs = 0L
    private var lastFailed = false

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        main.post { loadConfig(); evaluate() }
    }

    private val periodic = object : Runnable {
        override fun run() {
            if (screenOn) refresh(forced = true)
            main.postDelayed(this, StatusRefreshPolicy.PERIODIC_MS)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; hideOverlay() }
                // Phones without a lock screen never send USER_PRESENT, so SCREEN_ON must be enough for them.
                Intent.ACTION_SCREEN_ON -> { screenOn = true; if (!keyguardShowing()) evaluate(); refresh(forced = false) }
                Intent.ACTION_USER_PRESENT -> { screenOn = true; evaluate(); refresh(forced = false) }
            }
        }
    }

    /** The block screen must never cover the phone's own lock screen. */
    private fun keyguardShowing(): Boolean = try {
        (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
    } catch (_: Exception) { false }

    override fun onServiceConnected() {
        super.onServiceConnected()
        store = BlockerStore(this)
        worker = Executors.newSingleThreadExecutor()
        screenOn = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        loadConfig()
        loadPackageSets()
        store.addListener(prefsListener)
        BlockerSignals.onRefreshRequested = { refresh(forced = true) }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter)
        main.removeCallbacks(periodic)
        main.post(periodic)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // Our own block screen and dialogs also raise this event. Only a real screen of this app counts.
        if (pkg == packageName && event.className?.toString()?.startsWith(OWN_CLASS_PREFIX) != true) return
        if (pkg in transient && pkg !in alwaysAllowed) return
        currentPackage = pkg
        evaluate()
        refresh(forced = false)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        main.removeCallbacksAndMessages(null)
        BlockerSignals.onRefreshRequested = null
        if (::store.isInitialized) store.removeListener(prefsListener)
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) { }
        hideOverlay()
        worker?.shutdownNow()
        worker = null
    }

    private fun loadConfig() {
        enabled = store.enabled
        blocked = store.blockedApps
        state = if (BuildConfig.DEBUG && store.debugLock) {
            LockState(deviceLocked = true, sleep = false, fetchedAtMs = System.currentTimeMillis())
        } else {
            store.lockState
        }
    }

    private fun loadPackageSets() {
        alwaysAllowed = BlockerPackages.alwaysAllowed(this)
        transient = BlockerPackages.transient(this)
    }

    /** Shows or hides the block screen for the app now in front. Main thread. */
    private fun evaluate() {
        if (!screenOn) return
        when (BlockDecision.decide(currentPackage, enabled, state, blocked, alwaysAllowed, transient)) {
            BlockVerdict.BLOCK -> showOverlay()
            BlockVerdict.ALLOW -> hideOverlay()
            BlockVerdict.IGNORE -> Unit
        }
    }

    /** Asks the Worker for the lock state, off the main thread. Failures keep the last state. */
    private fun refresh(forced: Boolean) {
        val executor = worker ?: return
        try {
            executor.execute {
                val now = System.currentTimeMillis()
                if (!StatusRefreshPolicy.due(now, lastAttemptMs, lastFailed, forced)) return@execute
                lastAttemptMs = now
                lastFailed = !fetchStatus()
            }
        } catch (_: Exception) {
            // The executor was shut down while the service is closing.
        }
    }

    /** Worker thread. Returns false when the Worker could not be reached. */
    private fun fetchStatus(): Boolean {
        var token = store.phoneToken
        if (token.isBlank()) {
            if (linkPhone() != null) return true // not signed in: nothing to ask
            token = store.phoneToken
        }
        var outcome = BlockerApi.status(token)
        if (outcome is StatusOutcome.TokenRejected) {
            // The token was revoked (for example on the website). Ask for a new one once.
            store.phoneToken = ""
            store.deviceId = ""
            if (linkPhone() != null) return true
            outcome = BlockerApi.status(store.phoneToken)
        }
        return when (outcome) {
            is StatusOutcome.Updated -> { store.lockState = outcome.state; true } // the prefs listener re-evaluates
            is StatusOutcome.TokenRejected -> true
            is StatusOutcome.Unavailable -> false
        }
    }

    private fun linkPhone(): String? =
        BlockerLink.ensureDevice(store, KeystoreTokenStore(this).read(), BlockerPackages.deviceLabel())

    // --- Block screen (accessibility overlay: needs no "draw over other apps" permission) ---

    private fun showOverlay() {
        overlayText?.text = statusLine()
        if (overlay != null) return
        val view = buildOverlay()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        )
        params.gravity = Gravity.CENTER
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(view, params)
            overlay = view
            view.requestFocus()
        } catch (_: Exception) {
            overlay = null
            overlayText = null
        }
    }

    private fun hideOverlay() {
        val view = overlay ?: return
        overlay = null
        overlayText = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(view)
        } catch (_: Exception) { }
    }

    private fun statusLine(): String {
        val current = state
        val why = when (BlockDecision.reason(current)) {
            BlockReason.TASKS -> "Finish today's tasks, or take a break in Taskitator, to open this app."
            BlockReason.SLEEP -> "Sleep Lock is on. This app opens again when it ends."
            null -> ""
        }
        val checked = current?.fetchedAtMs ?: 0L
        val stale = checked > 0L && System.currentTimeMillis() - checked > 5 * 60_000L
        return if (stale) {
            why + "\n\nLast checked " + SimpleDateFormat("h:mm a", Locale.US).format(Date(checked)) +
                ". The lock stays on until the phone can reach Taskitator again."
        } else why
    }

    private fun buildOverlay(): View {
        val pad = dp(28)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(13, 17, 23))
            setPadding(pad, pad, pad, pad)
            isFocusable = true
            isFocusableInTouchMode = true
            isClickable = true
            setOnKeyListener { _, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) goHome()
                    true
                } else false
            }
        }
        root.addView(TextView(this).apply {
            text = "This app is blocked"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        val body = TextView(this).apply {
            text = statusLine()
            setTextColor(Color.rgb(200, 205, 212))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(26))
        }
        overlayText = body
        root.addView(body)
        root.addView(button("Open Taskitator") { openApp(emergency = false) })
        root.addView(button("Emergency Bypass") { openApp(emergency = true) })
        root.addView(button("Go to home screen") { goHome() })
        return root
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setAllCaps(false)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) }
        setOnClickListener { action() }
    }

    private fun openApp(emergency: Boolean) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            if (emergency) putExtra(EXTRA_OPEN_EMERGENCY, true)
        }
        try {
            startActivity(intent)
            currentPackage = packageName
            hideOverlay()
        } catch (_: Exception) {
            goHome()
        }
    }

    private fun goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
        currentPackage = null
        hideOverlay()
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()

    companion object {
        const val EXTRA_OPEN_EMERGENCY = "open_emergency"
        private const val OWN_CLASS_PREFIX = "com.example."
    }
}
