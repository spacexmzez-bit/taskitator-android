package com.example.blocker

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager

/** Looks up which packages get special treatment. Android-only glue; the rules are in BlockerLogic. */
object BlockerPackages {
    data class AppEntry(val packageName: String, val label: String)

    /** Never blocked, whatever the user picked: the user must always be able to call, go home and reach Settings. */
    private val FIXED_ALLOWED = setOf(
        "com.android.settings",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.dialer",
        "com.android.incallui",
        "com.android.emergency",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.google.android.dialer",
        "com.google.android.apps.safetyhub",
        "com.samsung.android.dialer",
        "com.samsung.android.incallui",
        "com.samsung.android.app.telephonyui",
        "com.miui.securitycenter"
    )

    fun alwaysAllowed(context: Context): Set<String> {
        val result = HashSet(FIXED_ALLOWED)
        result.add(context.packageName)
        val pm = context.packageManager
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.queryIntentActivities(home, 0).forEach { result.add(it.activityInfo.packageName) }
        } catch (_: Exception) { }
        try {
            val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))
            pm.queryIntentActivities(dial, 0).forEach { result.add(it.activityInfo.packageName) }
        } catch (_: Exception) { }
        try {
            val telecom = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            telecom?.defaultDialerPackage?.let { result.add(it) }
        } catch (_: Exception) { }
        return result
    }

    /** Keyboards and the system UI draw on top of other apps; they are not an app change. */
    fun transient(context: Context): Set<String> {
        val result = hashSetOf("com.android.systemui")
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.enabledInputMethodList?.forEach { result.add(it.packageName) }
        } catch (_: Exception) { }
        return result
    }

    /** Apps with a launcher icon that the user may block, sorted by name. Call off the main thread. */
    fun launchableApps(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val never = alwaysAllowed(context) + transient(context)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            pm.queryIntentActivities(launcher, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .filter { it !in never }
                .map { pkg ->
                    val label = try {
                        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                    } catch (_: Exception) { pkg }
                    AppEntry(pkg, label)
                }
                .sortedBy { it.label.lowercase() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** True when the user has switched the service on in Android's accessibility settings. */
    fun isServiceEnabled(context: Context): Boolean {
        val wanted = ComponentName(context, BlockerService::class.java)
        val enabled = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        } catch (_: Exception) { null } ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == wanted }
    }

    /** The Worker keeps at most 24 characters. */
    fun deviceLabel(): String = ("App: " + (Build.MODEL ?: "Android")).take(24)
}
