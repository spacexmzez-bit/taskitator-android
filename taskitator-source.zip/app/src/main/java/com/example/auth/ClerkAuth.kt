package com.example.auth

import android.app.Application
import com.clerk.api.Clerk
import com.clerk.api.hostedauth.HostedAuthCancellationException
import com.clerk.api.network.serialization.ClerkResult
import com.clerk.api.network.serialization.errorMessage
import com.example.data.network.SessionTokens
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull

/**
 * The only file that talks to the Clerk Android SDK.
 *
 * Sign-in uses Clerk's hosted pages in a browser tab; the SDK brings the session back into the app
 * and keeps it on the device. Session tokens last about a minute, so the rest of the app asks
 * [token] (through [SessionTokens]) before each Worker call instead of keeping one.
 */
object ClerkAuth {
    /** Public by design (it is also in the website's source). Production instance, clerk.mazendev.com. */
    const val PUBLISHABLE_KEY = "pk_live_Y2xlcmsubWF6ZW5kZXYuY29tJA"

    sealed class SignInResult {
        /** @param sameUser true when the account is the one that was signed in before this sign-in. */
        data class Success(val token: String, val sameUser: Boolean) : SignInResult()
        /** The user closed the browser tab. Any earlier session has been closed by then. */
        object Cancelled : SignInResult()
        /** @param signedOut true when the earlier session was already closed before the failure. */
        data class Failed(val message: String, val signedOut: Boolean = false) : SignInResult()
    }

    fun init(app: Application) {
        Clerk.initialize(app, publishableKey = PUBLISHABLE_KEY)
        SessionTokens.source = { token() }
    }

    /** The SDK loads in the background after [init]. False means it is still not ready (usually: offline). */
    suspend fun awaitReady(timeoutMs: Long = 10_000L): Boolean =
        withTimeoutOrNull(timeoutMs) { Clerk.isInitialized.first { it } } == true

    /** A fresh session token, or null when signed out or the token could not be refreshed. */
    suspend fun token(): String? {
        if (!awaitReady()) return null
        return when (val result = Clerk.auth.getToken()) {
            is ClerkResult.Success -> result.value
            is ClerkResult.Failure -> null
        }
    }

    /** Null while the SDK is not ready; otherwise whether it holds a session. */
    suspend fun hasSession(): Boolean? = if (awaitReady()) Clerk.session != null else null

    /**
     * Opens Clerk's sign-in page and waits for the user to finish.
     * Any session already on the device is signed out first, so this also serves for switching
     * accounts and for "sign in again to confirm".
     */
    suspend fun signIn(): SignInResult {
        if (!awaitReady(15_000L)) {
            return SignInResult.Failed("Could not reach the sign-in service. Check your connection and try again.")
        }
        val previousUser = Clerk.user?.id ?: Clerk.session?.user?.id
        val hadSession = Clerk.session != null
        if (hadSession) Clerk.auth.signOut()
        return when (val result = Clerk.auth.startHostedAuth()) {
            is ClerkResult.Success -> {
                val token = token()
                val user = result.value.user?.id ?: Clerk.user?.id
                if (token.isNullOrBlank()) SignInResult.Failed("Signed in, but the session could not be read. Try again.", signedOut = true)
                else SignInResult.Success(token, sameUser = previousUser != null && previousUser == user)
            }
            is ClerkResult.Failure ->
                if (result.throwable is HostedAuthCancellationException) SignInResult.Cancelled
                else SignInResult.Failed(result.errorMessage, signedOut = hadSession)
        }
    }

    /** Ends the session on this device. Best effort when offline. */
    suspend fun signOut() {
        if (!awaitReady(5_000L)) return
        try {
            Clerk.auth.signOut()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }
}
