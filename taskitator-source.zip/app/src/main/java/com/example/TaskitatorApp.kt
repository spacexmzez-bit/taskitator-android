package com.example

import android.app.Application
import com.example.auth.ClerkAuth
import com.example.data.util.CrashReport

class TaskitatorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Keep the last crash so Settings > Account can show it. The system's own handling still runs after.
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                CrashReport.save(filesDir, CrashReport.format(error, thread.name, System.currentTimeMillis()))
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
        // Also runs when only the app blocker service starts, so the blocker can refresh its own link.
        ClerkAuth.init(this)
    }
}
