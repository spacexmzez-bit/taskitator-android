package com.example

import android.app.Application
import com.example.auth.ClerkAuth

class TaskitatorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Also runs when only the app blocker service starts, so the blocker can refresh its own link.
        ClerkAuth.init(this)
    }
}
