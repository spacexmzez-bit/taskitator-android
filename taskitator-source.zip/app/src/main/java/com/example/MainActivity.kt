package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.blocker.BlockerService
import com.example.ui.MainApp
import com.example.ui.theme.TaskitatorTheme
import com.example.ui.viewmodel.TaskitatorViewModel
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {
    /** Set when the block screen's "Emergency Bypass" button opened the app. */
    private val openEmergency = mutableStateOf(false)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readBlockerIntent(intent)
    }

    private fun readBlockerIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(BlockerService.EXTRA_OPEN_EMERGENCY, false) == true) {
            intent.removeExtra(BlockerService.EXTRA_OPEN_EMERGENCY)
            openEmergency.value = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) readBlockerIntent(intent)
        setContent {
            val viewModel: TaskitatorViewModel = viewModel()
            if (openEmergency.value) {
                LaunchedEffect(Unit) {
                    viewModel.openEmergencyDialog()
                    openEmergency.value = false
                }
            }
            val settings by viewModel.settings.collectAsState()
            TaskitatorTheme(natureTheme = settings.appearanceTheme == "nature") {
                CompositionLocalProvider(LocalLayoutDirection provides
                    if (settings.language == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr) {
                    MainApp(viewModel = viewModel)
                }
            }
        }
    }
}
