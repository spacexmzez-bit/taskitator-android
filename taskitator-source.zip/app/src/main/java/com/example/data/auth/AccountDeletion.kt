package com.example.data.auth

import org.json.JSONObject
import java.security.SecureRandom

/** What the Worker said about a deletion request. Kept on the phone so the status can be checked later. */
data class DeletionNotice(
    val receipt: String,
    val status: String,
    val complete: Boolean,
    val phoneRecoveryUntilMs: Long
) {
    fun toJson(): JSONObject = JSONObject()
        .put("receipt", receipt).put("status", status).put("complete", complete)
        .put("phone_recovery_until", phoneRecoveryUntilMs)

    val statusText: String get() = when {
        complete -> "Your account and its data have been deleted."
        status == "retrying" -> "Deletion is in progress. Some data is still being removed."
        else -> "Deletion was accepted and is in progress."
    }

    companion object {
        /** Reads the answer of `DELETE /auth/account`, of `/auth/deletion/status`, or a saved notice. */
        fun parse(json: JSONObject, receipt: String = json.optString("receipt")): DeletionNotice? {
            val id = json.optString("receipt").ifBlank { receipt }
            if (!AccountDeletionRules.isReceipt(id)) return null
            if (!json.optBoolean("accepted", json.has("status"))) return null
            val status = json.optString("status", "pending").ifBlank { "pending" }
            return DeletionNotice(
                receipt = id,
                status = status,
                complete = json.optBoolean("complete", status == "complete"),
                phoneRecoveryUntilMs = json.optLong("phone_recovery_until", 0L)
            )
        }

        fun fromSaved(text: String?): DeletionNotice? {
            if (text.isNullOrBlank()) return null
            return try { parse(JSONObject(text)) } catch (_: Exception) { null }
        }
    }
}

/**
 * The app's side of account deletion. The Worker decides; these checks only stop requests the
 * Worker would refuse anyway, and build the bodies it expects (see docs/WORKER_CONTRACTS.md).
 */
object AccountDeletionRules {
    /** Must match the Worker exactly, including capitals. */
    const val PHRASE = "Delete my account"
    const val VERIFY_METHOD = "signin"
    const val ACTION = "delete-account"

    /** Returns null when the request may go ahead, otherwise what to tell the user. */
    fun refusal(typedPhrase: String, blockerOffConfirmed: Boolean, blockerEnabledHere: Boolean, phoneLocked: Boolean): String? = when {
        blockerEnabledHere && phoneLocked ->
            "You can't delete your account while your phone is locked. Finish today's tasks or use Emergency Bypass."
        blockerEnabledHere ->
            "Turn off \"Block apps while locked\" in Settings > Phone Lock first."
        !blockerOffConfirmed ->
            "Confirm that app blocking is off on every device."
        typedPhrase != PHRASE ->
            "Type $PHRASE exactly."
        else -> null
    }

    fun isReceipt(value: String): Boolean = value.length == 64 && value.all { it in '0'..'9' || it in 'a'..'f' }

    /** 64 lowercase hex characters, as the Worker requires. */
    fun newReceipt(random: SecureRandom = SecureRandom()): String {
        val bytes = ByteArray(32).also { random.nextBytes(it) }
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun startBody(): JSONObject = JSONObject().put("method", VERIFY_METHOD).put("action", ACTION)

    fun deleteBody(verificationId: String, receipt: String): JSONObject = JSONObject()
        .put("blocker_disabled", true)
        .put("phrase", PHRASE)
        .put("receipt", receipt)
        .put("verification_id", verificationId)

    fun statusBody(receipt: String): JSONObject = JSONObject().put("receipt", receipt)
}
