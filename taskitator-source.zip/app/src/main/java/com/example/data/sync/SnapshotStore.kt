package com.example.data.sync

import org.json.JSONObject
import java.io.File

/** File names for one account. Each account gets its own set of files. */
object AccountPaths {
    fun safeUserId(user: String): String = user.ifBlank { "anonymous" }.replace(Regex("[^a-zA-Z0-9_-]"), "_")
    fun snapshot(user: String) = "taskitator_${safeUserId(user)}_snapshot.json"
    fun base(user: String) = "taskitator_${safeUserId(user)}_base.json"
    fun recovery(user: String) = "taskitator_${safeUserId(user)}_recovery.json"
    fun conflictBackup(user: String) = "taskitator_${safeUserId(user)}_conflict_backup.json"
    fun notes(user: String) = "taskitator_${safeUserId(user)}_notes.json"
}

/** Reads and writes one account's snapshot with a recovery copy. Plain java.io, no Android. */
class SnapshotStore(private val dir: File, private val user: String) {
    val snapshotFile: File get() = File(dir, AccountPaths.snapshot(user))
    val recoveryFile: File get() = File(dir, AccountPaths.recovery(user))
    val baseFile: File get() = File(dir, AccountPaths.base(user))

    /** Returns the saved snapshot; falls back to the recovery copy when the main file is unreadable. */
    fun load(): JSONObject? {
        read(snapshotFile)?.let { return it }
        val recovered = read(recoveryFile) ?: return null
        try { recoveryFile.copyTo(snapshotFile, overwrite = true) } catch (_: Exception) {}
        return recovered
    }

    /** Writes to a temp file first, keeps the previous good copy as recovery, then swaps. */
    fun save(snapshot: JSONObject): Boolean {
        val target = snapshotFile
        val tmp = File(dir, "${target.name}.tmp")
        return try {
            tmp.writeText(snapshot.toString(2))
            if (read(target) != null) target.copyTo(recoveryFile, overwrite = true)
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }
            true
        } catch (_: Exception) {
            tmp.delete()
            false
        }
    }

    fun loadBase(): JSONObject? = read(baseFile)

    fun saveBase(base: JSONObject) {
        try { baseFile.writeText(base.toString(2)) } catch (_: Exception) {}
    }

    private fun read(file: File): JSONObject? = try {
        if (file.exists() && file.length() > 0) JSONObject(file.readText()) else null
    } catch (_: Exception) {
        null
    }
}
