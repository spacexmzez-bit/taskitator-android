package com.example.data.repository

import android.content.Context
import android.util.AtomicFile
import com.clerk.api.Clerk
import com.clerk.api.network.serialization.ClerkResult
import com.example.data.sync.SnapshotMerge
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import com.example.data.model.*
import com.example.data.network.*
import com.example.data.util.CriteriaValidator
import com.example.data.util.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class TaskRepository(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.IO)
    private val authPrefs = context.getSharedPreferences("taskitator_auth_identity", Context.MODE_PRIVATE)
    private val syncMutex = Mutex()

    // Auth & Account State (Phase 1.1)
    private val _authState = MutableStateFlow<AuthState>(AuthState.SignedOut)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    // Sync state
    private val _syncState = MutableStateFlow(SyncState.IDLE)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _syncStatusMessage = MutableStateFlow<String?>(null)
    val syncStatusMessage: StateFlow<String?> = _syncStatusMessage.asStateFlow()

    // Conflict Report State (Phase 1.3)
    private val _syncConflictReport = MutableStateFlow<SyncConflictReport?>(null)
    val syncConflictReport: StateFlow<SyncConflictReport?> = _syncConflictReport.asStateFlow()

    // Core Task State
    private val _tasks = MutableStateFlow<List<Task>>(emptyList())
    val tasks: StateFlow<List<Task>> = _tasks.asStateFlow()

    private val _settings = MutableStateFlow(UserSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private val _savedCriteria = MutableStateFlow<List<SavedCriteria>>(emptyList())
    val savedCriteria: StateFlow<List<SavedCriteria>> = _savedCriteria.asStateFlow()

    private val _breakPlanning = MutableStateFlow(BreakPlanningState())
    val breakPlanning: StateFlow<BreakPlanningState> = _breakPlanning.asStateFlow()

    private val _breaks = MutableStateFlow<List<BreakSession>>(emptyList())
    val breaks: StateFlow<List<BreakSession>> = _breaks.asStateFlow()

    private val _notes = MutableStateFlow<List<DistractionNote>>(emptyList())
    val notes: StateFlow<List<DistractionNote>> = _notes.asStateFlow()

    private val _pomodoro = MutableStateFlow(PomodoroState())
    val pomodoro: StateFlow<PomodoroState> = _pomodoro.asStateFlow()

    private val _lastCompletedTask = MutableStateFlow<Task?>(null)
    val lastCompletedTask: StateFlow<Task?> = _lastCompletedTask.asStateFlow()

    // Authoritative Raw JSON trees (Phase 1.2)
    private var rawSnapshot: JSONObject = JSONObject()
    private var baseSnapshot: JSONObject = JSONObject()
    private var baseVersion: Long = 0L
    private var baseIsTrusted = false

    // In-flight idempotent upload tracking
    private var pendingMutationId: String? = null
    private var pendingPushPayload: JSONObject? = null
    private var isSyncInProgress: Boolean = false
    private var verifiedClerkId: String? = null
    @Volatile private var identityEpoch: Long = 0L

    init {
        // Clerk owns session restoration. Never trust a persisted bearer token.
        authPrefs.edit().remove("saved_token").apply()
        loadData()
    }

    // --- Account Isolation & File Paths (Phase 1.1) ---

    private fun getSafeUserId(): String {
        val worker = (_authState.value as? AuthState.Authenticated)?.workerUser
        // No signed-in account -> anonymous sandbox. Do not expose another user's cache.
        return (worker ?: "anonymous").replace(Regex("[^a-zA-Z0-9_-]"), "_")
    }

    private fun getSnapshotFile(): File = File(context.filesDir, "taskitator_${getSafeUserId()}_snapshot.json")
    private fun getBaseSnapshotFile(): File = File(context.filesDir, "taskitator_${getSafeUserId()}_base.json")
    private fun getRecoveryFile(): File = File(context.filesDir, "taskitator_${getSafeUserId()}_recovery.json")
    private fun getBackupFile(): File = File(context.filesDir, "taskitator_${getSafeUserId()}_conflict_backup.json")
    private val notesFile: File get() = File(context.filesDir, "taskitator_${getSafeUserId()}_notes.json")

    private suspend fun freshClerkToken(): String? {
        val clerkId = verifiedClerkId ?: return null
        if (Clerk.activeUser?.id != clerkId) return null
        return when (val result = Clerk.auth.getToken()) {
            is ClerkResult.Success -> result.value.also { _settings.value = _settings.value.copy(authToken = it) }
            is ClerkResult.Failure -> null
        }
    }

    suspend fun signInWithClerk(clerkUserId: String): Pair<Boolean, String> {
        if (Clerk.activeUser?.id != clerkUserId) return false to "Clerk session is not active."
        identityEpoch++
        val epoch = identityEpoch
        verifiedClerkId = clerkUserId
        _authState.value = AuthState.Connecting
        val token = freshClerkToken()
        if (token.isNullOrBlank()) {
            _authState.value = AuthState.Error("Clerk could not provide a session token. Retry sign-in.")
            return false to "Clerk token unavailable."
        }
        val result = TaskitatorWorkerApi.getAuthMe(token)
        if (identityEpoch != epoch || Clerk.activeUser?.id != clerkUserId) return false to "Clerk account changed."
        if (result.isFailure) {
            val ex = result.exceptionOrNull()
            if (ex is UnauthorizedException) _authState.value = AuthState.SessionExpired("Worker rejected the Clerk session. Native JWT compatibility must be fixed on the Worker.")
            else if (ex is AccountDeletedException) _authState.value = AuthState.AccountDeleted("Account deletion is pending.")
            else if (ex is WorkerProtectionException) _authState.value = AuthState.Error("Worker access rejected: ${ex.message}")
            else {
                val oldId = authPrefs.getString("saved_clerk_user", null)
                val worker = authPrefs.getString("saved_worker_user", null)
                if (oldId == clerkUserId && !worker.isNullOrBlank()) {
                    _authState.value = AuthState.Authenticated(clerkUserId, worker, authPrefs.getString("saved_username", worker) ?: worker, isOffline = true)
                    loadData()
                    _syncState.value = SyncState.OFFLINE
                    return true to "Offline: previously verified account data available. Cloud writes disabled."
                }
                _authState.value = AuthState.Error(ex?.message ?: "Unable to verify account.")
            }
            return false to (_authState.value.toString())
        }
        val account = result.getOrThrow().optJSONObject("account")
        if (account == null) {
            _authState.value = AuthState.Unlinked(clerkUserId, "")
            return false to "Create a Taskitator cloud account to continue."
        }
        val worker = account.optString("user")
        if (worker.isBlank()) {
            _authState.value = AuthState.Error("Worker returned an invalid account identity.")
            return false to "Invalid account identity."
        }
        val username = account.optString("display_name", worker)
        // Never reuse another account's cache. Only restore cache after verified identity.
        authPrefs.edit().putString("saved_clerk_user", clerkUserId)
            .putString("saved_worker_user", worker).putString("saved_username", username).commit()
        _authState.value = AuthState.Authenticated(clerkUserId, worker, username)
        _settings.value = _settings.value.copy(authToken = token, clerkUserId = clerkUserId,
            workerUser = worker, username = username, needsInitialPull = true)
        loadData()
        return initialPull()
    }

    suspend fun connectWorkerAccount(): Pair<Boolean, String> {
        val clerkId = verifiedClerkId ?: return false to "Clerk sign-in required."
        val token = freshClerkToken() ?: return false to "Clerk session unavailable."
        val result = TaskitatorWorkerApi.connectAccount(token, "create")
        if (result.isFailure) return false to (result.exceptionOrNull()?.message ?: "Account connection failed.")
        return signInWithClerk(clerkId)
    }

    fun signOut() {
        identityEpoch++
        verifiedClerkId = null
        authPrefs.edit().clear().commit()
        _authState.value = AuthState.SignedOut
        _settings.value = UserSettings(needsInitialPull = true)
        _tasks.value = emptyList()
        _syncConflictReport.value = null
        pendingMutationId = null
        pendingPushPayload = null
        baseVersion = 0L
        loadData()
    }

    // --- Lossless Local Storage & Recovery (Phase 1.2) ---

    private fun loadData() {
        val sFile = getSnapshotFile()
        val rFile = getRecoveryFile()
        var loaded = false

        if (sFile.exists() && sFile.length() > 0) {
            try {
                val jsonStr = sFile.readText()
                if (jsonStr.isNotBlank()) {
                    rawSnapshot = JSONObject(jsonStr)
                    baseVersion = rawSnapshot.optLong("version", 0L)
                    parseSnapshot(rawSnapshot)
                    loaded = true
                }
            } catch (e: Exception) {
                // Primary snapshot file corrupted; attempt recovery
            }
        }

        if (!loaded && rFile.exists() && rFile.length() > 0) {
            try {
                val rJsonStr = rFile.readText()
                if (rJsonStr.isNotBlank()) {
                    rawSnapshot = JSONObject(rJsonStr)
                    baseVersion = rawSnapshot.optLong("version", 0L)
                    parseSnapshot(rawSnapshot)
                    loaded = true
                    // Safely restore primary file from recovery
                    rFile.copyTo(sFile, overwrite = true)
                }
            } catch (e: Exception) {
                // Recovery file corrupted
            }
        }

        if (!loaded) {
            if (sFile.exists() || rFile.exists()) {
                // Never silently overwrite corrupted user data with an empty snapshot.
                val quarantine = File(context.filesDir, "taskitator_${getSafeUserId()}_corrupt_${System.currentTimeMillis()}.json")
                if (sFile.exists()) sFile.copyTo(quarantine, overwrite = false)
                _syncState.value = SyncState.ERROR
                _syncStatusMessage.value = "Local cache unreadable. A recovery copy was retained."
            }
            initDefaultSnapshot()
        }

        val bFile = getBaseSnapshotFile()
        baseIsTrusted = false
        if (bFile.exists() && bFile.length() > 0) {
            try {
                baseSnapshot = JSONObject(bFile.readText())
                baseIsTrusted = true
            } catch (e: Exception) {
                baseSnapshot = JSONObject(rawSnapshot.toString())
            }
        } else {
            baseSnapshot = JSONObject(rawSnapshot.toString())
        }

        baseVersion = baseSnapshot.optLong("version", 0L)
        pendingPushPayload = try {
            val f = File(context.filesDir, "taskitator_${getSafeUserId()}_pending.json")
            if (f.exists()) JSONObject(f.readText()) else null
        } catch (_: Exception) { null }
        pendingMutationId = pendingPushPayload?.optString("mutation_id")?.takeIf { it.isNotBlank() }
        _notes.value = readNotesAndCleanup()
        checkEmergencyBypassCycleReset()
    }

    private fun initDefaultSnapshot() {
        rawSnapshot = JSONObject().apply {
            put("app", "taskitator")
            put("username", (_authState.value as? AuthState.Authenticated)?.workerUser ?: "")
            put("updated_at", System.currentTimeMillis())
            put("force", false)
            put("recurrence_state", JSONObject())
            put("recurrence_schema", 1)
            put("tasks", JSONArray())
            put("projects", JSONArray())
            put("settings", JSONObject())
            put("today_breaks", JSONObject())
            put("completed_audit_ledger", JSONArray())
            put("saved_criteria", JSONArray())
            put("last_login", System.currentTimeMillis())
        }

        // Strict invariant: NO DEMO TASKS.
        _tasks.value = emptyList()
        _settings.value = _settings.value.copy(needsInitialPull = true)
        saveLocalSnapshot()
    }

    private fun parseSnapshot(json: JSONObject) {
        // 1. Settings
        val settingsObj = json.optJSONObject("settings") ?: JSONObject()
        val customPrioList = mutableListOf<CustomPriority>()
        val customPrioArr = settingsObj.optJSONArray("custom_priorities")
        if (customPrioArr != null && customPrioArr.length() > 0) {
            for (i in 0 until customPrioArr.length()) {
                val p = customPrioArr.getJSONObject(i)
                customPrioList.add(
                    CustomPriority(
                        id = p.getString("id"),
                        label = p.getString("label"),
                        rank = p.getInt("rank"),
                        colorHex = p.optString("color", "#3B82F6")
                    )
                )
            }
        } else {
            customPrioList.addAll(DEFAULT_PRIORITIES)
        }

        val customTagsList = mutableListOf<String>()
        val tagsArr = settingsObj.optJSONArray("custom_tags")
        if (tagsArr != null && tagsArr.length() > 0) {
            for (i in 0 until tagsArr.length()) {
                customTagsList.add(tagsArr.getString(i))
            }
        } else {
            customTagsList.addAll(DEFAULT_TAGS)
        }

        _settings.value = _settings.value.copy(
            username = json.optString("username", _settings.value.username),
            copilotName = settingsObj.optString("copilot_name", "Ari"),
            isPro = settingsObj.optBoolean("is_pro", false),
            useByok = settingsObj.optBoolean("use_byok", false),
            dayStartHour = settingsObj.optInt("day_start_hour", 0).coerceIn(0, 4),
            weekendStart = settingsObj.optInt("weekend_start", 5),
            weekendEnd = settingsObj.optInt("weekend_end", 6),
            breakTimezone = settingsObj.optString("break_timezone", "UTC"),
            dumpDurationSeconds = settingsObj.optInt("dump_duration", 90).coerceIn(30, 300),
            strictCriteriaValidation = settingsObj.optBoolean("strict_criteria_validation", true),
            soundEffectsEnabled = settingsObj.optBoolean("sound_effects_enabled", true),
            hapticsEnabled = settingsObj.optBoolean("haptics_enabled", true),
            emergencyBypassUsesRemaining = settingsObj.optInt("emergency_bypass_uses", 4),
            emergencyBypassActive = settingsObj.optBoolean("emergency_bypass_active", false),
            emergencyBypassUntil = settingsObj.optLong("emergency_bypass_until", 0L),
            customPriorities = customPrioList,
            customTags = customTagsList,
            remoteVersion = baseVersion
        )

        // 2. Tasks
        val tasksArr = json.optJSONArray("tasks") ?: JSONArray()
        val loadedTasks = mutableListOf<Task>()
        for (i in 0 until tasksArr.length()) {
            val t = tasksArr.getJSONObject(i)
            val tags = mutableListOf<String>()
            val tArr = t.optJSONArray("tags")
            if (tArr != null) {
                for (j in 0 until tArr.length()) tags.add(tArr.getString(j))
            }

            val unmapped = mutableMapOf<String, Any?>()
            val iter = t.keys()
            val known = setOf("id", "parent_id", "title", "raw_title", "description", "due_date", "priority_id", "tags", "status", "ai_locked", "proof_criteria", "raw_proof_criteria", "strict_prerequisites", "is_bonus", "created_at", "completed_at", "order_index")
            while (iter.hasNext()) {
                val k = iter.next()
                if (k !in known) unmapped[k] = t.opt(k)
            }

            val statusStr = t.optString("status", "active").lowercase()
            val status = when (statusStr) {
                "completed" -> TaskStatus.COMPLETED
                "trash" -> TaskStatus.TRASH
                else -> TaskStatus.ACTIVE
            }

            loadedTasks.add(
                Task(
                    id = t.optString("id", UUID.randomUUID().toString()),
                    parentId = t.optString("parent_id").takeIf { it.isNotBlank() },
                    title = t.optString("title", ""),
                    rawTitle = t.optString("raw_title", t.optString("title", "")),
                    description = t.optString("description", ""),
                    dueDate = t.optString("due_date", ""),
                    priorityId = t.optString("priority_id", "prio_med"),
                    tags = tags,
                    status = status,
                    aiLocked = t.optBoolean("ai_locked", false),
                    auditApproved = t.optBoolean("audit_approved", false),
                    proofCriteria = t.optString("proof_criteria", ""),
                    rawProofCriteria = t.optString("raw_proof_criteria", ""),
                    requireAllSubtasksFirst = t.optBoolean("strict_prerequisites", false),
                    isBonus = t.optBoolean("is_bonus", false),
                    smartEarlyDate = t.optString("smart_early_date").takeIf { it.isNotBlank() },
                    projectId = t.optString("project_id").takeIf { it.isNotBlank() },
                    createdAt = t.optLong("created_at", System.currentTimeMillis()),
                    completedAt = t.optLong("completed_at").takeIf { it > 0 },
                    orderIndex = t.optInt("order_index", i),
                    unmappedFields = unmapped
                )
            )
        }
        _tasks.value = loadedTasks

        // 3. Saved Criteria
        val scArr = json.optJSONArray("saved_criteria") ?: JSONArray()
        val scList = mutableListOf<SavedCriteria>()
        for (i in 0 until scArr.length()) {
            val sc = scArr.getJSONObject(i)
            scList.add(
                SavedCriteria(
                    id = sc.optString("id", UUID.randomUUID().toString()),
                    title = sc.optString("title", ""),
                    criteria = sc.optString("criteria", ""),
                    score = sc.optInt("score", 9),
                    hasExemplar = sc.optBoolean("has_exemplar", false),
                    exemplar = sc.optString("exemplar").takeIf { it.isNotBlank() },
                    createdAt = sc.optLong("created_at", System.currentTimeMillis())
                )
            )
        }
        _savedCriteria.value = scList
    }

    /**
     * Atomically saves the authoritative raw snapshot with safety recovery backup.
     */
    private fun saveLocalSnapshot() {
        val target = getSnapshotFile()
        val atomic = AtomicFile(target)
        val bytes = rawSnapshot.toString().toByteArray(Charsets.UTF_8)
        val stream = atomic.startWrite()
        try {
            stream.write(bytes)
            atomic.finishWrite(stream)
            // Recovery is a copy of the LAST successfully written snapshot, not an old one.
            getRecoveryFile().writeBytes(bytes)
        } catch (e: Exception) {
            atomic.failWrite(stream)
            _syncState.value = SyncState.ERROR
            _syncStatusMessage.value = "Local storage failed. Do not uninstall the app: ${e.message}"
            throw e
        }
    }

    private fun saveBaseSnapshot() {
        val file = AtomicFile(getBaseSnapshotFile())
        val out = file.startWrite()
        try { out.write(baseSnapshot.toString().toByteArray()); file.finishWrite(out) }
        catch (e: Exception) { file.failWrite(out); throw e }
    }

    private fun savePendingPayload() {
        val file = File(context.filesDir, "taskitator_${getSafeUserId()}_pending.json")
        if (pendingPushPayload == null) { file.delete(); return }
        val atomic = AtomicFile(file)
        val out = atomic.startWrite()
        try { out.write(pendingPushPayload!!.toString().toByteArray()); atomic.finishWrite(out) }
        catch (e: Exception) { atomic.failWrite(out); throw e }
    }

    /**
     * Targeted field update: modifies ONLY the specific task's fields in the raw JSON,
     * guaranteeing 100% preservation of unknown fields, recurrence state, and web metadata.
     */
    private fun applyTaskToRawSnapshot(task: Task) {
        val tasksArr = rawSnapshot.optJSONArray("tasks") ?: JSONArray().also { rawSnapshot.put("tasks", it) }
        var taskObj: JSONObject? = null
        for (i in 0 until tasksArr.length()) {
            val obj = tasksArr.getJSONObject(i)
            if (obj.optString("id") == task.id) {
                taskObj = obj
                break
            }
        }

        if (taskObj == null) {
            // New task created on Android
            taskObj = JSONObject().apply {
                put("id", task.id)
                if (task.parentId != null) put("parent_id", task.parentId)
                put("title", task.title)
                put("raw_title", task.rawTitle)
                put("description", task.description)
                put("due_date", task.dueDate)
                put("priority_id", task.priorityId)
                put("tags", JSONArray(task.tags))
                put("status", task.status.name.lowercase())
                put("ai_locked", task.aiLocked)
                put("audit_approved", task.auditApproved)
                put("proof_criteria", task.proofCriteria)
                put("raw_proof_criteria", task.rawProofCriteria)
                put("strict_prerequisites", task.requireAllSubtasksFirst)
                put("is_bonus", task.isBonus)
                if (task.projectId != null) put("project_id", task.projectId)
                put("created_at", task.createdAt)
                if (task.completedAt != null) put("completed_at", task.completedAt)
                put("order_index", task.orderIndex)
            }
            tasksArr.put(taskObj)
        } else {
            // Compare the raw stored value to the new model. Only modify fields that
            // actually changed, and never synthesize fields that were absent on web.
            val previous = _tasks.value.firstOrNull { it.id == task.id }
            // For existing tasks use only values that differ from their original raw values.
            fun setChanged(key: String, value: Any?) {
                val old = taskObj!!.opt(key)
                val normalized = value ?: JSONObject.NULL
                if (SnapshotMerge.equivalent(old, normalized)) return
                if (value == null) taskObj!!.remove(key) else taskObj!!.put(key, value)
            }
            // The UI edits are based on the raw parsed model; comparisons below avoid
            // overwriting unsupported data where the model uses default values.
            val oldTask = previous
            if (oldTask == null || task.title != oldTask.title) setChanged("title", task.title)
            if (oldTask == null || task.rawTitle != oldTask.rawTitle) setChanged("raw_title", task.rawTitle)
            if (oldTask == null || task.description != oldTask.description) setChanged("description", task.description)
            if (oldTask == null || task.dueDate != oldTask.dueDate) setChanged("due_date", task.dueDate)
            if (oldTask == null || task.priorityId != oldTask.priorityId) setChanged("priority_id", task.priorityId)
            if (oldTask == null || task.tags != oldTask.tags) setChanged("tags", JSONArray(task.tags))
            if (oldTask == null || task.status != oldTask.status) setChanged("status", task.status.name.lowercase())
            if (oldTask == null || task.parentId != oldTask.parentId) setChanged("parent_id", task.parentId)
            if (oldTask == null || task.completedAt != oldTask.completedAt) setChanged("completed_at", task.completedAt)
            if (oldTask == null || task.orderIndex != oldTask.orderIndex) setChanged("order_index", task.orderIndex)
            // Protected fields (AI lock, prerequisites, approval, recurrence) are never
            // edited by the generic task editor. Their server-authoritative values survive.
        }
        rawSnapshot.put("updated_at", System.currentTimeMillis())
    }

    private fun markTaskTrashInRawSnapshot(taskId: String) {
        val tasksArr = rawSnapshot.optJSONArray("tasks") ?: return
        for (i in 0 until tasksArr.length()) {
            val obj = tasksArr.getJSONObject(i)
            if (obj.optString("id") == taskId) {
                obj.put("status", "trash")
                break
            }
        }
        rawSnapshot.put("updated_at", System.currentTimeMillis())
    }

    private fun permanentlyRemoveTaskFromRawSnapshot(taskId: String) {
        val tasksArr = rawSnapshot.optJSONArray("tasks") ?: return
        val newArr = JSONArray()
        for (i in 0 until tasksArr.length()) {
            val obj = tasksArr.getJSONObject(i)
            if (obj.optString("id") != taskId) {
                newArr.put(obj)
            }
        }
        rawSnapshot.put("tasks", newArr)
        rawSnapshot.put("updated_at", System.currentTimeMillis())
    }

    // --- Task Engine & Tree Hierarchy ---

    fun isDescendant(potentialChildId: String, ancestorId: String): Boolean {
        if (potentialChildId == ancestorId) return true
        val tasksById = _tasks.value.associateBy { it.id }
        var current = tasksById[potentialChildId]
        while (current?.parentId != null) {
            if (current.parentId == ancestorId) return true
            current = tasksById[current.parentId]
        }
        return false
    }

    fun hasNestedRecurrence(taskId: String, newParentId: String?): Boolean {
        val tasksById = _tasks.value.associateBy { it.id }
        val target = tasksById[taskId] ?: return false
        if (target.recurrence == RecurrenceRule.NONE) return false

        var curParent = newParentId?.let { tasksById[it] }
        while (curParent != null) {
            if (curParent.recurrence != RecurrenceRule.NONE) return true
            curParent = curParent.parentId?.let { tasksById[it] }
        }

        val descendants = getDescendants(taskId)
        return descendants.any { it.recurrence != RecurrenceRule.NONE }
    }

    private fun getDescendants(parentId: String): List<Task> {
        val list = mutableListOf<Task>()
        val children = _tasks.value.filter { it.parentId == parentId && it.status != TaskStatus.TRASH }
        for (child in children) {
            list.add(child)
            list.addAll(getDescendants(child.id))
        }
        return list
    }

    fun upsertTask(task: Task): Pair<Boolean, String?> {
        val existing = _tasks.value.firstOrNull { it.id == task.id }
        if (task.aiLocked && existing == null) return false to "AI-locked task creation requires Milestone 4."
        if (task.recurrence != RecurrenceRule.NONE) return false to "Recurrence creation/editing requires Milestone 2."
        if (existing?.aiLocked == true && task != existing) return false to "AI-locked tasks are read-only until Milestone 4."
        if (task.parentId != null && isDescendant(task.parentId, task.id)) {
            return Pair(false, "Invalid hierarchy: A task cannot be a subtask of itself or its descendants.")
        }

        if (hasNestedRecurrence(task.id, task.parentId)) {
            return Pair(false, "Nested recurrence is not permitted.")
        }

        val current = _tasks.value.toMutableList()
        val index = current.indexOfFirst { it.id == task.id }
        if (index >= 0) {
            current[index] = task
        } else {
            current.add(task)
        }
        applyTaskToRawSnapshot(task)
        _tasks.value = current
        saveLocalSnapshot()
        return Pair(true, null)
    }

    fun toggleTaskCompletion(taskId: String): Pair<Boolean, String?> {
        val current = _tasks.value.toMutableList()
        val index = current.indexOfFirst { it.id == taskId }
        if (index < 0) return Pair(false, "Task not found.")

        val task = current[index]
        if (task.status == TaskStatus.COMPLETED) {
            // Un-complete
            val updated = task.copy(status = TaskStatus.ACTIVE, completedAt = null, auditApproved = false)
            current[index] = updated
            applyTaskToRawSnapshot(updated)
            _tasks.value = current
            saveLocalSnapshot()
            return Pair(true, null)
        }

        // Rule 8.6: AI-locked tasks cannot be completed locally without approved audit
        if (task.aiLocked) {
            return Pair(false, "AI-locked task completion must be confirmed by the server (Milestone 4).")
        }

        val isBypass = false // Server-controlled; never trust locally toggled bypass.
        if (task.requireAllSubtasksFirst && !isBypass) {
            val descendants = getDescendants(task.id)
            val uncompletedNonBonus = descendants.filter { !it.isBonus && it.status != TaskStatus.COMPLETED }
            if (uncompletedNonBonus.isNotEmpty()) {
                return Pair(false, "Shield active: All subtasks must be completed before completing '${task.title}'.")
            }
        }

        val now = System.currentTimeMillis()
        val updated = task.copy(status = TaskStatus.COMPLETED, completedAt = now)
        current[index] = updated
        applyTaskToRawSnapshot(updated)

        // Cascade completion to descendants
        val descendants = getDescendants(task.id)
        for (d in descendants) {
            val dIndex = current.indexOfFirst { it.id == d.id }
            if (dIndex >= 0 && current[dIndex].status != TaskStatus.COMPLETED) {
                val dUpdated = current[dIndex].copy(status = TaskStatus.COMPLETED, completedAt = now)
                current[dIndex] = dUpdated
                applyTaskToRawSnapshot(dUpdated)
            }
        }

        _tasks.value = current
        _lastCompletedTask.value = updated
        saveLocalSnapshot()
        return Pair(true, null)
    }

    fun undoCompletion(taskId: String) {
        val current = _tasks.value.toMutableList()
        val index = current.indexOfFirst { it.id == taskId }
        if (index >= 0) {
            val updated = current[index].copy(status = TaskStatus.ACTIVE, completedAt = null)
            current[index] = updated
            applyTaskToRawSnapshot(updated)
            _tasks.value = current
            _lastCompletedTask.value = null
            saveLocalSnapshot()
        }
    }

    fun trashBranch(taskId: String): Pair<Boolean, String?> {
        val current = _tasks.value.toMutableList()
        val index = current.indexOfFirst { it.id == taskId }
        if (index < 0) return Pair(false, "Task not found.")

        val task = current[index]
        val isBypass = false // Server-controlled; never trust locally toggled bypass.
        if (!isBypass) {
            if (task.aiLocked && task.status == TaskStatus.ACTIVE) {
                return Pair(false, "Deleting an active AI-locked task is blocked unless Emergency Bypass is active.")
            }
            if (task.requireAllSubtasksFirst) {
                val descendants = getDescendants(task.id)
                if (descendants.any { it.status == TaskStatus.ACTIVE }) {
                    return Pair(false, "Deleting a shielded task with active subtasks is blocked unless Emergency Bypass is active.")
                }
            }
        }

        val allToTrash = listOf(task.id) + getDescendants(task.id).map { it.id }
        for (i in current.indices) {
            if (current[i].id in allToTrash) {
                current[i] = current[i].copy(status = TaskStatus.TRASH)
                markTaskTrashInRawSnapshot(current[i].id)
            }
        }
        _tasks.value = current
        saveLocalSnapshot()
        return Pair(true, null)
    }

    fun confirmAuditApproval(taskId: String, feedback: String) {
        _syncStatusMessage.value = "AI audit approval requires the server-authorized Milestone 4 flow."
    }

    fun restoreTask(taskId: String) {
        val current = _tasks.value.toMutableList()
        val index = current.indexOfFirst { it.id == taskId }
        if (index >= 0) {
            val updated = current[index].copy(status = TaskStatus.ACTIVE)
            current[index] = updated
            applyTaskToRawSnapshot(updated)
            _tasks.value = current
            saveLocalSnapshot()
        }
    }

    fun permanentlyDeleteTask(taskId: String) {
        _tasks.value = _tasks.value.filter { it.id != taskId }
        permanentlyRemoveTaskFromRawSnapshot(taskId)
        saveLocalSnapshot()
    }

    fun emptyTrash() {
        val trashed = _tasks.value.filter { it.status == TaskStatus.TRASH }
        _tasks.value = _tasks.value.filter { it.status != TaskStatus.TRASH }
        trashed.forEach { permanentlyRemoveTaskFromRawSnapshot(it.id) }
        saveLocalSnapshot()
    }

    // --- Emergency Bypass (12.3) ---

    fun activateEmergencyBypassLocally(): Pair<Boolean, String> =
        false to "Emergency Bypass is server-controlled and is not available until Milestone 3."

    private fun checkEmergencyBypassCycleReset() {
        val s = _settings.value
        if (s.emergencyBypassUntil > 0 && System.currentTimeMillis() > s.emergencyBypassUntil) {
            _settings.value = s.copy(emergencyBypassActive = false, emergencyBypassUntil = 0L)
            saveLocalSnapshot()
        }
    }

    // --- Breaks & Pomodoro Local Only ---

    fun addBreak(type: BreakType, duration: Int) {
        val current = _breaks.value.toMutableList()
        current.add(0, BreakSession(type = type, durationMinutes = duration))
        _breaks.value = current
    }

    fun evaluatePhoneAccess(): PhoneAccessDecision {
        val isBypass = false // Server-controlled; never trust locally toggled bypass.
        if (isBypass) return PhoneAccessDecision(allowed = true, reason = "Emergency Bypass active.")
        val todayStr = DateUtils.getLogicalDate(_settings.value.dayStartHour)
        val tasksById = _tasks.value.associateBy { it.id }
        val pendingActive = _tasks.value.any {
            it.status == TaskStatus.ACTIVE && DateUtils.getEffectiveDueDate(it, tasksById).let { d -> d.isBlank() || d <= todayStr }
        }
        return if (!pendingActive) {
            PhoneAccessDecision(allowed = true, reason = "All scheduled focus tasks completed for today.")
        } else {
            PhoneAccessDecision(allowed = false, reason = "Active tasks pending in today's queue.")
        }
    }

    fun startPomodoro() {
        _pomodoro.value = _pomodoro.value.copy(isRunning = true)
    }

    fun pausePomodoro() {
        _pomodoro.value = _pomodoro.value.copy(isRunning = false)
    }

    fun resetPomodoro() {
        val s = _settings.value
        val sec = when (_pomodoro.value.mode) {
            PomodoroMode.WORK -> s.workDurationMinutes * 60
            PomodoroMode.SHORT_BREAK -> s.shortBreakMinutes * 60
            PomodoroMode.LONG_BREAK -> s.longBreakMinutes * 60
        }
        _pomodoro.value = _pomodoro.value.copy(remainingSeconds = sec, isRunning = false)
    }

    fun tickPomodoro() {
        val current = _pomodoro.value
        if (!current.isRunning) return
        if (current.remainingSeconds > 0) {
            _pomodoro.value = current.copy(remainingSeconds = current.remainingSeconds - 1)
        } else {
            if (current.mode == PomodoroMode.WORK) {
                val newSessions = current.completedSessions + 1
                val nextMode = if (newSessions % 4 == 0) PomodoroMode.LONG_BREAK else PomodoroMode.SHORT_BREAK
                val sec = if (nextMode == PomodoroMode.LONG_BREAK) _settings.value.longBreakMinutes * 60 else _settings.value.shortBreakMinutes * 60
                _pomodoro.value = current.copy(
                    mode = nextMode,
                    remainingSeconds = sec,
                    isRunning = false,
                    completedSessions = newSessions
                )
            } else {
                _pomodoro.value = current.copy(
                    mode = PomodoroMode.WORK,
                    remainingSeconds = _settings.value.workDurationMinutes * 60,
                    isRunning = false
                )
            }
        }
    }

    fun switchPomodoroMode(mode: PomodoroMode) {
        val sec = when (mode) {
            PomodoroMode.WORK -> _settings.value.workDurationMinutes * 60
            PomodoroMode.SHORT_BREAK -> _settings.value.shortBreakMinutes * 60
            PomodoroMode.LONG_BREAK -> _settings.value.longBreakMinutes * 60
        }
        _pomodoro.value = _pomodoro.value.copy(mode = mode, remainingSeconds = sec, isRunning = false)
    }

    fun setPomodoroFocusedTask(taskId: String?) {
        _pomodoro.value = _pomodoro.value.copy(currentTaskId = taskId)
    }

    fun startPlanningWindow(): Pair<Boolean, String> =
        false to "Server-owned break planning is deferred until Milestone 2."

    fun lockSchedule(intervals: List<BreakInterval>): Pair<Boolean, String> =
        false to "Server-owned break planning is deferred until Milestone 2."

    // --- Distraction Notes (Local Only) ---

    private fun readNotesAndCleanup(): List<DistractionNote> {
        if (!notesFile.exists()) return emptyList()
        val list = mutableListOf<DistractionNote>()
        try {
            val arr = JSONArray(notesFile.readText())
            val now = System.currentTimeMillis()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val exp = obj.optLong("expires_at", now + 1)
                if (exp > now) {
                    list.add(
                        DistractionNote(
                            id = obj.getString("id"),
                            title = obj.optString("title").takeIf { it.isNotBlank() },
                            text = obj.getString("text"),
                            timestamp = obj.getLong("timestamp"),
                            expiresAt = exp
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return list
    }

    fun saveDistractionNote(text: String, title: String? = null) {
        val current = _notes.value.toMutableList()
        val note = DistractionNote(text = text, title = title)
        current.add(0, note)
        _notes.value = current

        val arr = JSONArray()
        current.forEach { n ->
            arr.put(JSONObject().apply {
                put("id", n.id)
                put("text", n.text)
                if (n.title != null) put("title", n.title)
                put("timestamp", n.timestamp)
                put("expires_at", n.expiresAt)
            })
        }
        notesFile.writeText(arr.toString())
    }

    fun deleteDistractionNote(id: String) {
        val current = _notes.value.filter { it.id != id }
        _notes.value = current
        val arr = JSONArray()
        current.forEach { n ->
            arr.put(JSONObject().apply {
                put("id", n.id)
                put("text", n.text)
                if (n.title != null) put("title", n.title)
                put("timestamp", n.timestamp)
                put("expires_at", n.expiresAt)
            })
        }
        notesFile.writeText(arr.toString())
    }

    // --- Settings Updates ---

    fun updateSettings(newSettings: UserSettings) {
        val old = _settings.value
        val settingsObj = rawSnapshot.optJSONObject("settings") ?: JSONObject().also { rawSnapshot.put("settings", it) }
        if (newSettings.copilotName != old.copilotName) settingsObj.put("copilot_name", newSettings.copilotName)
        if (newSettings.dayStartHour != old.dayStartHour) settingsObj.put("day_start_hour", newSettings.dayStartHour)
        if (newSettings.weekendStart != old.weekendStart) settingsObj.put("weekend_start", newSettings.weekendStart)
        if (newSettings.weekendEnd != old.weekendEnd) settingsObj.put("weekend_end", newSettings.weekendEnd)
        if (newSettings.breakTimezone != old.breakTimezone) settingsObj.put("break_timezone", newSettings.breakTimezone)
        if (newSettings.dumpDurationSeconds != old.dumpDurationSeconds) settingsObj.put("dump_duration", newSettings.dumpDurationSeconds)
        if (newSettings.strictCriteriaValidation != old.strictCriteriaValidation) settingsObj.put("strict_criteria_validation", newSettings.strictCriteriaValidation)
        if (newSettings.soundEffectsEnabled != old.soundEffectsEnabled) settingsObj.put("sound_effects_enabled", newSettings.soundEffectsEnabled)
        if (newSettings.hapticsEnabled != old.hapticsEnabled) settingsObj.put("haptics_enabled", newSettings.hapticsEnabled)
        // is_pro, use_byok, emergency_bypass, and AI/recurrence fields are server-owned.
        _settings.value = newSettings.copy(isPro = old.isPro, useByok = old.useByok,
            emergencyBypassActive = old.emergencyBypassActive,
            emergencyBypassUsesRemaining = old.emergencyBypassUsesRemaining)
        saveLocalSnapshot()
    }

    fun rescheduleAllOverdue(newDate: String) {
        val todayStr = DateUtils.getLogicalDate(_settings.value.dayStartHour)
        val current = _tasks.value.toMutableList()
        for (i in current.indices) {
            val t = current[i]
            if (t.status == TaskStatus.ACTIVE && t.dueDate.isNotBlank() && t.dueDate < todayStr) {
                val targetDate = if (t.aiLocked) todayStr else newDate
                val updated = t.copy(dueDate = targetDate)
                current[i] = updated
                applyTaskToRawSnapshot(updated)
            }
        }
        _tasks.value = current
        saveLocalSnapshot()
    }

    fun saveCriteriaPreset(saved: SavedCriteria): Pair<Boolean, String?> {
        val check = CriteriaValidator.validateSavedCriteriaRules(_savedCriteria.value, saved)
        if (!check.first) return check

        val current = _savedCriteria.value.toMutableList()
        current.add(saved)
        _savedCriteria.value = current

        val scArr = rawSnapshot.optJSONArray("saved_criteria") ?: JSONArray().also { rawSnapshot.put("saved_criteria", it) }
        scArr.put(JSONObject().apply {
            put("id", saved.id)
            put("title", saved.title)
            put("criteria", saved.criteria)
            put("score", saved.score)
            put("has_exemplar", saved.hasExemplar)
            if (saved.exemplar != null) put("exemplar", saved.exemplar)
            put("created_at", saved.createdAt)
        })

        saveLocalSnapshot()
        return Pair(true, null)
    }

    // --- Safe Cloud Sync & Gating (Phase 1.2 & 1.3) ---

    private fun identityUser(): String? = (_authState.value as? AuthState.Authenticated)?.workerUser

    private fun canonicalEmpty(version: Long, user: String): JSONObject = JSONObject().apply {
        put("username", user); put("version", version); put("tasks", JSONArray())
        put("settings", JSONObject()); put("saved_criteria", JSONArray())
    }

    private fun showConflict(base: JSONObject, local: JSONObject, remote: JSONObject,
                             issues: List<SnapshotMerge.Issue>): Pair<Boolean, String> {
        val backup = JSONObject().apply {
            put("base", base); put("local", local); put("remote", remote)
            put("conflicts", JSONArray(issues.map { it.id + ":" + it.fields.joinToString(",") }))
        }
        getBackupFile().writeText(backup.toString(2))
        val items = issues.distinctBy { it.id }.map { issue ->
            val synthetic = issue.id == "__snapshot__"
            val l = issue.local ?: JSONObject().put("id", issue.id).put("title", "Deleted locally")
            val r = issue.remote ?: JSONObject().put("id", issue.id).put("title", "Deleted remotely")
            ConflictTaskItem(issue.id, if (synthetic) "Snapshot/settings" else l.optString("title", "Deleted locally"),
                if (synthetic) "Server-owned or incompatible changes" else r.optString("title", "Deleted remotely"),
                l.optString("status"), r.optString("status"),
                issues.filter { it.id == issue.id }.flatMap { it.fields }, l, r)
        }
        _syncConflictReport.value = SyncConflictReport(items, JSONObject(base.toString()),
            JSONObject(local.toString()), JSONObject(remote.toString()), getBackupFile().absolutePath)
        _syncState.value = SyncState.CONFLICT
        return false to "Sync paused. Review conflicts; local data is backed up."
    }

    private suspend fun initialPullUnlocked(): Pair<Boolean, String> {
        val epoch = identityEpoch
        val user = identityUser() ?: return false to "A verified Taskitator account is required."
        val token = freshClerkToken() ?: run {
            _syncState.value = SyncState.OFFLINE
            return false to "Clerk token unavailable. Local data preserved."
        }
        _syncState.value = SyncState.PULLING
        val response = TaskitatorWorkerApi.pullSync(token)
        if (response.isFailure) {
            val e = response.exceptionOrNull()
            _syncState.value = SyncState.ERROR
            return false to "Cloud pull failed: ${e?.message}. Local data preserved."
        }
        if (identityEpoch != epoch || identityUser() != user) return false to "Account changed during pull."
        val body = response.getOrThrow()
        val remote = if (body.optBoolean("empty", false))
            canonicalEmpty(body.optLong("version", 0), user) else body
        if (remote.optString("username") != user || remote.optJSONArray("tasks") == null) {
            _syncState.value = SyncState.ERROR
            return false to "Worker returned an invalid or mismatched account snapshot."
        }
        val oldBase = JSONObject(baseSnapshot.toString())
        val oldLocal = JSONObject(rawSnapshot.toString())
        if (!baseIsTrusted && (oldLocal.optJSONArray("tasks")?.length() ?: 0) > 0) {
            return showConflict(oldBase, oldLocal, remote,
                listOf(SnapshotMerge.Issue("__snapshot__", listOf("untrusted_base_snapshot"), oldLocal, remote)))
        }
        val localEdits = SnapshotMerge.hasLocalEdits(oldBase, oldLocal)
        val outcome = if (localEdits) SnapshotMerge.merge(oldBase, oldLocal, remote)
            else SnapshotMerge.Result(JSONObject(remote.toString()), emptyList())
        if (outcome.issues.isNotEmpty()) return showConflict(oldBase, oldLocal, remote, outcome.issues)
        baseSnapshot = JSONObject(remote.toString())
        baseVersion = remote.optLong("version", 0)
        rawSnapshot = outcome.merged
        rawSnapshot.put("username", user)
        saveBaseSnapshot()
        baseIsTrusted = true
        saveLocalSnapshot()
        parseSnapshot(rawSnapshot)
        _settings.value = _settings.value.copy(needsInitialPull = false, remoteVersion = baseVersion)
        _syncState.value = SyncState.UP_TO_DATE
        _syncStatusMessage.value = if (SnapshotMerge.hasLocalEdits(baseSnapshot, rawSnapshot))
            "Cloud loaded; local changes are waiting to upload." else "Synced with cloud (v$baseVersion)."
        return true to _syncStatusMessage.value.orEmpty()
    }

    suspend fun initialPull(): Pair<Boolean, String> = syncMutex.withLock { initialPullUnlocked() }

    suspend fun performSync(): Pair<Boolean, String> = syncMutex.withLock {
        val epoch = identityEpoch
        val user = identityUser() ?: return@withLock false to "Sign in to sync."
        if (_syncConflictReport.value != null) return@withLock false to "Resolve the pending conflict before syncing."
        if (_settings.value.needsInitialPull) return@withLock initialPullUnlocked()
        val token = freshClerkToken() ?: run {
            _syncState.value = SyncState.OFFLINE
            return@withLock false to "Clerk session unavailable. Edits preserved."
        }
        if (pendingPushPayload == null && !SnapshotMerge.hasLocalEdits(baseSnapshot, rawSnapshot)) {
            return@withLock initialPullUnlocked() // Refresh remote; never push an unchanged snapshot.
        }
        // A previously uncertain upload is retried using exactly the same frozen payload.
        if (pendingPushPayload == null) {
            val snapshot = JSONObject(rawSnapshot.toString())
            snapshot.put("username", user)
            val id = java.util.UUID.randomUUID().toString()
            pendingPushPayload = TaskitatorWorkerApi.createPushPayload(snapshot, baseVersion, id)
            pendingMutationId = id
            savePendingPayload() // Durable BEFORE network I/O.
        }
        val payload = JSONObject(pendingPushPayload!!.toString())
        val sentVersion = payload.getLong("base_version")
        val sentId = payload.getString("mutation_id")
        _syncState.value = SyncState.PUSHING
        val push = TaskitatorWorkerApi.pushSync(payload, sentVersion, sentId, token)
        if (identityEpoch != epoch || identityUser() != user) return@withLock false to "Account changed during upload."
        if (push.isFailure) {
            val error = push.exceptionOrNull()
            if (error is SyncConflictException) {
                // Preserve the exact payload until we have a confirmed authoritative remote state.
                val remoteResult = TaskitatorWorkerApi.pullSync(token)
                if (remoteResult.isFailure) {
                    _syncState.value = SyncState.CONFLICT
                    return@withLock false to "409: Unable to retrieve cloud state. Upload paused."
                }
                if (identityEpoch != epoch || identityUser() != user) return@withLock false to "Account changed during conflict retrieval."
                val remote = remoteResult.getOrThrow()
                val base = JSONObject(baseSnapshot.toString())
                val local = JSONObject(rawSnapshot.toString())
                val outcome = SnapshotMerge.merge(base, local, remote)
                if (outcome.issues.isNotEmpty()) return@withLock showConflict(base, local, remote, outcome.issues)
                baseSnapshot = JSONObject(remote.toString())
                baseVersion = remote.optLong("version", baseVersion)
                rawSnapshot = outcome.merged
                saveBaseSnapshot(); baseIsTrusted = true; saveLocalSnapshot(); parseSnapshot(rawSnapshot)
                pendingPushPayload = null; pendingMutationId = null; savePendingPayload()
                _syncState.value = SyncState.IDLE
                return@withLock false to "Non-conflicting edits merged. Sync again to upload safely."
            }
            _syncState.value = if (error is UnauthorizedException || error is WorkerProtectionException ||
                error is PreconditionRequiredException || error is AccountDeletedException) SyncState.ERROR else SyncState.OFFLINE
            if (error is UnauthorizedException) _authState.value = AuthState.SessionExpired("Worker rejected the session.")
            if (error is AccountDeletedException) _authState.value = AuthState.AccountDeleted("Account deletion accepted.")
            return@withLock false to "Upload not confirmed: ${error?.message}. Exact request retained for retry."
        }
        val acknowledgedVersion = push.getOrThrow().optLong("version", sentVersion + 1)
        val remoteResult = TaskitatorWorkerApi.pullSync(token)
        if (remoteResult.isFailure) {
            // Upload succeeded, but server-normalized fields are not known. Do not push again.
            baseVersion = acknowledgedVersion
            _settings.value = _settings.value.copy(needsInitialPull = true)
            pendingPushPayload = null; pendingMutationId = null; savePendingPayload()
            _syncState.value = SyncState.ERROR
            return@withLock false to "Upload acknowledged, but refresh failed. Further uploads blocked until pull."
        }
        if (identityEpoch != epoch || identityUser() != user) return@withLock false to "Account changed during refresh."
        val remote = remoteResult.getOrThrow()
        val sent = JSONObject(payload.toString()).apply {
            remove("mutation_id"); remove("base_version")
            if (!rawSnapshot.has("recurrence_schema")) remove("recurrence_schema")
            if (!rawSnapshot.has("dynamic_priority_schema")) remove("dynamic_priority_schema")
            put("version", acknowledgedVersion)
        }
        val current = JSONObject(rawSnapshot.toString())
        val outcome = SnapshotMerge.merge(sent, current, remote)
        pendingPushPayload = null; pendingMutationId = null; savePendingPayload()
        if (outcome.issues.isNotEmpty()) return@withLock showConflict(sent, current, remote, outcome.issues)
        baseSnapshot = JSONObject(remote.toString())
        baseVersion = remote.optLong("version", acknowledgedVersion)
        rawSnapshot = outcome.merged
        saveBaseSnapshot(); baseIsTrusted = true; saveLocalSnapshot(); parseSnapshot(rawSnapshot)
        _syncState.value = SyncState.UP_TO_DATE
        _syncStatusMessage.value = if (SnapshotMerge.hasLocalEdits(baseSnapshot, rawSnapshot))
            "Upload confirmed; newer local edits remain queued." else "Synced (v$baseVersion)."
        true to _syncStatusMessage.value.orEmpty()
    }

    fun performThreeWayMerge(baseObj: JSONObject, localObj: JSONObject, remoteObj: JSONObject): Pair<Boolean, SyncConflictReport?> {
        val outcome = SnapshotMerge.merge(baseObj, localObj, remoteObj)
        if (outcome.issues.isNotEmpty()) {
            showConflict(baseObj, localObj, remoteObj, outcome.issues)
            return false to _syncConflictReport.value
        }
        // Historical API: successful merges update the caller's JSON object.
        val keys = remoteObj.keys().asSequence().toList()
        keys.forEach { remoteObj.remove(it) }
        outcome.merged.keys().asSequence().forEach { remoteObj.put(it, outcome.merged.get(it)) }
        return true to null
    }

    fun resolveConflictAdoptCloud() {
        val report = _syncConflictReport.value ?: return
        rawSnapshot = JSONObject(report.remoteSnapshot.toString())
        baseSnapshot = JSONObject(report.remoteSnapshot.toString())
        baseVersion = rawSnapshot.optLong("version", 0L)
        saveBaseSnapshot(); baseIsTrusted = true; saveLocalSnapshot(); parseSnapshot(rawSnapshot)
        pendingPushPayload = null; pendingMutationId = null; savePendingPayload()
        _syncConflictReport.value = null
        _syncState.value = SyncState.UP_TO_DATE
        _syncStatusMessage.value = "Cloud version adopted. Previous local copy remains in conflict backup."
    }

    private fun resolveChosenConflicts(keepLocalTaskIds: Set<String>) {
        val report = _syncConflictReport.value ?: return
        // Never allow client-side resolution of server-owned root/settings conflicts.
        if (report.conflictingTasks.any { it.taskId == "__snapshot__" }) {
            _syncStatusMessage.value = "Server-owned data cannot be overridden. Export backup and review manually."
            return
        }
        val outcome = SnapshotMerge.merge(report.baseSnapshot, report.localSnapshot,
            report.remoteSnapshot, preferLocal = keepLocalTaskIds)
        if (outcome.issues.isNotEmpty()) {
            _syncStatusMessage.value = "Protected fields still conflict. Export backup; no upload was made."
            return
        }
        baseSnapshot = JSONObject(report.remoteSnapshot.toString())
        baseVersion = baseSnapshot.optLong("version", baseVersion)
        rawSnapshot = outcome.merged
        saveBaseSnapshot(); baseIsTrusted = true; saveLocalSnapshot(); parseSnapshot(rawSnapshot)
        pendingPushPayload = null; pendingMutationId = null; savePendingPayload()
        _syncConflictReport.value = null
        _syncState.value = SyncState.IDLE
        scope.launch { performSync() }
    }

    fun resolveConflictKeepLocal() {
        resolveChosenConflicts(_syncConflictReport.value?.conflictingTasks?.map { it.taskId }?.toSet() ?: emptySet())
    }

    fun resolveConflictPerTask(keepLocalTaskIds: Set<String>) {
        resolveChosenConflicts(keepLocalTaskIds)
    }

    fun exportConflictBackup(): String {
        val bFile = getBackupFile()
        return if (bFile.exists()) bFile.readText() else "{}"
    }

    fun dismissConflictReport() {
        _syncConflictReport.value = null
    }
}
