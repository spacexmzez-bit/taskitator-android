package com.example.data.network

import com.example.blocker.BlockerSignals
import com.example.data.model.CriteriaValidationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object TaskitatorWorkerApi {

    // Hardcoded per build via Plan v5 (VERIFIED core.js). Not user-editable.
    const val WORKER_BASE_URL = "https://taskitator-sync.spacexmzez.workers.dev"

    // Tells the Worker which client is calling, so it can apply the app's own entitlements.
    const val CLIENT_HEADER = "X-Taskitator-Client"
    const val CLIENT_ANDROID = "android"

    private fun openConnection(path: String, method: String, token: String, username: String? = null): HttpURLConnection {
        val endpoint = URL("$WORKER_BASE_URL$path")
        val conn = endpoint.openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 55000 // Worker AI timeout is 55s per AIGateway.generate
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        conn.setRequestProperty("X-App-ID", "taskitator")
        conn.setRequestProperty(CLIENT_HEADER, CLIENT_ANDROID)
        if (!username.isNullOrBlank()) {
            conn.setRequestProperty("X-Taskitator-User", username)
        }
        if (token.isNotBlank()) {
            conn.setRequestProperty("Authorization", "Bearer $token")
        }
        return conn
    }

    /**
     * POST /ai/generate with format='criteria' 
     * Pass rule: score >= 7.
     */
    suspend fun validateCriteria(
        criteria: String,
        exemplarNote: String?,
        token: String
    ): Result<CriteriaValidationResult> = withContext(Dispatchers.IO) {
        try {
            val conn = openConnection("/ai/generate", "POST", SessionTokens.fresh(token))
            conn.doOutput = true

            val payload = JSONObject().apply {
                put("format", "criteria")
                put("prompt", criteria)
                if (!exemplarNote.isNullOrBlank()) {
                    put("exemplar", exemplarNote)
                }
            }

            OutputStreamWriter(conn.outputStream, "UTF-8").use { it.write(payload.toString()) }

            val responseCode = conn.responseCode
            if (responseCode in 200..299) {
                val text = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8")).use { it.readText() }
                val obj = JSONObject(text)
                val score = obj.optInt("score", 0)
                val critique = obj.optString("critique", obj.optString("reason", "Criteria evaluated."))
                val suggestedRewrite = obj.optString("suggested_rewrite").takeIf { it.isNotBlank() }
                    ?: obj.optString("suggestedRewrite").takeIf { it.isNotBlank() }
                val isValid = score >= 7

                Result.success(
                    CriteriaValidationResult(
                        isValid = isValid,
                        score = score,
                        critique = critique,
                        suggestedRewrite = suggestedRewrite
                    )
                )
            } else if (responseCode == 400 || responseCode == 403) {
                val err = conn.errorStream?.let { BufferedReader(InputStreamReader(it)).use { r -> r.readText() } } ?: ""
                Result.failure(Exception("Criteria validation needs an AI key saved on the website (Settings → AI). $err"))
            } else {
                val err = conn.errorStream?.let { BufferedReader(InputStreamReader(it)).use { r -> r.readText() } } ?: "HTTP $responseCode"
                Result.failure(Exception("AI criteria validation failed ($err). Please retry."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("AI verification service unreachable. Please retry."))
        }
    }

    /**
     * GET /pro/status - what the Worker grants this account inside the app.
     */
    suspend fun getProStatus(token: String): Result<ProStatus> = withContext(Dispatchers.IO) {
        try {
            val conn = openConnection("/pro/status", "GET", SessionTokens.fresh(token))
            val code = conn.responseCode
            if (code in 200..299) {
                val text = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8")).use { it.readText() }
                Result.success(ProStatus.parse(JSONObject(text)))
            } else {
                Result.failure(WorkerErrors.forStatus(code, readError(conn)))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun readError(conn: HttpURLConnection): String =
        conn.errorStream?.let { BufferedReader(InputStreamReader(it, "UTF-8")).use { r -> r.readText() } } ?: ""

    /**
     * GET /auth/me - inspect account and deletion status
     */
    suspend fun getAuthMe(token: String): Result<JSONObject> = getJson("/auth/me", token)

    /**
     * POST /auth/account - connect/create Worker account
     */
    suspend fun connectAccount(token: String, mode: String = "create"): Result<JSONObject> =
        withContext(Dispatchers.IO) {
            try {
                val conn = openConnection("/auth/account", "POST", SessionTokens.fresh(token))
                conn.doOutput = true
                OutputStreamWriter(conn.outputStream, "UTF-8").use { it.write(JSONObject().put("mode", mode).toString()) }
                readJson(conn)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /**
     * GET /sync/pull - pull latest snapshot
     */
    suspend fun pullSync(token: String, username: String? = null): Result<JSONObject> =
        getJson("/sync/pull", token, username)

    /**
     * Builds the top-level body for POST /sync/push.
     * The snapshot is sent as-is with base_version and mutation_id beside it, never nested under "payload".
     * The two schema flags tell the Worker this client keeps recurrence and Dynamic Priority data intact;
     * without them the Worker answers 428 for accounts that use those features.
     */
    fun createPushPayload(snapshot: JSONObject, baseVersion: Long, mutationId: String): JSONObject {
        val payload = JSONObject(snapshot.toString())
        payload.put("base_version", baseVersion)
        payload.put("mutation_id", mutationId)
        payload.put("recurrence_schema", 1)
        payload.put("dynamic_priority_schema", 1)
        payload.remove("payload")
        return payload
    }

    /**
     * POST /sync/push - push snapshot with base_version and mutation_id at top level
     */
    suspend fun pushSync(
        snapshot: JSONObject,
        baseVersion: Long,
        mutationId: String,
        token: String,
        username: String? = null
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val conn = openConnection("/sync/push", "POST", SessionTokens.fresh(token), username)
            conn.doOutput = true
            val payload = createPushPayload(snapshot, baseVersion, mutationId)
            OutputStreamWriter(conn.outputStream, "UTF-8").use { it.write(payload.toString()) }
            // Finished or reopened tasks change the lock: tell the blocker after a successful push.
            readJson(conn).onSuccess { BlockerSignals.requestRefresh() }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun getJson(path: String, token: String, username: String? = null): Result<JSONObject> =
        withContext(Dispatchers.IO) {
            try {
                readJson(openConnection(path, "GET", SessionTokens.fresh(token), username))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun readJson(conn: HttpURLConnection): Result<JSONObject> {
        val code = conn.responseCode
        if (code !in 200..299) return Result.failure(WorkerErrors.forStatus(code, readError(conn)))
        val text = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8")).use { it.readText() }
        return Result.success(JSONObject(text))
    }
}

class SyncConflictException(message: String, val errorJson: String = "") : Exception(message)
class WorkerProtectionException(message: String, val errorJson: String = "") : Exception(message)
class AccountDeletedException(message: String) : Exception(message)
class RateLimitException(message: String) : Exception(message)
class UnauthorizedException(message: String) : Exception(message)
class PreconditionRequiredException(message: String) : Exception(message)
class ServiceUnavailableException(message: String) : Exception(message)


/** Server-authoritative personal controls. Never derive permission from local timers. */
object PersonalControlApi {
    private const val ROOT = TaskitatorWorkerApi.WORKER_BASE_URL

    /** @param method set only for DELETE; otherwise GET without a body and POST with one. */
    suspend fun request(
        path: String,
        token: String,
        body: JSONObject? = null,
        method: String? = null,
        anonymous: Boolean = false
    ): Result<JSONObject> =
        withContext(Dispatchers.IO) {
            if (token.isBlank() && !anonymous) return@withContext Result.failure(IllegalStateException("Sign in to use cloud controls."))
            var conn: HttpURLConnection? = null
            try {
                conn = URL(ROOT + path).openConnection() as HttpURLConnection
                conn.requestMethod = method ?: if (body == null) "GET" else "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                if (!anonymous) conn.setRequestProperty("Authorization", "Bearer " + SessionTokens.fresh(token))
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                conn.setRequestProperty("X-App-ID", "taskitator")
                conn.setRequestProperty(TaskitatorWorkerApi.CLIENT_HEADER, TaskitatorWorkerApi.CLIENT_ANDROID)
                if (body != null) {
                    conn.doOutput = true
                    conn.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body.toString()) }
                }
                val status = conn.responseCode
                val text = (if (status in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = try { JSONObject(text) } catch (_: Exception) { JSONObject().put("message", text) }
                if (status in 200..299) {
                    // Breaks, Sleep Lock and Emergency Bypass change the lock: tell the blocker now.
                    if (BlockerSignals.changesLock(path, body != null)) BlockerSignals.requestRefresh()
                    Result.success(json)
                }
                else Result.failure(IllegalStateException("HTTP $status: " + json.optString("error", json.optString("message", text)).take(500)))
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                conn?.disconnect()
            }
        }
}