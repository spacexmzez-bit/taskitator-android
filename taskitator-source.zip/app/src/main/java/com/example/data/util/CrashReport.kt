package com.example.data.util

import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Keeps the last crash on the phone so it can be read and copied from Settings.
 * Nothing is sent anywhere. Session tokens are removed before the text is saved.
 */
object CrashReport {
    const val FILE_NAME = "last_crash.txt"
    private const val MAX_CHARS = 8000

    private val jwt = Regex("eyJ[A-Za-z0-9_\\-]+\\.[A-Za-z0-9_\\-]+\\.[A-Za-z0-9_\\-]*")
    private val phoneToken = Regex("tkp_[A-Za-z0-9]{8,}")

    fun sanitize(text: String): String = text.replace(jwt, "[token]").replace(phoneToken, "[token]")

    fun format(error: Throwable, threadName: String, atMs: Long): String {
        val trace = StringWriter().also { error.printStackTrace(PrintWriter(it)) }.toString()
        return sanitize("Time: $atMs\nThread: $threadName\n\n$trace").take(MAX_CHARS)
    }

    fun save(dir: File, text: String) {
        File(dir, FILE_NAME).writeText(text)
    }

    fun load(dir: File): String? {
        val file = File(dir, FILE_NAME)
        return try { if (file.exists()) file.readText().ifBlank { null } else null } catch (_: Exception) { null }
    }

    fun clear(dir: File) {
        try { File(dir, FILE_NAME).delete() } catch (_: Exception) { }
    }
}
