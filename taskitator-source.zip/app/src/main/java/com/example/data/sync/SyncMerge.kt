package com.example.data.sync

import com.example.data.model.ConflictTaskItem
import org.json.JSONArray
import org.json.JSONObject

/** Result of a three-way merge. When [clean] is true, the merged data has been written into the remote object. */
data class MergeResult(val clean: Boolean, val conflicts: List<ConflictTaskItem>)

/**
 * Three-way merge of base, local and remote snapshots. Pure: no Android, no files, no network.
 * A clean merge writes the merged tasks, projects and settings into [remoteObj].
 */
object SyncMerge {
    private val protectedFields = setOf("ai_locked", "strict_prerequisites", "audit_approved", "completed_audit_ledger")

    fun merge(baseObj: JSONObject, localObj: JSONObject, remoteObj: JSONObject): MergeResult {
        val baseTasks = byId(baseObj.optJSONArray("tasks"))
        val localTasks = byId(localObj.optJSONArray("tasks"))
        val remoteTasks = byId(remoteObj.optJSONArray("tasks"))

        val allIds = (baseTasks.keys + localTasks.keys + remoteTasks.keys).toSet()
        val conflicts = mutableListOf<ConflictTaskItem>()
        val mergedTasksArray = JSONArray()

        for (id in allIds) {
            val b = baseTasks[id]
            val l = localTasks[id]
            val r = remoteTasks[id]

            if (b == null) {
                // Task added after base
                if (l != null && r == null) {
                    mergedTasksArray.put(JSONObject(l.toString()))
                } else if (r != null && l == null) {
                    mergedTasksArray.put(JSONObject(r.toString()))
                } else if (l != null && r != null) {
                    val conflictingFields = findConflictingFields(l, r)
                    if (conflictingFields.isEmpty()) {
                        mergedTasksArray.put(JSONObject(r.toString()))
                    } else {
                        conflicts.add(conflictItem(id, l, r, conflictingFields))
                    }
                }
            } else {
                // Task existed in base
                if (l == null && r != null) {
                    if (!sameObject(b, r)) {
                        conflicts.add(conflictItem(id, deleted(id, "[Deleted locally]"), r, listOf("delete_vs_edit")))
                    }
                } else if (r == null && l != null) {
                    if (!sameObject(b, l)) {
                        conflicts.add(conflictItem(id, l, deleted(id, "[Deleted remotely]"), listOf("delete_vs_edit")))
                    }
                } else if (l != null && r != null) {
                    val lChanged = !sameObject(b, l)
                    val rChanged = !sameObject(b, r)

                    if (lChanged && !rChanged) {
                        mergedTasksArray.put(JSONObject(l.toString()))
                    } else if (!lChanged) {
                        mergedTasksArray.put(JSONObject(r.toString()))
                    } else {
                        // Both changed: check field by field
                        val conflictingFields = mutableListOf<String>()
                        val mergedTask = JSONObject(r.toString())
                        for (f in keys(b) + keys(l) + keys(r)) {
                            if (f in protectedFields) continue
                            val bVal = b.opt(f)?.toString() ?: ""
                            val lVal = l.opt(f)?.toString() ?: ""
                            val rVal = r.opt(f)?.toString() ?: ""
                            if (lVal != bVal && rVal == bVal) {
                                if (l.has(f)) mergedTask.put(f, l.get(f)) else mergedTask.remove(f)
                            } else if (lVal != rVal && !(rVal != bVal && lVal == bVal)) {
                                conflictingFields.add(f)
                            }
                        }
                        if (conflictingFields.isEmpty()) {
                            mergedTasksArray.put(mergedTask)
                        } else {
                            conflicts.add(conflictItem(id, l, r, conflictingFields))
                        }
                    }
                }
            }
        }

        // Projects are merged per project id so two devices can create different projects.
        val bp = byId(baseObj.optJSONArray("projects"))
        val lp = byId(localObj.optJSONArray("projects"))
        val rp = byId(remoteObj.optJSONArray("projects"))
        val mergedProjects = JSONArray()
        for (id in (bp.keys + lp.keys + rp.keys).toSortedSet()) {
            val b = bp[id]; val l = lp[id]; val r = rp[id]
            val lChanged = !sameValue(b, l)
            val rChanged = !sameValue(b, r)
            if (lChanged && rChanged && !sameValue(l, r)) {
                conflicts.add(conflictItem("project:$id", l ?: JSONObject(), r ?: JSONObject(), listOf("project_change")))
            } else (if (lChanged) l else r)?.let { mergedProjects.put(it) }
        }

        // Settings are merged key by key, which keeps separately synced draft keys.
        val bs = baseObj.optJSONObject("settings") ?: JSONObject()
        val ls = localObj.optJSONObject("settings") ?: JSONObject()
        val rs = remoteObj.optJSONObject("settings") ?: JSONObject()
        val mergedSettings = JSONObject(rs.toString())
        for (key in keys(bs) + keys(ls) + keys(rs)) {
            val b = bs.opt(key); val l = ls.opt(key); val r = rs.opt(key)
            val lChanged = !sameValue(b, l)
            val rChanged = !sameValue(b, r)
            if (lChanged && rChanged && !sameValue(l, r)) {
                conflicts.add(conflictItem("setting:$key", JSONObject().put("title", "Local setting $key"),
                    JSONObject().put("title", "Cloud setting $key"), listOf("concurrent_change")))
            } else if (lChanged) {
                if (l == null) mergedSettings.remove(key) else mergedSettings.put(key, l)
            }
        }

        // Whole-value scopes: take the side that changed; both changed differently is a conflict.
        val scopeWrites = mutableListOf<Pair<String, Any?>>()
        for (key in listOf("recurrence_state", "saved_criteria", "completed_audit_ledger")) {
            val b = baseObj.opt(key); val l = localObj.opt(key); val r = remoteObj.opt(key)
            if (sameValue(l, r)) continue
            if (sameValue(b, r)) {
                scopeWrites.add(key to l)
            } else if (!sameValue(b, l)) {
                conflicts.add(conflictItem("scope:$key", JSONObject().put("title", "Local $key"),
                    JSONObject().put("title", "Cloud $key"), listOf("concurrent_change")))
            }
        }

        if (conflicts.isNotEmpty()) return MergeResult(false, conflicts)
        for ((key, value) in scopeWrites) {
            if (value == null) remoteObj.remove(key) else remoteObj.put(key, value)
        }
        remoteObj.put("projects", mergedProjects)
        remoteObj.put("settings", mergedSettings)
        remoteObj.put("tasks", mergedTasksArray)
        return MergeResult(true, emptyList())
    }

    fun byId(arr: JSONArray?): Map<String, JSONObject> {
        val map = LinkedHashMap<String, JSONObject>()
        if (arr == null) return map
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            if (id.isNotBlank()) map[id] = obj
        }
        return map
    }

    private fun deleted(id: String, title: String) =
        JSONObject().put("id", id).put("title", title).put("status", "trash")

    private fun keys(obj: JSONObject): Set<String> {
        val out = LinkedHashSet<String>()
        val it = obj.keys()
        while (it.hasNext()) out.add(it.next())
        return out
    }

    private fun sameValue(a: Any?, b: Any?): Boolean = (a?.toString() ?: "<absent>") == (b?.toString() ?: "<absent>")

    private fun sameObject(a: JSONObject, b: JSONObject): Boolean {
        val aKeys = keys(a)
        if (aKeys != keys(b)) return false
        return aKeys.all { (a.opt(it)?.toString() ?: "") == (b.opt(it)?.toString() ?: "") }
    }

    private fun findConflictingFields(l: JSONObject, r: JSONObject): List<String> =
        (keys(l) + keys(r)).filter { (l.opt(it)?.toString() ?: "") != (r.opt(it)?.toString() ?: "") }

    private fun conflictItem(id: String, l: JSONObject, r: JSONObject, fields: List<String>) = ConflictTaskItem(
        taskId = id,
        localTitle = l.optString("title", "[Untitled]"),
        remoteTitle = r.optString("title", "[Untitled]"),
        localStatus = l.optString("status", "active"),
        remoteStatus = r.optString("status", "active"),
        conflictingFields = fields,
        localJson = l,
        remoteJson = r
    )
}
