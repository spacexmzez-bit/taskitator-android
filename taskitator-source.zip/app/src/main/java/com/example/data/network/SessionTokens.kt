package com.example.data.network

/**
 * Supplies a fresh session token for every Worker call.
 *
 * Clerk session tokens live for about a minute, so a token kept in memory or on disk is soon useless.
 * The sign-in layer installs [source]; the network layer asks it right before each request.
 */
object SessionTokens {
    /** Returns a fresh token, or null/blank when there is no signed-in session or it could not be refreshed. */
    @Volatile
    var source: (suspend () -> String?)? = null

    /**
     * @param known the token the caller holds. Blank means "signed out": no token is fetched.
     *   Phone tokens (`tkp_…`) do not expire and are returned as they are.
     * @return a fresh token when one is available, otherwise [known].
     */
    suspend fun fresh(known: String): String {
        if (known.isBlank() || known.startsWith(PHONE_PREFIX)) return known
        val supplier = source ?: return known
        val token = try {
            supplier()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }
        return if (token.isNullOrBlank()) known else token
    }

    const val PHONE_PREFIX = "tkp_"
}
