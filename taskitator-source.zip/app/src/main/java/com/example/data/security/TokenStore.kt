package com.example.data.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Where the session token is kept at rest. */
interface TokenStore {
    fun read(): String
    fun write(token: String)
    fun clear()
}

/**
 * Keeps the session token encrypted with an AES-256-GCM key that lives in the Android Keystore.
 * The key never leaves the Keystore; only the encrypted token is written to preferences.
 * Any failure (for example a key lost after a device restore) reads as "no token": the user signs in again.
 */
class KeystoreTokenStore(context: Context, private val entry: String = KEY_ENCRYPTED) : TokenStore {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    override fun read(): String {
        val stored = prefs.getString(entry, null)
        if (stored.isNullOrBlank()) return migrateLegacy()
        return try {
            val bytes = Base64.decode(stored, Base64.NO_WRAP)
            val iv = bytes.copyOfRange(0, IV_BYTES)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(TAG_BITS, iv))
            String(cipher.doFinal(bytes, IV_BYTES, bytes.size - IV_BYTES), Charsets.UTF_8)
        } catch (_: Exception) {
            clear()
            ""
        }
    }

    override fun write(token: String) {
        if (token.isBlank()) {
            clear()
            return
        }
        try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val sealed = cipher.iv + cipher.doFinal(token.toByteArray(Charsets.UTF_8))
            prefs.edit()
                .putString(entry, Base64.encodeToString(sealed, Base64.NO_WRAP))
                .apply()
            if (entry == KEY_ENCRYPTED) prefs.edit().remove(KEY_LEGACY).apply()
        } catch (_: Exception) {
            // Never fall back to plain text. The session then lasts only until the app closes.
            clear()
        }
    }

    override fun clear() {
        prefs.edit().remove(entry).apply()
        if (entry == KEY_ENCRYPTED) prefs.edit().remove(KEY_LEGACY).apply()
    }

    /** Builds before this one stored the token in plain text. Move it once, then remove it. */
    private fun migrateLegacy(): String {
        if (entry != KEY_ENCRYPTED) return ""
        val legacy = prefs.getString(KEY_LEGACY, null)
        if (legacy.isNullOrBlank()) return ""
        write(legacy)
        return legacy
    }

    private fun key(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (keyStore.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        /** Entry name for the blocker's phone token (the same Keystore key encrypts it). */
        const val PHONE_TOKEN_ENTRY = "phone_token_enc"
        private const val PREFS = "taskitator_auth_secure"
        private const val KEY_ENCRYPTED = "saved_token_enc"
        private const val KEY_LEGACY = "saved_token"
        private const val KEYSTORE = "AndroidKeyStore"
        private const val ALIAS = "taskitator_session_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_BYTES = 12
        private const val TAG_BITS = 128
    }
}
