package com.example.data.sync

import org.json.JSONArray
import org.json.JSONObject

/** Conservative three-way merge: never drops unknown or server-owned fields. */
object SnapshotMerge {
    data class Issue(val id: String, val fields: List<String>, val local: JSONObject?, val remote: JSONObject?)
    /** [serverOwnedOverrides]: device-side differences in server-owned fields that were intentionally NOT kept (cloud wins). */
    data class Result(val merged: JSONObject, val issues: List<Issue>, val serverOwnedOverrides: List<String> = emptyList())

    const val SNAPSHOT_ID = "__snapshot__"

    private val metadata = setOf("version", "saved_at", "updated_at", "mutation_id", "base_version")
    private val localSettings = setOf("copilot_name", "day_start_hour", "weekend_start", "weekend_end",
        "break_timezone", "dump_duration", "strict_criteria_validation", "sound_effects_enabled", "haptics_enabled")
    private val serverTaskFields = setOf("ai_locked", "audit_approved", "strict_prerequisites", "completed_audit_ledger",
        "dynamic_priority_target", "study_plan_id", "recurrence", "recurrence_id", "recurrence_series_id", "study_plan")
    private object Missing
    private fun value(o: JSONObject?, k: String): Any? = if (o != null && o.has(k)) o.opt(k) else Missing
    private fun keys(o: JSONObject?): Set<String> = if (o == null) emptySet() else o.keys().asSequence().toSet()
    private fun canonical(x: Any?): String = when (x) {
        Missing -> "MISSING"
        null, JSONObject.NULL -> "NULL"
        is JSONObject -> keys(x).sorted().joinToString(",", "{", "}") { JSONObject.quote(it) + ":" + canonical(x.opt(it)) }
        is JSONArray -> (0 until x.length()).joinToString(",", "[", "]") { canonical(x.opt(it)) }
        is Number -> x.toString()
        is Boolean -> x.toString()
        else -> JSONObject.quote(x.toString())
    }
    fun equivalent(a: Any?, b: Any?): Boolean = canonical(a) == canonical(b)
    private fun put(o: JSONObject, key: String, v: Any?) {
        if (v === Missing) o.remove(key) else o.put(key, v)
    }
    private fun clone(o: JSONObject) = JSONObject(o.toString())
    private fun byId(a: JSONArray?): LinkedHashMap<String, JSONObject> {
        val result = linkedMapOf<String, JSONObject>()
        if (a != null) for (i in 0 until a.length()) {
            val item = a.optJSONObject(i) ?: continue
            val id = item.optString("id")
            if (id.isNotBlank()) result[id] = item
        }
        return result
    }

    fun merge(base: JSONObject, local: JSONObject, remote: JSONObject, preferLocal: Set<String>? = null): Result {
        val merged = clone(remote)
        val issues = mutableListOf<Issue>()
        val overrides = mutableListOf<String>()
        // Root is server-owned unless explicitly supported below. Android never edits these keys, so a
        // base/local difference is never a user edit: the cloud value wins and no conflict is raised.
        // Unknown website fields are preserved because [merged] starts as a copy of the cloud snapshot.
        for (k in keys(base) + keys(local)) {
            if (k in metadata || k == "tasks" || k == "settings" || k == "saved_criteria") continue
            if (!equivalent(value(base, k), value(local, k))) overrides += k
        }
        val bSettings = base.optJSONObject("settings")
        val lSettings = local.optJSONObject("settings")
        val rSettings = remote.optJSONObject("settings")
        val mergedSettings = if (rSettings == null) JSONObject() else clone(rSettings)
        for (k in keys(bSettings) + keys(lSettings) + keys(rSettings)) {
            val b = value(bSettings, k); val l = value(lSettings, k); val r = value(rSettings, k)
            if (equivalent(l, b)) continue
            if (k !in localSettings) {
                // Website/server-managed setting (worker_url, custom_tags, auto_page_refresh, ...): cloud wins.
                overrides += "settings.$k"
                continue
            }
            if (equivalent(r, b) || equivalent(l, r)) put(mergedSettings, k, l)
            else if (preferLocal == null) issues += Issue(SNAPSHOT_ID, listOf("settings.$k"), local, remote)
            else if (preferLocal?.contains(SNAPSHOT_ID) == true) put(mergedSettings, k, l) // else cloud value already in mergedSettings
        }
        if (rSettings != null || lSettings != null) merged.put("settings", mergedSettings)

        // Saved criteria can be added independently by either device. Existing record edits are conservative.
        val bCriteria = byId(base.optJSONArray("saved_criteria"))
        val lCriteria = byId(local.optJSONArray("saved_criteria"))
        val rCriteria = byId(remote.optJSONArray("saved_criteria"))
        val criteria = JSONArray()
        for (id in (rCriteria.keys + lCriteria.keys + bCriteria.keys).toSet()) {
            val b = bCriteria[id]; val l = lCriteria[id]; val r = rCriteria[id]
            when {
                b == null && l != null && r == null -> criteria.put(clone(l))
                (b == null && l != null && r != null && !equivalent(l, r)) ||
                (b != null && !equivalent(l, b) && !equivalent(r, b) && !equivalent(l, r)) -> when {
                    preferLocal == null -> issues += Issue(SNAPSHOT_ID, listOf("saved_criteria.$id"), local, remote)
                    preferLocal?.contains(SNAPSHOT_ID) == true -> { if (l != null) criteria.put(clone(l)) }
                    else -> { if (r != null) criteria.put(clone(r)) }
                }
                b != null && !equivalent(l, b) && equivalent(r, b) -> if (l != null) criteria.put(clone(l))
                r != null -> criteria.put(clone(r))
            }
        }
        if (base.has("saved_criteria") || local.has("saved_criteria") || remote.has("saved_criteria")) merged.put("saved_criteria", criteria)

        val bTasks = byId(base.optJSONArray("tasks"))
        val lTasks = byId(local.optJSONArray("tasks"))
        val rTasks = byId(remote.optJSONArray("tasks"))
        val mergedTasks = JSONArray()
        for (id in (rTasks.keys + lTasks.keys + bTasks.keys).toSet()) {
            val b = bTasks[id]; val l = lTasks[id]; val r = rTasks[id]
            if (b == null) {
                when {
                    l == null && r != null -> mergedTasks.put(clone(r))
                    r == null && l != null -> mergedTasks.put(clone(l))
                    l != null && r != null && equivalent(l, r) -> mergedTasks.put(clone(r))
                    l != null && r != null -> {
                        if (preferLocal?.contains(id) == true) mergedTasks.put(clone(l))
                        else if (preferLocal != null) mergedTasks.put(clone(r))
                        else issues += Issue(id, listOf("created_on_both_devices"), l, r)
                    }
                }
                continue
            }
            if (l == null || r == null) {
                val survivor = l ?: r
                if (survivor != null && !equivalent(survivor, b)) {
                    if (preferLocal == null) issues += Issue(id, listOf("delete_vs_edit"), l, r)
                    else if (preferLocal.contains(id)) { if (l != null) mergedTasks.put(clone(l)) }
                    else { if (r != null) mergedTasks.put(clone(r)) }
                } else if (l != null && r != null) mergedTasks.put(clone(r))
                continue
            }
            val candidate = clone(r)
            val taskIssues = mutableListOf<String>()
            for (key in keys(b) + keys(l) + keys(r)) {
                val bv = value(b, key); val lv = value(l, key); val rv = value(r, key)
                if (equivalent(lv, bv)) continue
                if (key in serverTaskFields) {
                    // Server-owned: cloud value stays. Only an unresolved (preferLocal == null) merge reports it.
                    if (preferLocal == null) taskIssues += key
                    continue
                }
                if (equivalent(rv, bv) || equivalent(lv, rv)) put(candidate, key, lv)
                else if (preferLocal?.contains(id) == true) put(candidate, key, lv)
                else if (preferLocal == null) taskIssues += key
            }
            if (taskIssues.isNotEmpty()) issues += Issue(id, taskIssues, l, r)
            else mergedTasks.put(candidate)
        }
        merged.put("tasks", mergedTasks)
        return Result(merged, issues, overrides)
    }

    fun hasLocalEdits(base: JSONObject, local: JSONObject): Boolean {
        val normalizedBase = clone(base)
        val normalizedLocal = clone(local)
        for (k in metadata) { normalizedBase.remove(k); normalizedLocal.remove(k) }
        return !equivalent(normalizedBase, normalizedLocal)
    }
}
