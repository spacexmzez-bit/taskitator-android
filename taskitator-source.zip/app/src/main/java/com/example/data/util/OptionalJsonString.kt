package com.example.data.util

import org.json.JSONObject

/** Preserve JSON null as Kotlin null for optional task relationships. */
fun optionalJsonString(json: JSONObject, key: String): String? {
    if (!json.has(key) || json.isNull(key)) return null
    return json.optString(key, "").takeIf { it.isNotBlank() }
}
