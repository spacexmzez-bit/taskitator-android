package com.example.data.sync

/** What a sync request should do next. Pure decision, no I/O. */
enum class SyncStep { SIGNED_OUT, BUSY, PULL, PUSH }

object SyncDecision {
    /**
     * - No token: nothing can sync.
     * - A sync already running: do not start another.
     * - First pull not done yet: pull only, so an empty local store can never overwrite the cloud.
     * - No local edits: pull only, never push an unchanged snapshot.
     * - Otherwise push.
     */
    fun next(hasToken: Boolean, inProgress: Boolean, needsInitialPull: Boolean, dirty: Boolean): SyncStep = when {
        !hasToken -> SyncStep.SIGNED_OUT
        inProgress -> SyncStep.BUSY
        needsInitialPull || !dirty -> SyncStep.PULL
        else -> SyncStep.PUSH
    }
}
