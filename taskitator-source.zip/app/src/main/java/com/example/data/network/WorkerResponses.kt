package com.example.data.network

import org.json.JSONObject

/** Pure readers for Worker responses. Shapes are documented in docs/WORKER_CONTRACTS.md. */

/** GET /auth/me. */
data class AuthMe(
    val workerUser: String,
    val username: String,
    val clerkUserId: String,
    val deletionPending: Boolean
) {
    val linked: Boolean get() = workerUser.isNotBlank()

    companion object {
        fun parse(json: JSONObject): AuthMe {
            val account = json.optJSONObject("account")
            val user = account?.optString("user").orEmpty()
            val name = account?.optString("username").orEmpty()
                .ifBlank { account?.optString("display_name").orEmpty() }
            return AuthMe(
                workerUser = user,
                username = name,
                clerkUserId = account?.optString("user_id").orEmpty(),
                deletionPending = account == null && json.optJSONObject("deletion") != null
            )
        }
    }
}

/**
 * GET /pro/status, as the Android app must read it.
 * The app is Pro only when the Worker says so for the app ("entitlements.app").
 * A website-only Pro account is a free account inside the app.
 */
data class ProStatus(val appPro: Boolean, val personalKeyMode: Boolean) {
    companion object {
        val FREE = ProStatus(appPro = false, personalKeyMode = false)

        fun parse(json: JSONObject): ProStatus {
            val appPro = json.optJSONObject("entitlements")?.optBoolean("app", false) ?: false
            return ProStatus(appPro = appPro, personalKeyMode = appPro && json.optBoolean("use_byok", false))
        }
    }
}

/** GET or POST /emergency. The Worker owns the count and the window; the app only shows them. */
data class EmergencyState(val usesLeft: Int, val activeUntilMs: Long, val resetAtMs: Long) {
    fun isActive(nowMs: Long): Boolean = activeUntilMs > nowMs

    companion object {
        val UNKNOWN = EmergencyState(usesLeft = 0, activeUntilMs = 0L, resetAtMs = 0L)

        fun parse(json: JSONObject): EmergencyState = EmergencyState(
            usesLeft = json.optInt("uses_left", 0).coerceAtLeast(0),
            activeUntilMs = json.optLong("active_until_ms", 0L),
            resetAtMs = json.optLong("reset_at", 0L)
        )
    }
}

/** POST /pro/ai/batch-confirm request body. */
object AuditConfirm {
    fun body(jobId: String, taskIds: List<String>, operationId: String, batch: Boolean): JSONObject =
        JSONObject()
            .put("job_id", jobId)
            .put("task_ids", org.json.JSONArray(taskIds))
            .put("operation_id", operationId)
            .put("batch", batch)
}

/** Maps a Worker HTTP failure to the typed exception the sync code branches on. */
object WorkerErrors {
    /** Reads "error" from a Worker error body; falls back to the raw text. */
    fun message(body: String): String = try {
        JSONObject(body).optString("error").ifBlank { body }
    } catch (_: Exception) {
        body
    }.take(500)

    fun isVersionConflict(body: String): Boolean = try {
        JSONObject(body).optBoolean("conflict", false)
    } catch (_: Exception) {
        false
    }

    fun forStatus(code: Int, body: String = ""): Exception {
        val detail = message(body)
        return when (code) {
            401 -> UnauthorizedException("Unauthorized (401). Please sign in again.")
            403 -> WorkerProtectionException("Forbidden (403): $detail", body)
            // Only { "conflict": true } means another device wrote first. Any other 409 is a rule refusal.
            409 -> if (isVersionConflict(body)) SyncConflictException("SYNC_409_CONFLICT", body)
                   else WorkerProtectionException("Rejected (409): $detail", body)
            410 -> AccountDeletedException("Account deletion has been accepted (410).")
            428 -> PreconditionRequiredException("Precondition required (428): $detail")
            429 -> RateLimitException("Rate limit exceeded (429). Please retry shortly.")
            503 -> ServiceUnavailableException("Worker temporarily unavailable (503). Local edits are kept.")
            else -> Exception("HTTP $code: $detail")
        }
    }
}
