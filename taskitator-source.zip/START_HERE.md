# Taskitator — install and test the Android recovery build

## What you have

This ZIP is the latest repaired Android **source**, not an APK. It uses package ID `com.mazendev.taskitator`. The pre-existing APK in the workspace is from an older AI Studio build and is not equivalent to this source.

The Android app has **not** passed compilation, device sign-in, or Milestone 1 acceptance testing. Treat the first APK as a development test build only.

## Requirements (Windows)

1. Install **Android Studio** from https://developer.android.com/studio.
2. In Android Studio **SDK Manager**, install **Android SDK Platform 36**, **Android SDK Build-Tools 36**, and **Android SDK Platform-Tools**.
3. Install **JDK 21**, or use Android Studio's bundled `jbr` if its Java version is 21.
4. Have an Internet connection for Gradle and Android dependencies on the first build.
5. Extract the entire ZIP to a short path such as `C:\TaskitatorAndroid`. Do not open a single file from inside the ZIP.

## One-command debug APK build (PowerShell)

Open **Windows PowerShell** in the extracted project folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build-debug.ps1
```

The script uses the installed Android SDK and JDK 21, downloads Gradle 9.8.2 into `.local-gradle` if needed, runs `testDebugUnitTest`, then builds `assembleDebug`. If any step fails, it exits and prints the failure.

If Java 21 is not detected, set `JAVA_HOME` to your JDK 21 directory, e.g.:

```powershell
$env:JAVA_HOME = 'C:\Program Files\Android\Android Studio\jbr'
powershell -NoProfile -ExecutionPolicy Bypass -File .\build-debug.ps1
```

When successful, the APK is:

`app\build\outputs\apk\debug\app-debug.apk`

**Do not assume the build succeeded unless the command ends with `BUILD SUCCESSFUL` and the APK exists.** If it fails, share the Gradle error output so the source can be corrected.

## Install on your Android phone

**Option A — USB (recommended):** Enable Developer options and USB debugging on your phone, connect it to your PC, approve the USB debugging prompt, then run:

```powershell
& "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe" devices
& "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe" install -r ".\app\build\outputs\apk\debug\app-debug.apk"
```

**Option B — file transfer:** Copy the APK to your phone, open it with Files, and approve installation from that app when Android prompts you. Only install APKs you built yourself or trust.

If Android says an app with the same package ID has a different signature, back up its data first; uninstalling an existing installation deletes that app's local data.

## Safe first test

1. Use a **new, disposable Clerk/Taskitator account**. Do not test initial synchronization on an account containing important tasks.
2. Launch the app and check whether Clerk shows email/password and Google options.
3. Sign in. If the Worker returns **401 / Session expired**, stop: the native Clerk JWT `azp` policy probably needs the reviewed Worker change. Do not try to bypass it client-side.
4. Check that account linking and initial cloud pull finish before creating/editing tasks.
5. Test task create, edit, close/reopen, airplane-mode edits, reconnect, and conflicting edits across devices. Verify data on the website before considering the milestone passed.

## Release format

Debug APK is for direct installation and testing. An **AAB** is for Play Store release, requires a dedicated signing/upload key and verified production behavior, and is not the appropriate artifact at this stage.

## Known blockers

- No verified Android compilation, so compile errors may remain.
- No verified Clerk Google OAuth return flow on device.
- The existing Worker may reject native tokens (`azp` policy).
- Cloud sync and conflict recovery are not certified safe on real accounts.
- The included acceptance tests have not been executed here.
