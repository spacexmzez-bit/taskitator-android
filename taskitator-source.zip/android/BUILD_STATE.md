# Taskitator Android build verification — 2026-11-06

- Source: recovered Milestone 1 Android project from latest AI Studio ZIP, with follow-up repair changes.
- Android application ID: `com.mazendev.taskitator`.
- Source archive prepared and ZIP integrity checked.
- **Compilation: NOT RUN** — this environment has no Android SDK/Gradle or dependency-repository access.
- **APK for this source: NOT GENERATED**. The existing `app-debug.apk` in the workspace belongs to an older AI Studio build with package `com.aistudio.taskitator.mvptsk`; it is NOT this project.
- **Device Clerk sign-in: NOT VERIFIED**. Native session JWT may be rejected by the production Worker `azp` validation.
- **A01–A20 acceptance tests: NOT VERIFIED**. Tests are included but their presence is not evidence of passing.
- **Production changes: NONE**. Do not deploy Worker patches without review.

See `START_HERE.md` and `MANUAL_WORKER_AUTH.md`.

## Build 1 sync-recovery patch — 2026-11-06
- Compilation: NOT RUN (no Android SDK / Maven access in the authoring environment). First verification is the GitHub Actions build and `gradle test`.
- `SnapshotMerge`: root keys and non-device settings are server-owned (cloud wins, no `__snapshot__` conflict); device-editable settings and saved criteria honour the user's choice via the `__snapshot__` entry; protected task fields keep the cloud value when a choice is applied.
- `TaskRepository`: Apply Choice / All Device no longer dead-end on `__snapshot__`; Adopt Cloud parses before persisting, rolls back on failure, and archives a timestamped `*_conflict_backup_<ts>.json`; `parseSnapshot` no longer throws on unexpected website shapes.
- `ConflictResolutionDialog`: phone-width layout, stacked buttons, status line.
- Tests added in `SnapshotMergeTest` — NOT YET RUN.

## UI fix patch — 2026-11-06 (not compiled)
- Priority display name read from website field `name` (was `label` → raw ids like `prio_high` shown).
- Titles shown without `{key==value}` markup.
- Today list now follows website rule (active only, due today/overdue anchors, no blank dates).
- Filter dialog and Edit Task: wrapping chips; due date quick-picks + date picker; wider dialog.

## Build 2 (core task management) — 2026-11-06, NOT compiled / NOT run
- Wire format fix: `created_at` / `completed_at` are read as ISO or number and written as ISO strings (website calls string methods on them; numbers broke its Completed list and sort).
- Un-completing AI-locked tasks is blocked (website rule).
- Nav: Calendar, Projects, Stats, Trash screens (already written, previously unreachable) are now routed from the drawer.
- Sorting: Priority / Alphabetical / Required-then-priority (website comparator), persisted; applied to Today, General, Projects and subtasks.
- Dynamic Priority (derived effective priority) ported for sorting.
- Completed Tasks dialog from the top-bar ✓ chip (Today: today's completions; General: all).
- Real projects: `projects[]` + `task.project_id` (Inbox default), create/rename/delete (tasks move to Inbox), project picker in Task dialog, subtree moves with parent, merge-by-id in SnapshotMerge.
- General list now shows active tasks only. Titles are displayed exactly as stored (website behavior).
- NOT done: project filter, Calendar/Stats parity audit against website, bulk-operation audit, collapse-state persistence, undo audit, Dashboard "overdue" count alignment.
