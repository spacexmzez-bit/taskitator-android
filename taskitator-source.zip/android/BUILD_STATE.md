# Taskitator Android build verification — 2026-11-06

- Source: recovered Milestone 1 Android project from latest AI Studio ZIP, with follow-up repair changes.
- Android application ID: `com.mazendev.taskitator`.
- Source archive prepared and ZIP integrity checked.
- **Compilation: NOT RUN** — this environment has no Android SDK/Gradle or dependency-repository access.
- **APK for this source: NOT GENERATED**. The existing `app-debug.apk` in the workspace belongs to an older AI Studio build with package `com.aistudio.taskitator.mvptsk`; it is NOT this project.
- **Device Clerk sign-in: NOT VERIFIED**. Native session JWT may be rejected by the production Worker `azp` validation.
- **A01–A20 acceptance tests: NOT VERIFIED**. Tests are included but their presence is not evidence of passing.
- **Production changes: NONE**. Do not deploy Worker patches without review.

See `START_HERE.md` and `MANUAL_WORKER_AUTH.md`.

## Build 1 sync-recovery patch — 2026-11-06
- Compilation: NOT RUN (no Android SDK / Maven access in the authoring environment). First verification is the GitHub Actions build and `gradle test`.
- `SnapshotMerge`: root keys and non-device settings are server-owned (cloud wins, no `__snapshot__` conflict); device-editable settings and saved criteria honour the user's choice via the `__snapshot__` entry; protected task fields keep the cloud value when a choice is applied.
- `TaskRepository`: Apply Choice / All Device no longer dead-end on `__snapshot__`; Adopt Cloud parses before persisting, rolls back on failure, and archives a timestamped `*_conflict_backup_<ts>.json`; `parseSnapshot` no longer throws on unexpected website shapes.
- `ConflictResolutionDialog`: phone-width layout, stacked buttons, status line.
- Tests added in `SnapshotMergeTest` — NOT YET RUN.
