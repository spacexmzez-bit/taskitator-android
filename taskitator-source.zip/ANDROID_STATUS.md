# Taskitator Android — status

Updated 2026-11-11, Phase 1 delivered. `PHASE1_STATUS.md` is the previous builder's note and is kept unchanged.

## How this delivery was checked

- Data layer (`app/src/main/java/com/example/data/**`) and all unit tests: compiled locally with Kotlin 2.0.21 against hand-written stand-ins for the Android classes. 51 unit tests pass locally.
- A local-only smoke run of `TaskRepository` with a fake `Context` passed (fresh install, save, relaunch, corrupt file, sign-out). It is not in the zip because CI has no fake `Context`.
- UI layer (`ui/**`): **not compiled**. No Android SDK or Compose here. Checked only for syntax and for references to removed code.
- `KeystoreTokenStore` cannot run outside a device. It compiles against stand-ins only.
- Nothing was tested against the live Worker: there is no working sign-in until Phase 3.

A green GitHub Actions run is still required before any of this counts as verified.

## Phase 0 — Baseline and contracts: done

Green CI on the baseline zip confirmed by the owner on 2026-11-11. Contracts and findings: `docs/WORKER_CONTRACTS.md`.

## Phase 1 — Cleanup and audit defects

| Item | State | Where |
|---|---|---|
| Emergency Bypass uses the Worker (`/emergency`), no local activation or use counting | Done, untested on device | `TaskRepository.activateEmergencyBypass`, `refreshEmergency`; `EmergencyBypassDialog.kt`; top-bar 🚨 now opens the dialog |
| Pomodoro records no breaks (same as the website) | Done | `_breaks`, `addBreak`, `BreakSession`, `BreakType` deleted; Stats screen break cards removed |
| `AuditEngine` deleted | Done | file removed |
| `evaluatePhoneAccess` and its dialog deleted | Done | `PhoneAccessDialog.kt` removed (it was never shown) |
| Local study-plan generator deleted | Done | `StudyPlanGenerator.kt`, `StudyPlanDialog.kt` and the drawer entry removed. Study plans return in Phase 5 |
| `confirmAuditApproval` follows the website (push unsent edits → `/pro/ai/batch-confirm` → pull) | Done in the data layer, no caller yet | `TaskRepository.confirmAuditApproval(taskId, jobId)` |
| Fake proof submission removed | Done | `EvidenceAuditDialog.kt` no longer sends a made-up file to the AI; it tells the user to submit proof on the website. Real proof upload is Phase 6 |
| Website-only screens and calls removed (license activation, personal-key toggle and key calls, provider picker, phone-token setup) | Done | `SettingsScreen.kt` tabs "Pro" and "Phone Lock"; `TaskitatorWorkerApi.kt` |
| Pro state comes from the Worker, never from the snapshot | Done | `ProStatus.parse` reads `entitlements.app` only. Until Phase 4 adds that field, every account is free inside the app |
| Session token encrypted with an Android Keystore key; old plain-text token moved on first run | Done, untested on device | `data/security/TokenStore.kt` |
| Backup and device transfer off | Done | `AndroidManifest.xml`, `res/xml/data_extraction_rules.xml` |
| Merge and sync decision moved to pure classes with tests | Done | `data/sync/SyncMerge.kt`, `SyncDecision.kt`, `SnapshotStore.kt` |
| Literal-only tests replaced by tests of real code | Done | `app/src/test/java/com/example/*` |
| CI guard against website-only purchase and key text | Done | `PlaySourceGuardTest.kt` (confirmed it fails when the text is present) |
| Push sends `dynamic_priority_schema: 1` | Done | `TaskitatorWorkerApi.createPushPayload` |

### Defects fixed while moving code

- A push refused with 409 for a rule (not a version conflict) started a merge and could retry forever. Only `{"conflict": true}` starts a merge now, and a rebase is retried once.
- The merge crashed when one side had removed a field from a task.
- On a conflict, local data was written into the "cloud" copy shown to the user. The cloud copy is now left untouched.
- A corrupt snapshot file could be copied over the good recovery copy.
- `is_pro`, `use_byok` and emergency fields were written into the synced settings. They are no longer read from or written to the snapshot.
- When a push succeeded but the follow-up pull failed, the app kept the old version number and stayed marked as unsynced.

## Not done / known broken (later phases)

- Sign-in: the "Sign In on Taskitator Web" button only opens the website; nothing returns to the app. Pasted tokens expire in about a minute. Phase 3.
- "Delete Account on Website" button remains until in-app deletion exists. Phase 3.
- Criteria validation (`TaskitatorWorkerApi.validateCriteria`) sends a body the Worker does not accept. Phase 6.
- Copilot replies are canned keyword answers. Phase 6.
- `BreakPlanningDialog.kt` is unreachable dead UI. Phase 5.
- Sleep Lock is only editable when the account already has a phone token. Phase 2 creates one for the blocker.
- All UI strings are hard-coded English. Phase 5.
