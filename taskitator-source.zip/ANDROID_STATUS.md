# Taskitator Android — status

Updated 2026-11-14, Phase 2 delivered. `PHASE1_STATUS.md` is the previous builder's note and is kept unchanged.

## How this delivery was checked

- Phase 1: green GitHub Actions run confirmed by the owner on 2026-11-14.
- Phase 2 pure rules (`blocker/BlockerLogic.kt`, `BlockerApi.parseDevice`) and all unit tests: compiled locally with Kotlin 2.0.21. 82 unit tests pass locally (31 new).
- Phase 2 Android code (`BlockerService`, `BlockerPackages`, `BlockerStore`): type-checked locally against hand-written stand-ins for the Android classes. That catches Kotlin mistakes, not wrong Android behaviour.
- Phase 2 UI (`ui/screens/BlockerSettings.kt`, `MainActivity.kt`): **not compiled**. No Compose here.
- **Nothing in Phase 2 has run on a device.** The service, the block screen, the app picker and the permission flow are untested until the owner sideloads the APK.
- Nothing was tested against the live Worker: there is no working sign-in until Phase 3. The debug-only "Test lock" switch exists so the block screen can be tried without an account.

A green GitHub Actions run and a device test are required before Phase 2 counts as verified.

## Phase 0 — Baseline and contracts: done

Green CI on the baseline zip confirmed by the owner on 2026-11-11. Contracts and findings: `docs/WORKER_CONTRACTS.md`.

## Phase 1 — Cleanup and audit defects

| Item | State | Where |
|---|---|---|
| Emergency Bypass uses the Worker (`/emergency`), no local activation or use counting | Done, untested on device | `TaskRepository.activateEmergencyBypass`, `refreshEmergency`; `EmergencyBypassDialog.kt`; top-bar 🚨 now opens the dialog |
| Pomodoro records no breaks (same as the website) | Done | `_breaks`, `addBreak`, `BreakSession`, `BreakType` deleted; Stats screen break cards removed |
| `AuditEngine` deleted | Done | file removed |
| `evaluatePhoneAccess` and its dialog deleted | Done | `PhoneAccessDialog.kt` removed (it was never shown) |
| Local study-plan generator deleted | Done | `StudyPlanGenerator.kt`, `StudyPlanDialog.kt` and the drawer entry removed. Study plans return in Phase 5 |
| `confirmAuditApproval` follows the website (push unsent edits → `/pro/ai/batch-confirm` → pull) | Done in the data layer, no caller yet | `TaskRepository.confirmAuditApproval(taskId, jobId)` |
| Fake proof submission removed | Done | `EvidenceAuditDialog.kt` no longer sends a made-up file to the AI; it tells the user to submit proof on the website. Real proof upload is Phase 6 |
| Website-only screens and calls removed (license activation, personal-key toggle and key calls, provider picker, phone-token setup) | Done | `SettingsScreen.kt` tabs "Pro" and "Phone Lock"; `TaskitatorWorkerApi.kt` |
| Pro state comes from the Worker, never from the snapshot | Done | `ProStatus.parse` reads `entitlements.app` only. Until Phase 4 adds that field, every account is free inside the app |
| Session token encrypted with an Android Keystore key; old plain-text token moved on first run | Done, untested on device | `data/security/TokenStore.kt` |
| Backup and device transfer off | Done | `AndroidManifest.xml`, `res/xml/data_extraction_rules.xml` |
| Merge and sync decision moved to pure classes with tests | Done | `data/sync/SyncMerge.kt`, `SyncDecision.kt`, `SnapshotStore.kt` |
| Literal-only tests replaced by tests of real code | Done | `app/src/test/java/com/example/*` |
| CI guard against website-only purchase and key text | Done | `PlaySourceGuardTest.kt` (confirmed it fails when the text is present) |
| Push sends `dynamic_priority_schema: 1` | Done | `TaskitatorWorkerApi.createPushPayload` |

### Defects fixed while moving code

- A push refused with 409 for a rule (not a version conflict) started a merge and could retry forever. Only `{"conflict": true}` starts a merge now, and a rebase is retried once.
- The merge crashed when one side had removed a field from a task.
- On a conflict, local data was written into the "cloud" copy shown to the user. The cloud copy is now left untouched.
- A corrupt snapshot file could be copied over the good recovery copy.
- `is_pro`, `use_byok` and emergency fields were written into the synced settings. They are no longer read from or written to the snapshot.
- When a push succeeded but the follow-up pull failed, the app kept the old version number and stayed marked as unsynced.

## Not done / known broken (later phases)

- Sign-in: the "Sign In on Taskitator Web" button only opens the website; nothing returns to the app. Pasted tokens expire in about a minute. Phase 3.
- "Delete Account on Website" button remains until in-app deletion exists. Phase 3.
- Criteria validation (`TaskitatorWorkerApi.validateCriteria`) sends a body the Worker does not accept. Phase 6.
- Copilot replies are canned keyword answers. Phase 6.
- `BreakPlanningDialog.kt` is unreachable dead UI. Phase 5.
- Sleep Lock is only editable when the account already has a phone token. The app now creates one after sign-in (Phase 2).
- All UI strings are hard-coded English. Phase 5.

## Phase 2 — Native app blocker

| Item | State | Where |
|---|---|---|
| Foreground-app detection with an AccessibilityService (`typeWindowStateChanged` only, no window content, `isAccessibilityTool="false"`) | Built, untested on device | `blocker/BlockerService.kt`, `res/xml/blocker_service.xml`, `AndroidManifest.xml` |
| Block screen as an accessibility overlay; no "draw over other apps" permission | Built, untested on device | `BlockerService.showOverlay` |
| Block screen buttons: Open Taskitator, Emergency Bypass (opens the app's Emergency dialog), Go to home screen; shows why it is locked and when the lock was last checked | Built, untested on device | `BlockerService.buildOverlay`, `MainActivity.readBlockerIntent` |
| Decision rule (app + lock state + lists → block / allow / leave as is) | Done, unit-tested | `BlockDecision.decide` in `blocker/BlockerLogic.kt`; `BlockerLogicTest` |
| Lock state only from the Worker `/status` (JSON form), read with the phone's own token | Built; parsing unit-tested; live call untested | `BlockerApi.status`, `StatusOutcome.fromHttp` |
| Phone token created silently after sign-in (`POST /auth/phone`), stored encrypted; removed from the account on sign-out | Built, untested (needs sign-in) | `BlockerLink`, `TaskitatorViewModel.linkBlockerPhone`, `signOut` |
| Refresh: on service start, on app switches (at most every 15 s), every 60 s while the screen is on, and right after a successful break / Sleep Lock / Emergency / sync push | Built; timing rule unit-tested | `StatusRefreshPolicy`, `BlockerSignals`, hooks in `TaskitatorWorkerApi.kt` |
| Offline: last known lock state stays in force; a failed or malformed answer never unlocks | Done in the rules, unit-tested | `StatusOutcome.fromHttp`, `BlockerStore.lockState` |
| Never blocked: Taskitator, home screen, dialer and in-call screens, Settings, permission dialogs. Keyboards and system panels do not change the screen | Built; rule unit-tested, package lookup untested on device | `BlockerPackages` |
| Blocked-apps picker (device-local list, search) | Built, not compiled locally | `ui/screens/BlockerSettings.kt` |
| Loosening refused while locked (turn off, remove an app, sign out) | Rule done and unit-tested; UI not compiled locally | `BlockListRules` |
| Prominent disclosure + consent before Android settings | Built, not compiled locally | `BlockerDisclosure` |
| Service status, "why is an app blocked" text, battery guidance | Built, not compiled locally | `BlockerSettings` |
| Play declaration text, store sentence (EN + AR), privacy paragraph, demo video script, per-maker battery table | Done | `docs/PLAY_ACCESSIBILITY.md` |
| Debug-only "Test lock" switch | Built | `BlockerSettings`; ignored in release builds (`BuildConfig.DEBUG`) |
| Device test on Samsung / Xiaomi | **Not done** | owner |

### Phase 2 decisions and limits

- Sleep Lock (`sleep = true`) blocks the same app list as the task lock. The website uses two separate MacroDroid macros; the app has one list.
- The user can still switch the service off in Android's accessibility settings while locked. Android does not let an app prevent that, and Device Admin is out of scope.
- A foreground service / WorkManager was not added. The plan says to add one only if device testing shows the accessibility service going stale.
- The block screen and settings text are English only. Arabic strings come with the rest of the app in Phase 5.
- Each install uses one of the account's phone slots (3 free, 12 Pro). At the limit the blocker cannot link and stays unlocked; the reason is not yet shown in the UI.
- Split-screen and picture-in-picture are not handled: the block screen follows the last app that opened a window.
